import { createPersisted } from './persist'

function sameLine(a, b) {
  return a.productId === b.productId && a.variant === b.variant
}

export const useCartStore = createPersisted('mg-cart', (set, get) => ({
  items: [],
  saved: [],
  couponCode: '',

  addItem: (item, qty = 1) => {
    const variant = item.variant || ''
    const parts = String(variant).split('/').map((p) => p.trim()).filter(Boolean)
    const line = {
      productId: item.id || item.productId,
      name: item.name,
      brand: item.brand || '',
      image: item.image || item.images?.[0],
      price: item.price,
      salePrice: item.salePrice ?? item.price,
      stock: item.stock,
      variant,
      qty,
      color: item.color || item.variants?.color?.[0] || parts[0] || '',
      ram: item.ram || item.variants?.ram?.[0] || '',
      storage: item.storage || item.variants?.storage?.[0] || parts.find((p) => /\d+\s?(GB|TB)/i.test(p)) || '',
      model: item.model || item.variants?.model?.[0] || '',
      specifications: item.specifications || [],
    }
    set((s) => {
      const idx = s.items.findIndex((i) => sameLine(i, line))
      if (idx >= 0) {
        const next = [...s.items]
        next[idx] = { ...next[idx], qty: Math.min((next[idx].stock || 99), next[idx].qty + qty) }
        return { items: next }
      }
      return { items: [...s.items, line] }
    })
  },
  setQty: (productId, variant, qty) =>
    set((s) => ({
      items: s.items
        .map((i) => (i.productId === productId && i.variant === variant ? { ...i, qty: Math.max(1, qty) } : i))
        .filter((i) => i.qty > 0),
    })),
  removeItem: (productId, variant) =>
    set((s) => ({ items: s.items.filter((i) => !(i.productId === productId && i.variant === variant)) })),
  saveForLater: (productId, variant) =>
    set((s) => {
      const item = s.items.find((i) => i.productId === productId && i.variant === variant)
      if (!item) return {}
      return {
        items: s.items.filter((i) => !(i.productId === productId && i.variant === variant)),
        saved: [...s.saved.filter((i) => !(i.productId === productId && i.variant === variant)), item],
      }
    }),
  moveSavedToCart: (productId, variant) =>
    set((s) => {
      const item = s.saved.find((i) => i.productId === productId && i.variant === variant)
      if (!item) return {}
      return {
        saved: s.saved.filter((i) => !(i.productId === productId && i.variant === variant)),
        items: [...s.items, item],
      }
    }),
  setCoupon: (code) => set({ couponCode: code }),
  clearCart: () => set({ items: [], couponCode: '' }),
  count: () => get().items.reduce((n, i) => n + i.qty, 0),
}))

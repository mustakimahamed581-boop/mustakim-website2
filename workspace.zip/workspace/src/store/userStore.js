import { createPersisted } from './persist'
import { defaultCustomers, defaultNotifications } from '../data/seed'

function uid(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
}

export const useUserStore = createPersisted('mg-user', (set, get) => ({
  users: defaultCustomers,
  currentUserId: null,
  notifications: defaultNotifications,
  recentlyViewed: [],

  current: () => get().users.find((u) => u.id === get().currentUserId) || null,
  rememberMe: true,

  login: (phoneOrEmail, password, remember = true) => {
    const key = String(phoneOrEmail || '').trim().toLowerCase()
    const u = get().users.find(
      (x) =>
        (x.phone === phoneOrEmail || String(x.email || '').toLowerCase() === key) &&
        x.password === password &&
        x.status !== 'blocked',
    )
    if (!u) return { ok: false, message: 'Incorrect email or password' }
    set({ currentUserId: u.id, rememberMe: remember })
    return { ok: true, user: u }
  },
  register: ({ name, phone, email, password, photo }) => {
    if (get().users.some((u) => (phone && u.phone === phone) || (email && u.email === email))) {
      return { ok: false, message: 'An account with this phone or email already exists.' }
    }
    const user = {
      id: uid('u'),
      name,
      phone,
      email,
      password,
      photo: photo || '',
      provider: 'email',
      registeredAt: new Date().toISOString(),
      status: 'active',
      addresses: [],
    }
    set((s) => ({ users: [user, ...s.users], currentUserId: user.id, rememberMe: true }))
    return { ok: true, user }
  },
  socialLogin: (provider) => ({
    ok: false,
    message: `${provider} is not configured. Connect it from Admin → API Center before live login.`,
  }),
  logout: () => set({ currentUserId: null }),
  updateProfile: (patch) =>
    set((s) => ({
      users: s.users.map((u) => (u.id === s.currentUserId ? { ...u, ...patch } : u)),
    })),
  upsertAddress: (addr) =>
    set((s) => ({
      users: s.users.map((u) => {
        if (u.id !== s.currentUserId) return u
        const list = u.addresses || []
        const exists = list.some((a) => a.id === addr.id)
        let addresses = exists ? list.map((a) => (a.id === addr.id ? addr : a)) : [{ ...addr, id: addr.id || uid('addr') }, ...list]
        if (addr.isDefault) addresses = addresses.map((a) => ({ ...a, isDefault: a.id === (addr.id || addresses[0].id) }))
        return { ...u, addresses }
      }),
    })),
  deleteAddress: (id) =>
    set((s) => ({
      users: s.users.map((u) =>
        u.id === s.currentUserId ? { ...u, addresses: (u.addresses || []).filter((a) => a.id !== id) } : u,
      ),
    })),
  setUserStatus: (id, status) => set((s) => ({ users: s.users.map((u) => (u.id === id ? { ...u, status } : u)) })),
  deleteUser: (id) =>
    set((s) => ({
      users: s.users.filter((u) => u.id !== id),
      currentUserId: s.currentUserId === id ? null : s.currentUserId,
    })),
  addNotification: (n) => set((s) => ({ notifications: [{ ...n, id: n.id || uid('n'), read: false, createdAt: new Date().toISOString() }, ...s.notifications] })),
  markRead: (id) => set((s) => ({ notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) })),
  markAllRead: (userId) =>
    set((s) => ({ notifications: s.notifications.map((n) => (n.userId === userId ? { ...n, read: true } : n)) })),
  viewProduct: (id) =>
    set((s) => ({ recentlyViewed: [id, ...s.recentlyViewed.filter((x) => x !== id)].slice(0, 12) })),
}))

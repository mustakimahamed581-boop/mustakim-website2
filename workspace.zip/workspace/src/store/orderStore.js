import { createPersisted } from './persist'
import { defaultOrders } from '../data/seed'
import { generateOrderId } from '../utils/orderId'
import { generateInvoiceNumber, estimatedDeliveryIso, normalizePaymentStatus } from '../utils/payment'

export const useOrderStore = createPersisted('mg-orders', (set, get) => ({
  orders: defaultOrders,

  addOrder: (payload) => {
    const id = generateOrderId(get().orders)
    const paymentStatus = normalizePaymentStatus(payload.paymentStatus || 'pending')
    const now = new Date().toISOString()
    const order = {
      ...payload,
      id,
      status: payload.status || 'pending',
      paymentStatus,
      trxId: payload.trxId || '',
      invoiceNumber: payload.invoiceNumber || generateInvoiceNumber(id),
      invoiceGenerated: paymentStatus === 'approved',
      paymentSubmittedAt: payload.paymentSubmittedAt || now,
      paymentApprovedAt: paymentStatus === 'approved' ? now : '',
      estimatedDelivery: payload.estimatedDelivery || estimatedDeliveryIso(payload.paymentMethod === 'cod' ? 3 : 4),
      notes: payload.notes || '',
      timeline: [{ status: 'pending', at: now }],
      courier: payload.courier || { consignmentId: '', trackingCode: '', status: '' },
      createdAt: now,
    }
    set((s) => ({ orders: [order, ...s.orders] }))
    return order
  },
  updateOrder: (id, patch) =>
    set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, ...patch } : o)) })),
  setStatus: (id, status) =>
    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === id
          ? { ...o, status, timeline: [...(o.timeline || []), { status, at: new Date().toISOString() }] }
          : o,
      ),
    })),
  setCourier: (id, courier) =>
    set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, courier: { ...o.courier, ...courier } } : o)) })),
  setPaymentStatus: (id, paymentStatus, extra = {}) => {
    const status = normalizePaymentStatus(paymentStatus)
    const now = new Date().toISOString()
    set((s) => ({
      orders: s.orders.map((o) => {
        if (o.id !== id) return o
        const approved = status === 'approved'
        return {
          ...o,
          paymentStatus: status,
          invoiceGenerated: approved,
          paymentApprovedAt: approved ? now : o.paymentApprovedAt || '',
          status: approved && o.status === 'pending' ? 'confirmed' : status === 'rejected' ? o.status : o.status,
          timeline: approved && o.status === 'pending'
            ? [...(o.timeline || []), { status: 'confirmed', at: now }]
            : o.timeline,
          ...extra,
        }
      }),
    }))
    return get().orders.find((o) => o.id === id)
  },
}))

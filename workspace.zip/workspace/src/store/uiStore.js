import { createPersisted } from './persist'

export const useUiStore = createPersisted('mg-ui', (set) => ({
  soundEnabled: false,
  searchOpen: false,
  cartOpen: false,
  mobileNav: true,
  compareIds: [],
  toasts: [],
  setSound: (soundEnabled) => set({ soundEnabled }),
  setSearchOpen: (searchOpen) => set({ searchOpen }),
  setCartOpen: (cartOpen) => set({ cartOpen }),
  toggleCompare: (id) =>
    set((s) => {
      const has = s.compareIds.includes(id)
      const compareIds = has ? s.compareIds.filter((x) => x !== id) : [...s.compareIds, id].slice(0, 3)
      return { compareIds }
    }),
  pushToast: (toast) =>
    set((s) => ({ toasts: [...s.toasts, { id: Date.now() + Math.random(), ...toast }] })),
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}))

import { createPersisted } from './persist'
import { defaultAdminSecurity } from '../data/seed'

const PROTO_PASSWORD = 'mustakim'
const SESSION_MS = 60 * 60 * 1000

export const useAdminStore = createPersisted('mg-admin', (set, get) => ({
  authed: false,
  authedAt: null,
  password: PROTO_PASSWORD,
  security: defaultAdminSecurity,
  sessions: [],

  isAuthed: () => {
    const { authed, authedAt, security } = get()
    if (!authed || !authedAt) return false
    const timeout = (security.sessionTimeoutMin || 60) * 60 * 1000 || SESSION_MS
    if (Date.now() - authedAt > timeout) {
      set({ authed: false })
      return false
    }
    return true
  },
  login: (password) => {
    if (password !== get().password) {
      set((s) => ({
        security: { ...s.security, failedAttempts: (s.security.failedAttempts || 0) + 1 },
      }))
      return { ok: false, message: 'Incorrect admin password.' }
    }
    const now = new Date().toISOString()
    set((s) => ({
      authed: true,
      authedAt: Date.now(),
      security: { ...s.security, lastLogin: now, failedAttempts: 0 },
      sessions: [{ id: `sess-${Date.now()}`, started: now, device: 'Web Admin' }, ...s.sessions].slice(0, 8),
    }))
    return { ok: true }
  },
  logout: () => set({ authed: false, authedAt: null }),
  logoutAll: () => set({ authed: false, authedAt: null, sessions: [] }),
  changePassword: (current, next) => {
    if (current !== get().password) return { ok: false, message: 'Current password is incorrect.' }
    if (!next || next.length < 6) return { ok: false, message: 'New password must be at least 6 characters.' }
    set({ password: next })
    return { ok: true }
  },
  setTimeoutMin: (min) => set((s) => ({ security: { ...s.security, sessionTimeoutMin: min } })),
}))

import { createPersisted } from './persist'
import {
  defaultCms,
  defaultSettings,
  defaultPayments,
  defaultPaymentMethods,
  defaultInvoiceDesign,
  defaultCourier,
  defaultFirebase,
  defaultIntegrations,
  defaultFeatureFlags,
  defaultAuthProviders,
  defaultLoginPage,
  defaultAds,
  defaultActivityLog,
  defaultIcons,
} from '../data/seed'

function uid(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
}

export const useSettingsStore = createPersisted('mg-settings', (set, get) => ({
  cms: defaultCms,
  settings: defaultSettings,
  payments: defaultPayments,
  paymentMethods: defaultPaymentMethods,
  invoiceDesign: defaultInvoiceDesign,
  courier: defaultCourier,
  firebase: defaultFirebase,
  integrations: defaultIntegrations,
  customApis: [],
  analyticsConfig: { gaId: '', pixelId: '' },
  featureFlags: defaultFeatureFlags,
  authProviders: defaultAuthProviders,
  loginPage: defaultLoginPage,
  ads: defaultAds,
  activityLog: defaultActivityLog,
  icons: defaultIcons,
  lastError: null,

  setCms: (cms) => {
    set((s) => ({ cms: { ...s.cms, ...cms } }))
    get().logActivity('Settings Changed')
  },
  setSettings: (settings) => set((s) => ({ settings: { ...s.settings, ...settings } })),
  setPayments: (payments) => set((s) => ({ payments: { ...s.payments, ...payments } })),
  setInvoiceDesign: (invoiceDesign) =>
    set((s) => ({ invoiceDesign: { ...s.invoiceDesign, ...invoiceDesign } })),
  upsertPaymentMethod: (method) =>
    set((s) => {
      const list = s.paymentMethods || []
      const id = method.id || uid('pay')
      const next = { ...method, id }
      const exists = list.some((m) => m.id === id)
      return {
        paymentMethods: exists ? list.map((m) => (m.id === id ? { ...m, ...next } : m)) : [...list, next],
      }
    }),
  deletePaymentMethod: (id) =>
    set((s) => ({ paymentMethods: (s.paymentMethods || []).filter((m) => m.id !== id) })),
  setPaymentMethodEnabled: (id, enabled) =>
    set((s) => ({
      paymentMethods: (s.paymentMethods || []).map((m) => (m.id === id ? { ...m, enabled } : m)),
    })),
  setCourier: (courier) => set((s) => ({ courier: { ...s.courier, ...courier } })),
  setFirebase: (firebase) => set((s) => ({ firebase: { ...s.firebase, ...firebase } })),
  setIntegration: (id, patch) =>
    set((s) => ({
      integrations: s.integrations.map((i) => (i.id === id ? { ...i, ...patch } : i)),
    })),
  upsertCustomApi: (api) =>
    set((s) => {
      const exists = s.customApis.some((a) => a.id === api.id)
      if (exists) return { customApis: s.customApis.map((a) => (a.id === api.id ? api : a)) }
      return { customApis: [{ ...api, id: api.id || uid('api') }, ...s.customApis] }
    }),
  setAnalyticsConfig: (analyticsConfig) => set({ analyticsConfig }),
  setFeatureFlags: (featureFlags) => set((s) => ({ featureFlags: { ...s.featureFlags, ...featureFlags } })),
  setAuthProviders: (authProviders) => set((s) => ({ authProviders: { ...s.authProviders, ...authProviders } })),
  setLoginPage: (loginPage) => set((s) => ({ loginPage: { ...s.loginPage, ...loginPage } })),
  setIcons: (icons) => set((s) => ({ icons: { ...s.icons, ...icons } })),
  upsertAd: (ad) =>
    set((s) => {
      const code = (ad.code || '').trim()
      if (code && s.ads.some((a) => a.code.trim() === code && a.id !== ad.id)) return {}
      const exists = s.ads.some((a) => a.id === ad.id)
      if (exists) return { ads: s.ads.map((a) => (a.id === ad.id ? { ...a, ...ad } : a)) }
      return { ads: [{ ...ad, id: ad.id || uid('ad'), enabled: ad.enabled !== false }, ...s.ads] }
    }),
  deleteAd: (id) => set((s) => ({ ads: s.ads.filter((a) => a.id !== id) })),
  logActivity: (action, admin = 'Mustakim') =>
    set((s) => ({
      activityLog: [{ id: uid('act'), action, admin, at: new Date().toISOString() }, ...(s.activityLog || [])].slice(0, 80),
    })),
  setLastError: (lastError) => set({ lastError }),
  exportBackup: () => {
    const s = get()
    return {
      cms: s.cms,
      settings: s.settings,
      payments: s.payments,
      paymentMethods: s.paymentMethods,
      invoiceDesign: s.invoiceDesign,
      courier: s.courier,
      firebase: s.firebase,
      integrations: s.integrations,
      featureFlags: s.featureFlags,
      ads: s.ads,
      loginPage: s.loginPage,
      icons: s.icons,
    }
  },
  importBackup: (data) => {
    if (!data || typeof data !== 'object') return { ok: false }
    set((s) => ({
      cms: data.cms ? { ...s.cms, ...data.cms } : s.cms,
      settings: data.settings ? { ...s.settings, ...data.settings } : s.settings,
      payments: data.payments ? { ...s.payments, ...data.payments } : s.payments,
      paymentMethods: data.paymentMethods || s.paymentMethods,
      invoiceDesign: data.invoiceDesign ? { ...s.invoiceDesign, ...data.invoiceDesign } : s.invoiceDesign,
      courier: data.courier ? { ...s.courier, ...data.courier } : s.courier,
      firebase: data.firebase ? { ...s.firebase, ...data.firebase } : s.firebase,
      integrations: data.integrations || s.integrations,
      featureFlags: data.featureFlags ? { ...s.featureFlags, ...data.featureFlags } : s.featureFlags,
      ads: data.ads || s.ads,
      loginPage: data.loginPage ? { ...s.loginPage, ...data.loginPage } : s.loginPage,
      icons: data.icons ? { ...s.icons, ...data.icons } : s.icons,
    }))
    return { ok: true }
  },
}))

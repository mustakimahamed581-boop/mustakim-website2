import { createPersisted } from './persist'
import {
  defaultProducts,
  defaultCategories,
  defaultCoupons,
  defaultFlashSale,
  defaultReviews,
  defaultQuestions,
  defaultBanners,
  defaultHeroSlides,
} from '../data/seed'

function uid(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`
}

export const useCatalogStore = createPersisted('mg-catalog', (set, get) => ({
  products: defaultProducts,
  categories: defaultCategories,
  coupons: defaultCoupons,
  flashSale: defaultFlashSale,
  reviews: defaultReviews,
  questions: defaultQuestions,
  banners: defaultBanners,
  heroSlides: defaultHeroSlides,

  getProduct: (id) => get().products.find((p) => p.id === id),
  getCategory: (slugOrId) =>
    get().categories.find((c) => c.slug === slugOrId || c.id === slugOrId),

  upsertProduct: (product) =>
    set((s) => {
      const exists = s.products.some((p) => p.id === product.id)
      if (exists) return { products: s.products.map((p) => (p.id === product.id ? product : p)) }
      return { products: [{ ...product, id: product.id || uid('p') }, ...s.products] }
    }),
  duplicateProduct: (id) =>
    set((s) => {
      const p = s.products.find((x) => x.id === id)
      if (!p) return {}
      const copy = { ...p, id: uid('p'), sku: `${p.sku}-COPY`, name: `${p.name} (Copy)` }
      return { products: [copy, ...s.products] }
    }),
  deleteProduct: (id) => set((s) => ({ products: s.products.filter((p) => p.id !== id) })),

  upsertCategory: (cat) =>
    set((s) => {
      const exists = s.categories.some((c) => c.id === cat.id)
      if (exists) return { categories: s.categories.map((c) => (c.id === cat.id ? { ...c, ...cat } : c)) }
      return { categories: [...s.categories, { ...cat, id: cat.id || uid('cat') }] }
    }),
  deleteCategory: (id) => set((s) => ({ categories: s.categories.filter((c) => c.id !== id) })),
  reorderCategories: (ordered) => set({ categories: ordered }),

  upsertCoupon: (coupon) =>
    set((s) => {
      const exists = s.coupons.some((c) => c.id === coupon.id)
      if (exists) return { coupons: s.coupons.map((c) => (c.id === coupon.id ? coupon : c)) }
      return { coupons: [{ ...coupon, id: coupon.id || uid('cp') }, ...s.coupons] }
    }),
  deleteCoupon: (id) => set((s) => ({ coupons: s.coupons.filter((c) => c.id !== id) })),
  incrementCouponUse: (code) =>
    set((s) => ({
      coupons: s.coupons.map((c) =>
        c.code.toLowerCase() === String(code).toLowerCase() ? { ...c, usedCount: (c.usedCount || 0) + 1 } : c,
      ),
    })),

  setFlashSale: (flashSale) => set({ flashSale }),

  upsertBanner: (banner) =>
    set((s) => {
      const exists = s.banners.some((b) => b.id === banner.id)
      if (exists) return { banners: s.banners.map((b) => (b.id === banner.id ? banner : b)) }
      return { banners: [{ ...banner, id: banner.id || uid('ban') }, ...s.banners] }
    }),
  deleteBanner: (id) => set((s) => ({ banners: s.banners.filter((b) => b.id !== id) })),

  upsertHero: (slide) =>
    set((s) => {
      const exists = s.heroSlides.some((h) => h.id === slide.id)
      if (exists) return { heroSlides: s.heroSlides.map((h) => (h.id === slide.id ? slide : h)) }
      return { heroSlides: [...s.heroSlides, { ...slide, id: slide.id || uid('hero') }] }
    }),
  deleteHero: (id) => set((s) => ({ heroSlides: s.heroSlides.filter((h) => h.id !== id) })),

  upsertReview: (review) =>
    set((s) => {
      const exists = s.reviews.some((r) => r.id === review.id)
      if (exists) return { reviews: s.reviews.map((r) => (r.id === review.id ? { ...r, ...review } : r)) }
      return { reviews: [{ ...review, id: review.id || uid('rv') }, ...s.reviews] }
    }),
  setReviewStatus: (id, status) =>
    set((s) => ({ reviews: s.reviews.map((r) => (r.id === id ? { ...r, status } : r)) })),
  deleteReview: (id) => set((s) => ({ reviews: s.reviews.filter((r) => r.id !== id) })),

  addQuestion: (q) => set((s) => ({ questions: [{ ...q, id: uid('q') }, ...s.questions] })),
  adjustStock: (id, delta) =>
    set((s) => ({
      products: s.products.map((p) => (p.id === id ? { ...p, stock: Math.max(0, (p.stock || 0) + Number(delta)) } : p)),
    })),
  setStock: (id, stock) =>
    set((s) => ({
      products: s.products.map((p) => (p.id === id ? { ...p, stock: Math.max(0, Number(stock)) } : p)),
    })),
  setProductEnabled: (id, enabled) =>
    set((s) => ({ products: s.products.map((p) => (p.id === id ? { ...p, enabled } : p)) })),
  bulkUpdate: (ids, patch) =>
    set((s) => ({
      products: s.products.map((p) => (ids.includes(p.id) ? { ...p, ...patch, flags: { ...p.flags, ...(patch.flags || {}) } } : p)),
    })),
  importProducts: (list) =>
    set((s) => {
      const incoming = (list || []).map((p) => ({
        ...p,
        id: p.id || uid('p'),
        enabled: p.enabled !== false,
        images: p.images || (p.image ? [p.image] : []),
        flags: p.flags || { featured: false, trending: false, bestSeller: false, newArrival: false, flashSale: false, recommended: false },
      }))
      return { products: [...incoming, ...s.products] }
    }),
}))

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

function safeMerge(persisted, current) {
  if (!persisted || typeof persisted !== 'object') return current
  const out = { ...current }
  for (const key of Object.keys(persisted)) {
    const val = persisted[key]
    if (val == null) continue
    const cur = current[key]
    if (Array.isArray(cur) && !Array.isArray(val)) continue
    if (Array.isArray(val)) {
      out[key] = val
      continue
    }
    if (cur && typeof cur === 'object' && !Array.isArray(cur) && typeof val === 'object' && !Array.isArray(val)) {
      out[key] = { ...cur, ...val }
    } else {
      out[key] = val
    }
  }
  return out
}

export function createPersisted(name, initializer) {
  return create(
    persist(initializer, {
      name,
      storage: createJSONStorage(() => {
        try {
          return localStorage
        } catch {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          }
        }
      }),
      merge: (persisted, current) => safeMerge(persisted, current),
    }),
  )
}

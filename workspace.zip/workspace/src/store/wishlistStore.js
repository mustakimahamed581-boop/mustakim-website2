import { createPersisted } from './persist'

export const useWishlistStore = createPersisted('mg-wishlist', (set, get) => ({
  ids: [],
  toggle: (id) =>
    set((s) => ({ ids: s.ids.includes(id) ? s.ids.filter((x) => x !== id) : [...s.ids, id] })),
  has: (id) => get().ids.includes(id),
  remove: (id) => set((s) => ({ ids: s.ids.filter((x) => x !== id) })),
}))

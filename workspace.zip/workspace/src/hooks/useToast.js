import { useUiStore } from '../store/uiStore'
import { playSound } from '../services/sound'

export function useToast() {
  const pushToast = useUiStore((s) => s.pushToast)
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  return (toast) => {
    pushToast(typeof toast === 'string' ? { title: toast, type: 'info' } : toast)
    if (toast?.type === 'error') playSound('error', soundEnabled)
    if (toast?.type === 'success') playSound('success', soundEnabled)
  }
}

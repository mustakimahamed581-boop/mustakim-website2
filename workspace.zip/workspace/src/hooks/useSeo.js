import { useEffect } from 'react'
import { useCms } from '../context/CmsContext'

export function useSeo({ title, description } = {}) {
  const { cms } = useCms()
  useEffect(() => {
    const t = title ? `${title} | ${cms.shopName}` : cms.seo?.title || cms.shopName
    document.title = t
    const meta = document.querySelector('meta[name="description"]')
    if (meta && (description || cms.seo?.description)) {
      meta.setAttribute('content', description || cms.seo.description)
    }
  }, [title, description, cms])
}

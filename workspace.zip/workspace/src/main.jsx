import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import ErrorBoundary from './components/ui/ErrorBoundary.jsx'

window.addEventListener('unhandledrejection', (e) => {
  try {
    const logs = JSON.parse(localStorage.getItem('mg-runtime-errors') || '[]')
    logs.unshift({ at: new Date().toISOString(), message: String(e.reason?.message || e.reason || 'promise') })
    localStorage.setItem('mg-runtime-errors', JSON.stringify(logs.slice(0, 20)))
  } catch {
    /* ignore */
  }
})

const rootEl = document.getElementById('root')
try {
  createRoot(rootEl).render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>,
  )
} catch (err) {
  rootEl.innerHTML = `<div data-app-ready="1" style="min-height:100vh;display:grid;place-items:center;background:#0A0A0A;color:#fff;text-align:center;padding:24px;font-family:Inter,system-ui,sans-serif"><div><p style="color:#F5A623">MUSTAKIM GADGETS</p><h1>Unable to start</h1><p style="color:#9ca3af">${String(err?.message || err)}</p><p><a href="/" style="color:#F5A623">Reload</a></p></div></div>`
}

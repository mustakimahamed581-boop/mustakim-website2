import { Link, useParams } from 'react-router-dom'
import { useCatalogStore } from '../store/catalogStore'
import { iconByName } from '../utils/icons'
import Shop from './Shop'
import { useSeo } from '../hooks/useSeo'
import AdSlot from '../components/ads/AdSlot'

export default function Categories() {
  const { slug } = useParams()
  if (slug) return <Shop categorySlug={slug} />
  return <CategoryGrid />
}

function CategoryGrid() {
  useSeo({ title: 'Categories' })
  const allCategories = useCatalogStore((s) => s.categories)
  const products = useCatalogStore((s) => s.products)
  const categories = (allCategories || []).filter((c) => c.enabled).sort((a, b) => a.order - b.order)
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Categories</h1>
      <AdSlot placement="category" />
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {categories.map((c) => {
          const Icon = iconByName(c.icon)
          const count = products.filter((p) => p.categoryId === c.id).length
          return (
            <Link key={c.id} to={`/categories/${c.slug}`} className="rounded-2xl overflow-hidden bg-[#111] border border-white/8 hover:border-[#F5A623]/40">
              <div className="h-28 bg-[#1A1A1A]">
                {c.image ? <img src={c.image} alt={c.name} className="w-full h-full object-cover" /> : <div className="grid place-items-center h-full"><Icon className="text-[#F5A623]" /></div>}
              </div>
              <div className="p-3">
                <p className="font-medium">{c.name}</p>
                <p className="text-xs text-white/45">{c.nameBn} · {count} products</p>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  )
}

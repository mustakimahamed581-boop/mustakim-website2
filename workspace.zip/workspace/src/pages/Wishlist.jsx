import { useMemo } from 'react'
import { useCatalogStore } from '../store/catalogStore'
import { useWishlistStore } from '../store/wishlistStore'
import ProductCard from '../components/product/ProductCard'
import EmptyState from '../components/ui/EmptyState'
import { Heart } from 'lucide-react'
import { useSeo } from '../hooks/useSeo'

export default function Wishlist() {
  useSeo({ title: 'Wishlist' })
  const ids = useWishlistStore((s) => s.ids)
  const allProducts = useCatalogStore((s) => s.products)
  const products = useMemo(() => (allProducts || []).filter((p) => ids.includes(p.id)), [allProducts, ids])
  if (!products.length) {
    return <EmptyState icon={Heart} title="Wishlist is empty" message="Tap the heart on any product to save it here." to="/shop" />
  }
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Wishlist</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {products.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Mail, Phone, Lock, User, Eye, EyeOff } from 'lucide-react'
import { useUserStore } from '../store/userStore'
import { useSettingsStore } from '../store/settingsStore'
import Button from '../components/ui/Button'
import Logo from '../components/layout/Logo'
import { useSeo } from '../hooks/useSeo'
import { useToast } from '../hooks/useToast'

export default function Auth({ mode = 'login' }) {
  useSeo({ title: mode === 'login' ? 'Login' : 'Register' })
  const login = useUserStore((s) => s.login)
  const register = useUserStore((s) => s.register)
  const socialLogin = useUserStore((s) => s.socialLogin)
  const providers = useSettingsStore((s) => s.authProviders)
  const page = useSettingsStore((s) => s.loginPage)
  const navigate = useNavigate()
  const loc = useLocation()
  const toast = useToast()
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '', confirm: '', photo: '', remember: true })
  const [show, setShow] = useState(false)
  const redirect = loc.state?.from || '/account'

  const submit = (e) => {
    e.preventDefault()
    if (mode === 'register') {
      if (!providers.registration?.enabled) return toast({ type: 'error', title: 'Registration is disabled' })
      if (form.password !== form.confirm) return toast({ type: 'error', title: 'Passwords do not match' })
      const res = register(form)
      if (!res.ok) return toast({ type: 'error', title: res.message })
      toast({ type: 'success', title: 'Account created' })
      navigate(redirect)
      return
    }
    const id = form.phone || form.email
    const res = login(id, form.password, form.remember)
    if (!res.ok) return toast({ type: 'error', title: res.message })
    toast({ type: 'success', title: 'Welcome back' })
    navigate(redirect)
  }

  const trySocial = (key, label) => {
    const p = providers[key]
    if (!p?.enabled) return toast({ type: 'error', title: `${label} is disabled` })
    if (!p?.configured) return toast({ type: 'error', title: `${label} is not configured`, message: 'Connect it from Admin API Center. No fake success.' })
    const res = socialLogin(label)
    toast({ type: 'error', title: res.message })
  }

  return (
    <div className="min-h-[70vh] relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(245,166,35,0.12),_transparent_55%)] pointer-events-none" />
      <div className="max-w-md mx-auto px-4 py-12 relative">
        <div className="rounded-3xl bg-[#111]/80 border border-white/10 p-6 backdrop-blur-xl shadow-[0_0_40px_rgba(245,166,35,0.08)]">
          <Logo />
          <h1 className="text-2xl font-bold mt-6">{mode === 'login' ? page.title : 'Create account'}</h1>
          <p className="text-xs text-white/50 mt-1">{page.subtitle}</p>
          <p className="text-xs text-white/30 mt-1">Demo: 01700000000 / demo1234</p>
          <form onSubmit={submit} className="space-y-3 mt-5">
            {mode === 'register' ? (
              <label className="flex items-center gap-2 bg-[#1A1A1A] rounded-xl px-3">
                <User size={16} className="text-white/40" />
                <input required className="w-full bg-transparent py-3 outline-none" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </label>
            ) : null}
            <label className="flex items-center gap-2 bg-[#1A1A1A] rounded-xl px-3">
              {mode === 'login' ? <Mail size={16} className="text-white/40" /> : <Phone size={16} className="text-white/40" />}
              <input required className="w-full bg-transparent py-3 outline-none" placeholder={mode === 'login' ? 'Phone or email' : 'Phone number'} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value, email: mode === 'login' ? e.target.value : form.email })} />
            </label>
            {mode === 'register' ? (
              <label className="flex items-center gap-2 bg-[#1A1A1A] rounded-xl px-3">
                <Mail size={16} className="text-white/40" />
                <input className="w-full bg-transparent py-3 outline-none" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </label>
            ) : null}
            <label className="flex items-center gap-2 bg-[#1A1A1A] rounded-xl px-3">
              <Lock size={16} className="text-white/40" />
              <input required type={show ? 'text' : 'password'} className="w-full bg-transparent py-3 outline-none" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
              <button type="button" onClick={() => setShow((v) => !v)} aria-label="Toggle password">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button>
            </label>
            {mode === 'register' ? (
              <input required type="password" className="w-full bg-[#1A1A1A] p-3 rounded-xl" placeholder="Confirm password" value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} />
            ) : (
              <label className="flex items-center gap-2 text-xs text-white/50">
                <input type="checkbox" checked={form.remember} onChange={(e) => setForm({ ...form, remember: e.target.checked })} /> Remember me
              </label>
            )}
            <Button type="submit" className="w-full">{mode === 'login' ? page.loginButton : page.registerButton}</Button>
          </form>
          <div className="grid grid-cols-2 gap-2 mt-4">
            <button type="button" className="rounded-xl border border-white/10 py-2 text-xs" onClick={() => trySocial('google', 'Google')}>Google</button>
            <button type="button" className="rounded-xl border border-white/10 py-2 text-xs" onClick={() => trySocial('facebook', 'Facebook')}>Facebook</button>
            <button type="button" className="rounded-xl border border-white/10 py-2 text-xs" onClick={() => trySocial('github', 'GitHub')}>GitHub</button>
            <button type="button" className="rounded-xl border border-white/10 py-2 text-xs" onClick={() => trySocial('otp', 'Phone OTP')}>Phone OTP</button>
          </div>
          <p className="text-[11px] text-white/35 mt-3">{page.termsText}</p>
          <p className="text-sm text-white/50 mt-4">
            {mode === 'login' ? (
              <>New here? <Link className="text-[#F5A623]" to="/register">Register</Link></>
            ) : (
              <>Have an account? <Link className="text-[#F5A623]" to="/login">Login</Link></>
            )}
          </p>
        </div>
      </div>
    </div>
  )
}

import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { SlidersHorizontal, X } from 'lucide-react'
import { useCatalogStore } from '../store/catalogStore'
import ProductCard from '../components/product/ProductCard'
import QuickView from '../components/product/QuickView'
import EmptyState from '../components/ui/EmptyState'
import { useSeo } from '../hooks/useSeo'
import Button from '../components/ui/Button'
import AdSlot from '../components/ads/AdSlot'

function sortProducts(list, sort) {
  const arr = [...list]
  if (sort === 'price-asc') arr.sort((a, b) => a.salePrice - b.salePrice)
  else if (sort === 'price-desc') arr.sort((a, b) => b.salePrice - a.salePrice)
  else if (sort === 'rating') arr.sort((a, b) => b.rating - a.rating)
  else if (sort === 'discount') arr.sort((a, b) => (b.price - b.salePrice) / b.price - (a.price - a.salePrice) / a.price)
  else if (sort === 'popular') arr.sort((a, b) => b.reviewCount - a.reviewCount)
  else arr.sort((a, b) => Number(b.flags?.newArrival) - Number(a.flags?.newArrival))
  return arr
}

export default function Shop({ categorySlug }) {
  useSeo({ title: categorySlug ? 'Category' : 'Shop' })
  const allProducts = useCatalogStore((s) => s.products)
  const allCategories = useCatalogStore((s) => s.categories)
  const products = useMemo(() => (allProducts || []).filter((p) => p.enabled), [allProducts])
  const categories = useMemo(() => (allCategories || []).filter((c) => c.enabled), [allCategories])
  const [params, setParams] = useSearchParams()
  const q = params.get('q') || ''
  const sort = params.get('sort') || 'newest'
  const [qv, setQv] = useState(null)
  const [sheet, setSheet] = useState(false)
  const [filters, setFilters] = useState({
    category: categorySlug || params.get('cat') || '',
    brand: '',
    min: 0,
    max: 200000,
    rating: 0,
    inStock: false,
    discounted: false,
  })

  const brands = [...new Set(products.map((p) => p.brand))].sort()

  const filtered = useMemo(() => {
    let list = products
    const cat = categories.find((c) => c.slug === filters.category || c.id === filters.category)
    if (cat) list = list.filter((p) => p.categoryId === cat.id)
    if (filters.brand) list = list.filter((p) => p.brand === filters.brand)
    if (filters.inStock) list = list.filter((p) => p.stock > 0)
    if (filters.discounted) list = list.filter((p) => p.salePrice < p.price)
    if (filters.rating) list = list.filter((p) => p.rating >= filters.rating)
    list = list.filter((p) => p.salePrice >= filters.min && p.salePrice <= filters.max)
    if (q) {
      const s = q.toLowerCase()
      list = list.filter((p) => [p.name, p.brand, p.sku, ...(p.keywords || [])].join(' ').toLowerCase().includes(s))
    }
    return sortProducts(list, sort)
  }, [products, categories, filters, q, sort])

  const FilterForm = (
    <div className="space-y-4 text-sm">
      <div>
        <p className="font-semibold mb-2">Category</p>
        <select className="w-full bg-[#1A1A1A] rounded-lg p-2" value={filters.category} onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}>
          <option value="">All</option>
          {categories.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
        </select>
      </div>
      <div>
        <p className="font-semibold mb-2">Brand</p>
        <select className="w-full bg-[#1A1A1A] rounded-lg p-2" value={filters.brand} onChange={(e) => setFilters((f) => ({ ...f, brand: e.target.value }))}>
          <option value="">All</option>
          {brands.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
      </div>
      <div>
        <p className="font-semibold mb-2">Price Range</p>
        <div className="flex gap-2">
          <input type="number" className="w-full bg-[#1A1A1A] rounded-lg p-2" value={filters.min} onChange={(e) => setFilters((f) => ({ ...f, min: Number(e.target.value) }))} />
          <input type="number" className="w-full bg-[#1A1A1A] rounded-lg p-2" value={filters.max} onChange={(e) => setFilters((f) => ({ ...f, max: Number(e.target.value) }))} />
        </div>
      </div>
      <div>
        <p className="font-semibold mb-2">Rating</p>
        {[0, 4, 4.5].map((r) => (
          <label key={r} className="flex items-center gap-2 py-1">
            <input type="radio" checked={filters.rating === r} onChange={() => setFilters((f) => ({ ...f, rating: r }))} />
            {r === 0 ? 'Any' : `${r}+ stars`}
          </label>
        ))}
      </div>
      <label className="flex items-center gap-2"><input type="checkbox" checked={filters.inStock} onChange={(e) => setFilters((f) => ({ ...f, inStock: e.target.checked }))} /> In stock</label>
      <label className="flex items-center gap-2"><input type="checkbox" checked={filters.discounted} onChange={(e) => setFilters((f) => ({ ...f, discounted: e.target.checked }))} /> On discount</label>
    </div>
  )

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between gap-3 mb-4">
        <h1 className="text-2xl font-bold">{q ? `Search: ${q}` : 'Shop'}</h1>
        <div className="flex items-center gap-2">
          <select
            className="bg-[#1A1A1A] rounded-lg p-2 text-sm"
            value={sort}
            onChange={(e) => {
              params.set('sort', e.target.value)
              setParams(params)
            }}
          >
            <option value="newest">Newest</option>
            <option value="popular">Popular</option>
            <option value="price-asc">Price Low → High</option>
            <option value="price-desc">Price High → Low</option>
            <option value="rating">Highest Rated</option>
            <option value="discount">Biggest Discount</option>
          </select>
          <button className="lg:hidden p-2 rounded-lg bg-[#1A1A1A]" onClick={() => setSheet(true)} aria-label="Filters">
            <SlidersHorizontal size={18} />
          </button>
        </div>
      </div>
      <AdSlot placement={q ? 'search' : 'shop'} />
      <p className="text-sm text-white/50 mb-4">Showing {filtered.length} of {products.length} products</p>
      <div className="grid lg:grid-cols-[240px_1fr] gap-6">
        <aside className="hidden lg:block rounded-2xl bg-[#111] border border-white/8 p-4 h-fit sticky top-20">{FilterForm}</aside>
        {filtered.length === 0 ? (
          <EmptyState title="No products found" message="Try a different filter or search term." to="/" action="Go home" />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {filtered.map((p) => <ProductCard key={p.id} product={p} onQuickView={setQv} />)}
          </div>
        )}
      </div>
      {sheet ? (
        <div className="fixed inset-0 z-[70] lg:hidden">
          <button className="absolute inset-0 bg-black/60" onClick={() => setSheet(false)} aria-label="Close filters" />
          <div className="absolute bottom-0 inset-x-0 bg-[#111] rounded-t-2xl p-4 max-h-[80dvh] overflow-y-auto">
            <div className="flex justify-between mb-3">
              <h3 className="font-semibold">Filters</h3>
              <button onClick={() => setSheet(false)} aria-label="Close"><X /></button>
            </div>
            {FilterForm}
            <Button className="w-full mt-4" onClick={() => setSheet(false)}>Apply</Button>
          </div>
        </div>
      ) : null}
      <QuickView product={qv} onClose={() => setQv(null)} />
    </div>
  )
}

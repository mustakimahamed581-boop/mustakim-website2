import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Heart, Share2, GitCompare, Star, Shield, Minus, Plus } from 'lucide-react'
import { useCatalogStore } from '../store/catalogStore'
import { useCartStore } from '../store/cartStore'
import { useWishlistStore } from '../store/wishlistStore'
import { useUserStore } from '../store/userStore'
import { useUiStore } from '../store/uiStore'
import { formatBdt, discountPercent } from '../utils/format'
import { playSound } from '../services/sound'
import { useSeo } from '../hooks/useSeo'
import { useToast } from '../hooks/useToast'
import ProductCard from '../components/product/ProductCard'
import Button from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import AdSlot from '../components/ads/AdSlot'

const TABS = ['Description', 'Specifications', 'Features', 'Warranty', 'Reviews', 'Questions']

export default function ProductDetails() {
  const { id } = useParams()
  const product = useCatalogStore((s) => s.products.find((p) => p.id === id))
  const products = useCatalogStore((s) => s.products)
  const allReviews = useCatalogStore((s) => s.reviews)
  const allQuestions = useCatalogStore((s) => s.questions)
  const reviews = useMemo(
    () => (allReviews || []).filter((r) => r.productId === id && r.status === 'approved'),
    [allReviews, id],
  )
  const questions = useMemo(
    () => (allQuestions || []).filter((q) => q.productId === id),
    [allQuestions, id],
  )
  const upsertReview = useCatalogStore((s) => s.upsertReview)
  const addQuestion = useCatalogStore((s) => s.addQuestion)
  const addItem = useCartStore((s) => s.addItem)
  const toggleWish = useWishlistStore((s) => s.toggle)
  const wished = useWishlistStore((s) => s.ids.includes(id))
  const toggleCompare = useUiStore((s) => s.toggleCompare)
  const compared = useUiStore((s) => s.compareIds.includes(id))
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  const viewProduct = useUserStore((s) => s.viewProduct)
  const recentIds = useUserStore((s) => s.recentlyViewed)
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId))
  const toast = useToast()
  const navigate = useNavigate()

  useSeo({ title: product?.name, description: product?.description })
  useEffect(() => { if (id) viewProduct(id) }, [id, viewProduct])
  useEffect(() => {
    document.documentElement.scrollTop = 0
    document.body.scrollTop = 0
    window.scrollTo(0, 0)
    const main = document.querySelector('main')
    if (main) main.scrollTop = 0
  }, [id])

  const [img, setImg] = useState(0)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState('Description')
  const [variant, setVariant] = useState({})
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: '', comment: '' })
  const [qText, setQText] = useState('')

  useEffect(() => {
    if (!product) return
    setImg(0)
    setVariant({
      color: product.variants?.color?.[0] || '',
      storage: product.variants?.storage?.[0] || '',
      ram: product.variants?.ram?.[0] || '',
      size: product.variants?.size?.[0] || '',
      model: product.variants?.model?.[0] || '',
    })
  }, [product])

  const variantStr = useMemo(
    () => Object.values(variant).filter(Boolean).join(' / '),
    [variant],
  )

  if (!product) return <EmptyState title="Product unavailable" message="This item may have been removed." to="/shop" />

  const off = discountPercent(product.price, product.salePrice)
  const related = products.filter((p) => p.categoryId === product.categoryId && p.id !== product.id).slice(0, 4)
  const recommended = products.filter((p) => p.flags.recommended && p.id !== product.id).slice(0, 4)
  const recent = recentIds.map((rid) => products.find((p) => p.id === rid)).filter((p) => p && p.id !== product.id).slice(0, 4)

  const add = () => {
    if (product.stock <= 0) return toast({ type: 'error', title: 'Out of stock' })
    addItem({ ...product, variant: variantStr }, qty)
    playSound('cart', soundEnabled)
    toast({ type: 'success', title: 'Added to cart' })
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <p className="text-xs text-white/40 mb-4">
        Home / {product.brand} / {product.name}
      </p>
      <div className="grid lg:grid-cols-2 gap-8">
        <div>
          <div className="rounded-2xl bg-[#111] overflow-hidden aspect-square relative">
            <img
              src={product.images[img]}
              alt={product.name}
              className="w-full h-full object-cover cursor-zoom-in"
              onClick={() => window.open(product.images[img], '_blank')}
            />
          </div>
          <div className="flex gap-2 mt-3 overflow-x-auto no-scrollbar">
            {(product.images || []).slice(0, 10).map((src, i) => (
              <button key={`${src}-${i}`} onClick={() => setImg(i)} className={`w-16 h-16 rounded-lg overflow-hidden border shrink-0 ${i === img ? 'border-[#F5A623]' : 'border-white/10'}`}>
                <img src={src} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
          {product.video ? (
            <div className="mt-4 rounded-2xl overflow-hidden bg-black aspect-video">
              {/youtube\.com|youtu\.be/.test(product.video) ? (
                <iframe
                  title="Product video"
                  className="w-full h-full"
                  src={product.video.replace('watch?v=', 'embed/').replace('youtu.be/', 'www.youtube.com/embed/')}
                  allow="accelerometer; autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video src={product.video} controls className="w-full h-full" />
              )}
            </div>
          ) : null}
        </div>
        <div>
          <p className="text-sm text-white/50">{product.brand}</p>
          <h1 className="text-3xl font-bold mt-1">{product.name}</h1>
          <p className="text-sm text-amber-400 mt-2 flex items-center gap-2">
            <Star size={14} fill="currentColor" /> {product.rating} ({product.reviewCount} reviews)
          </p>
          <div className="flex items-baseline gap-3 mt-4">
            <span className="text-3xl font-extrabold text-[#F5A623]">{formatBdt(product.salePrice)}</span>
            {off > 0 ? <span className="text-white/40 line-through">{formatBdt(product.price)}</span> : null}
            {off > 0 ? <span className="text-emerald-400 text-sm">{off}% OFF</span> : null}
          </div>
          <dl className="grid grid-cols-2 gap-2 text-sm mt-4 text-white/70">
            <div>SKU: {product.sku}</div>
            <div>Stock: {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}</div>
            <div className="col-span-2 flex items-center gap-1"><Shield size={14} className="text-[#F5A623]" /> {product.warranty}</div>
          </dl>
          {Object.entries(product.variants || {}).map(([key, opts]) =>
            opts?.length ? (
              <div key={key} className="mt-4">
                <p className="text-sm capitalize mb-2">{key}</p>
                <div className="flex flex-wrap gap-2">
                  {opts.map((o) => (
                    <button
                      key={o}
                      onClick={() => setVariant((v) => ({ ...v, [key]: o }))}
                      className={`px-3 py-1.5 rounded-lg text-sm border ${variant[key] === o ? 'border-[#F5A623] text-[#F5A623]' : 'border-white/15'}`}
                    >
                      {o}
                    </button>
                  ))}
                </div>
              </div>
            ) : null,
          )}
          <div className="flex items-center gap-3 mt-5">
            <div className="flex items-center rounded-xl border border-white/15">
              <button className="p-2" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease"><Minus size={14} /></button>
              <span className="w-8 text-center">{qty}</span>
              <button className="p-2" onClick={() => setQty((q) => q + 1)} aria-label="Increase"><Plus size={14} /></button>
            </div>
            <Button onClick={add} className="flex-1">Add to Cart</Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                add()
                playSound('buy', soundEnabled)
                navigate('/checkout')
              }}
            >
              Buy Now
            </Button>
          </div>
          <div className="flex gap-4 mt-4 text-sm text-white/60">
            <button onClick={() => toggleWish(product.id)} className="flex items-center gap-1 hover:text-[#F5A623]">
              <Heart size={14} fill={wished ? 'currentColor' : 'none'} /> Wishlist
            </button>
            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href)
                toast({ type: 'success', title: 'Link copied' })
              }}
              className="flex items-center gap-1 hover:text-[#F5A623]"
            >
              <Share2 size={14} /> Share
            </button>
            <button onClick={() => toggleCompare(product.id)} className={`flex items-center gap-1 ${compared ? 'text-[#F5A623]' : ''}`}>
              <GitCompare size={14} /> Compare
            </button>
          </div>
        </div>
      </div>

      <AdSlot placement="product" />
      <div className="mt-10">
        <div className="flex gap-2 overflow-x-auto no-scrollbar border-b border-white/10">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-sm whitespace-nowrap ${tab === t ? 'text-[#F5A623] border-b-2 border-[#F5A623]' : 'text-white/50'}`}>
              {t}
            </button>
          ))}
        </div>
        <div className="py-6 text-sm text-white/75 leading-relaxed">
          {tab === 'Description' && <p>{product.description}</p>}
          {tab === 'Specifications' && (
            <table className="w-full max-w-xl">
              <tbody>
                {product.specifications.map((s) => (
                  <tr key={s.label} className="border-b border-white/5">
                    <td className="py-2 text-white/50 w-40">{s.label}</td>
                    <td>{s.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {tab === 'Features' && <ul className="list-disc pl-5 space-y-1">{product.features.map((f) => <li key={f}>{f}</li>)}</ul>}
          {tab === 'Warranty' && <p>{product.warranty}</p>}
          {tab === 'Reviews' && (
            <div className="space-y-4">
              {reviews.map((r) => (
                <div key={r.id} className="rounded-xl bg-[#111] p-4">
                  <p className="font-medium">{r.title} <span className="text-amber-400 text-xs">{'★'.repeat(r.rating)}</span></p>
                  <p className="text-xs text-white/40">{r.userName} {r.verified ? '· Verified Purchase' : ''}</p>
                  <p className="mt-2">{r.comment}</p>
                </div>
              ))}
              <form
                className="rounded-xl bg-[#111] p-4 space-y-2 max-w-lg"
                onSubmit={(e) => {
                  e.preventDefault()
                  upsertReview({
                    productId: product.id,
                    userId: user?.id || 'guest',
                    userName: user?.name || 'Guest',
                    rating: reviewForm.rating,
                    title: reviewForm.title,
                    comment: reviewForm.comment,
                    images: [],
                    verified: false,
                    status: 'pending',
                    createdAt: new Date().toISOString(),
                  })
                  setReviewForm({ rating: 5, title: '', comment: '' })
                  toast({ type: 'info', title: 'Review submitted for moderation' })
                }}
              >
                <p className="font-semibold">Write a review</p>
                <select className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={reviewForm.rating} onChange={(e) => setReviewForm((f) => ({ ...f, rating: Number(e.target.value) }))}>
                  {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} stars</option>)}
                </select>
                <input required className="w-full bg-[#1A1A1A] p-2 rounded-lg" placeholder="Title" value={reviewForm.title} onChange={(e) => setReviewForm((f) => ({ ...f, title: e.target.value }))} />
                <textarea required className="w-full bg-[#1A1A1A] p-2 rounded-lg" placeholder="Comment" value={reviewForm.comment} onChange={(e) => setReviewForm((f) => ({ ...f, comment: e.target.value }))} />
                <Button type="submit">Submit review</Button>
              </form>
            </div>
          )}
          {tab === 'Questions' && (
            <div className="space-y-3">
              {questions.map((q) => (
                <div key={q.id} className="rounded-xl bg-[#111] p-4">
                  <p className="font-medium">Q: {q.question}</p>
                  <p className="text-white/60 mt-1">A: {q.answer || 'Awaiting answer'}</p>
                </div>
              ))}
              <form
                className="flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault()
                  addQuestion({ productId: product.id, userName: user?.name || 'Guest', question: qText, answer: '', createdAt: new Date().toISOString() })
                  setQText('')
                  toast({ title: 'Question posted' })
                }}
              >
                <input className="flex-1 bg-[#1A1A1A] p-2 rounded-lg" value={qText} onChange={(e) => setQText(e.target.value)} placeholder="Ask a question" />
                <Button type="submit">Ask</Button>
              </form>
            </div>
          )}
        </div>
      </div>

      {related.length ? (
        <section className="mt-8">
          <h2 className="text-xl font-bold mb-4">Related Products</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{related.map((p) => <ProductCard key={p.id} product={p} compact />)}</div>
        </section>
      ) : null}
      {recommended.length ? (
        <section className="mt-8">
          <h2 className="text-xl font-bold mb-4">Recommended</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{recommended.map((p) => <ProductCard key={p.id} product={p} compact />)}</div>
        </section>
      ) : null}
      {recent.length ? (
        <section className="mt-8 mb-8">
          <h2 className="text-xl font-bold mb-4">Recently Viewed</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{recent.map((p) => <ProductCard key={p.id} product={p} compact />)}</div>
        </section>
      ) : null}
    </div>
  )
}

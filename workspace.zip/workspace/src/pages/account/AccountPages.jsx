import { Link, useNavigate, useParams } from 'react-router-dom'
import { useUserStore } from '../../store/userStore'
import { useOrderStore } from '../../store/orderStore'
import { useWishlistStore } from '../../store/wishlistStore'
import { useCatalogStore } from '../../store/catalogStore'
import { useCartStore } from '../../store/cartStore'
import { formatBdt, formatDate, initials } from '../../utils/format'
import { ORDER_STATUSES, STATUS_LABELS, PAYMENT_LABELS } from '../../data/constants'
import ProductCard from '../../components/product/ProductCard'
import Button from '../../components/ui/Button'
import EmptyState from '../../components/ui/EmptyState'
import { Package } from 'lucide-react'
import { useState } from 'react'
import { useToast } from '../../hooks/useToast'
import { useSeo } from '../../hooks/useSeo'
import { divisions, getDistricts, getUpazilas } from '../../data/bdLocations'

export function AccountHome() {
  useSeo({ title: 'Account' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId) || null)
  const allOrders = useOrderStore((s) => s.orders)
  const orders = allOrders.filter((o) => o.userId === user?.id)
  const wish = useWishlistStore((s) => s.ids.length)
  const notes = useUserStore((s) => s.notifications)
  const unread = notes.filter((n) => n.userId === user?.id && !n.read).length
  const cards = [
    ['Total Orders', orders.length],
    ['Pending', orders.filter((o) => ['pending', 'confirmed', 'processing'].includes(o.status)).length],
    ['Delivered', orders.filter((o) => o.status === 'delivered').length],
    ['Wishlist', wish],
  ]
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map(([l, v]) => (
          <div key={l} className="rounded-2xl bg-[#111] border border-white/8 p-4">
            <p className="text-xs text-white/50">{l}</p>
            <p className="text-2xl font-bold text-[#F5A623]">{v}</p>
          </div>
        ))}
      </div>
      {unread ? <p className="text-sm text-white/50 mt-4">{unread} unread notifications</p> : null}
    </div>
  )
}

export function AccountProfile() {
  useSeo({ title: 'Profile' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId))
  const updateProfile = useUserStore((s) => s.updateProfile)
  const toast = useToast()
  const [form, setForm] = useState({ name: user.name, phone: user.phone, email: user.email, photo: user.photo || '' })
  return (
    <div className="rounded-2xl bg-[#111] p-5 max-w-lg space-y-3">
      <h1 className="text-xl font-bold">My Profile</h1>
      <div className="w-16 h-16 rounded-full gold-gradient grid place-items-center text-black font-bold">{initials(form.name)}</div>
      <input className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <input className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
      <input className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
      <p className="text-xs text-white/40">Member since {formatDate(user.registeredAt)}</p>
      <Button onClick={() => { updateProfile(form); toast({ type: 'success', title: 'Profile saved' }) }}>Save</Button>
    </div>
  )
}

export function AccountOrders() {
  useSeo({ title: 'My Orders' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId) || null)
  const allOrders = useOrderStore((s) => s.orders)
  const orders = allOrders.filter((o) => o.userId === user?.id)
  const addItem = useCartStore((s) => s.addItem)
  const setStatus = useOrderStore((s) => s.setStatus)
  const navigate = useNavigate()
  if (!orders.length) return <EmptyState icon={Package} title="No orders yet" message="Your purchases will show up here." to="/shop" />
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-bold">My Orders</h1>
      {orders.map((o) => (
        <div key={o.id} className="rounded-2xl bg-[#111] border border-white/8 p-4">
          <div className="flex flex-wrap justify-between gap-2">
            <p className="font-mono text-sm">{o.id}</p>
            <span className="text-xs px-2 py-1 rounded-full bg-white/10">{STATUS_LABELS[o.status]}</span>
          </div>
          <p className="text-xs text-white/40 mt-1">{formatDate(o.createdAt)} · {PAYMENT_LABELS[o.paymentMethod]} · {formatBdt(o.totals.grandTotal)}</p>
          <p className="text-sm mt-2">{o.items.map((i) => i.name).join(', ')}</p>
          <div className="flex flex-wrap gap-2 mt-3">
            <Link to={`/account/orders/${o.id}`}><Button variant="dark" className="!py-1.5">View / Track</Button></Link>
            {['pending', 'confirmed'].includes(o.status) ? (
              <Button variant="danger" className="!py-1.5" onClick={() => setStatus(o.id, 'cancelled')}>Cancel</Button>
            ) : null}
            <Button
              variant="outline"
              className="!py-1.5"
              onClick={() => {
                o.items.forEach((i) => addItem({ ...i, id: i.productId, images: [i.image] }, i.qty))
                navigate('/checkout')
              }}
            >
              Reorder
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

export function AccountOrderDetail() {
  const { id } = useParams()
  const order = useOrderStore((s) => s.orders.find((o) => o.id === id))
  useSeo({ title: id })
  if (!order) return <p>Order not found.</p>
  const idx = ORDER_STATUSES.indexOf(order.status)
  return (
    <div className="rounded-2xl bg-[#111] p-5">
      <div className="flex justify-between">
        <h1 className="font-mono font-bold">{order.id}</h1>
        <Link to={`/account/orders/${id}/invoice`} className="text-sm text-[#F5A623]">Invoice</Link>
      </div>
      <div className="flex gap-1 overflow-x-auto mt-6 pb-2">
        {ORDER_STATUSES.filter((s) => !['cancelled', 'returned'].includes(s)).map((s, i) => (
          <div key={s} className={`min-w-[90px] text-center text-[10px] ${i <= idx ? 'text-[#F5A623]' : 'text-white/30'}`}>
            <div className={`h-1.5 rounded-full mb-1 ${i <= idx ? 'bg-[#F5A623]' : 'bg-white/10'}`} />
            {STATUS_LABELS[s]}
          </div>
        ))}
      </div>
      <ul className="mt-4 space-y-2 text-sm">
        {order.items.map((i) => (
          <li key={i.productId} className="flex justify-between">
            <span>{i.qty} × {i.name}</span>
            <span>{formatBdt(i.salePrice * i.qty)}</span>
          </li>
        ))}
      </ul>
      <p className="mt-4 font-bold">Total {formatBdt(order.totals.grandTotal)}</p>
      <p className="text-xs text-white/40 mt-2">Payment {order.paymentStatus} · Courier {order.courier?.trackingCode || '—'}</p>
      <ol className="mt-4 text-xs text-white/50 space-y-1">
        {order.timeline?.map((t) => (
          <li key={t.at}>{formatDate(t.at)} — {STATUS_LABELS[t.status]}</li>
        ))}
      </ol>
    </div>
  )
}

export function AccountWishlist() {
  return (
    <div>
      <h1 className="text-xl font-bold mb-3">Wishlist</h1>
      <AccountWishGrid />
    </div>
  )
}

function AccountWishGrid() {
  const ids = useWishlistStore((s) => s.ids)
  const allProducts = useCatalogStore((s) => s.products)
  const products = allProducts.filter((p) => ids.includes(p.id))
  if (!products.length) return <EmptyState title="No saved items" message="Save gadgets from the shop." to="/shop" />
  return <div className="grid grid-cols-2 md:grid-cols-3 gap-3">{products.map((p) => <ProductCard key={p.id} product={p} compact />)}</div>
}

export function AccountAddresses() {
  useSeo({ title: 'Addresses' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId))
  const upsertAddress = useUserStore((s) => s.upsertAddress)
  const deleteAddress = useUserStore((s) => s.deleteAddress)
  const toast = useToast()
  const [form, setForm] = useState({
    id: '', label: 'Home', name: user.name, phone: user.phone, division: 'Dhaka', district: 'Dhaka', upazila: 'Dhanmondi', address: '', isDefault: true,
  })
  return (
    <div className="grid lg:grid-cols-2 gap-4">
      <div className="space-y-2">
        <h1 className="text-xl font-bold">Saved Addresses</h1>
        {(user.addresses || []).map((a) => (
          <div key={a.id} className="rounded-xl bg-[#111] p-3 text-sm">
            <p className="font-medium">{a.label} {a.isDefault ? '· Default' : ''}</p>
            <p className="text-white/50">{a.address}, {a.upazila}, {a.district}</p>
            <div className="flex gap-2 mt-2">
              <button className="text-[#F5A623]" onClick={() => setForm(a)}>Edit</button>
              <button className="text-red-400" onClick={() => deleteAddress(a.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      <form
        className="rounded-xl bg-[#111] p-4 space-y-2"
        onSubmit={(e) => {
          e.preventDefault()
          upsertAddress(form)
          toast({ type: 'success', title: 'Address saved' })
        }}
      >
        <select className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })}>
          <option>Home</option><option>Office</option><option>Other</option>
        </select>
        <input className="w-full bg-[#1A1A1A] p-2 rounded-lg" placeholder="Full address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        <select className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.division} onChange={(e) => setForm({ ...form, division: e.target.value, district: getDistricts(e.target.value)[0] })}>
          {divisions.map((d) => <option key={d}>{d}</option>)}
        </select>
        <select className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value, upazila: getUpazilas(e.target.value)[0] })}>
          {getDistricts(form.division).map((d) => <option key={d}>{d}</option>)}
        </select>
        <select className="w-full bg-[#1A1A1A] p-2 rounded-lg" value={form.upazila} onChange={(e) => setForm({ ...form, upazila: e.target.value })}>
          {getUpazilas(form.district).map((d) => <option key={d}>{d}</option>)}
        </select>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} /> Default</label>
        <Button type="submit">Save address</Button>
      </form>
    </div>
  )
}

export function AccountNotifications() {
  useSeo({ title: 'Notifications' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId) || null)
  const notes = useUserStore((s) => s.notifications)
  const list = notes.filter((n) => n.userId === user?.id)
  const markRead = useUserStore((s) => s.markRead)
  const markAllRead = useUserStore((s) => s.markAllRead)
  if (!list.length) return <EmptyState title="No notifications" message="Order updates and offers will appear here." />
  return (
    <div>
      <div className="flex justify-between mb-3">
        <h1 className="text-xl font-bold">Notifications</h1>
        <button className="text-sm text-[#F5A623]" onClick={() => markAllRead(user.id)}>Mark all read</button>
      </div>
      <div className="space-y-2">
        {list.map((n) => (
          <button key={n.id} onClick={() => markRead(n.id)} className={`w-full text-left rounded-xl p-3 ${n.read ? 'bg-[#111]' : 'bg-[#1A1408] border border-[#F5A623]/30'}`}>
            <p className="font-medium text-sm">{n.title}</p>
            <p className="text-xs text-white/50">{n.body}</p>
          </button>
        ))}
      </div>
    </div>
  )
}

export function AccountRecent() {
  const ids = useUserStore((s) => s.recentlyViewed)
  const allProducts = useCatalogStore((s) => s.products)
  const products = ids.map((id) => allProducts.find((p) => p.id === id)).filter(Boolean)
  return (
    <div>
      <h1 className="text-xl font-bold mb-3">Recently Viewed</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">{products.map((p) => <ProductCard key={p.id} product={p} compact />)}</div>
    </div>
  )
}

export function AccountSettings() {
  useSeo({ title: 'Account Settings' })
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId))
  const updateProfile = useUserStore((s) => s.updateProfile)
  const [pw, setPw] = useState('')
  const toast = useToast()
  return (
    <div className="rounded-2xl bg-[#111] p-5 max-w-md space-y-3">
      <h1 className="text-xl font-bold">Account Settings</h1>
      <p className="text-sm text-white/50">Payment methods are collected at checkout. Saved cards require a connected gateway.</p>
      <input type="password" className="w-full bg-[#1A1A1A] p-2 rounded-lg" placeholder="New password" value={pw} onChange={(e) => setPw(e.target.value)} />
      <Button onClick={() => { if (pw.length < 6) return toast({ type: 'error', title: 'Min 6 characters' }); updateProfile({ password: pw }); toast({ type: 'success', title: 'Password updated' }) }}>Update password</Button>
      <p className="text-xs text-white/30">Logged in as {user.email}</p>
    </div>
  )
}

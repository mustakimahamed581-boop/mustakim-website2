import { useState } from 'react'
import { NavLink, Outlet, Navigate, useNavigate } from 'react-router-dom'
import { useUserStore } from '../../store/userStore'
import { LayoutDashboard, Package, Heart, MapPin, User, Bell, Settings, LogOut, Eye } from 'lucide-react'

const links = [
  { to: '/account', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/account/profile', label: 'My Profile', icon: User },
  { to: '/account/orders', label: 'My Orders', icon: Package },
  { to: '/account/wishlist', label: 'Wishlist', icon: Heart },
  { to: '/account/addresses', label: 'Addresses', icon: MapPin },
  { to: '/account/notifications', label: 'Notifications', icon: Bell },
  { to: '/account/recent', label: 'Recently Viewed', icon: Eye },
  { to: '/account/settings', label: 'Settings', icon: Settings },
]

export default function AccountLayout() {
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId) || null)
  const logout = useUserStore((s) => s.logout)
  const navigate = useNavigate()
  const [ask, setAsk] = useState(false)
  if (!user) return <Navigate to="/login" replace state={{ from: '/account' }} />
  return (
    <div className="max-w-6xl mx-auto px-4 py-6 grid lg:grid-cols-[220px_1fr] gap-6">
      <aside className="rounded-2xl bg-[#111] border border-white/8 p-3 h-fit">
        <p className="px-2 py-2 text-sm">Hi, <strong>{user.name.split(' ')[0]}</strong></p>
        <nav className="flex lg:flex-col gap-1 overflow-x-auto no-scrollbar">
          {links.map((l) => {
            const Icon = l.icon
            return (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2 rounded-xl text-sm whitespace-nowrap ${isActive ? 'bg-[#F5A623] text-black' : 'hover:bg-white/5'}`
                }
              >
                <Icon size={16} /> {l.label}
              </NavLink>
            )
          })}
          <button
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-red-400"
            onClick={() => setAsk(true)}
          >
            <LogOut size={16} /> Logout
          </button>
        </nav>
      </aside>
      <div className="min-w-0">
        <Outlet />
      </div>
      {ask ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4">
          <div className="bg-[#111] rounded-2xl p-5 max-w-sm w-full border border-white/10">
            <p className="font-semibold">Are you sure you want to logout?</p>
            <div className="flex gap-2 mt-4">
              <button className="flex-1 rounded-xl bg-red-600 py-2" onClick={() => { logout(); navigate('/login') }}>Yes</button>
              <button className="flex-1 rounded-xl bg-white/10 py-2" onClick={() => setAsk(false)}>Cancel</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}

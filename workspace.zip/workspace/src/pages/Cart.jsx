import { Link } from 'react-router-dom'
import { Minus, Plus, Trash2, Heart } from 'lucide-react'
import { useCartStore } from '../store/cartStore'
import { useWishlistStore } from '../store/wishlistStore'
import { useCatalogStore } from '../store/catalogStore'
import { calculateOrderTotals, getDeliveryCharge } from '../utils/calculate'
import { validateCoupon } from '../utils/coupon'
import { formatBdt } from '../utils/format'
import { useSettingsStore } from '../store/settingsStore'
import EmptyState from '../components/ui/EmptyState'
import Button from '../components/ui/Button'
import { useSeo } from '../hooks/useSeo'
import { useToast } from '../hooks/useToast'
import { ShoppingBag } from 'lucide-react'
import { useState } from 'react'
import AdSlot from '../components/ads/AdSlot'

export default function Cart() {
  useSeo({ title: 'Cart' })
  const items = useCartStore((s) => s.items)
  const saved = useCartStore((s) => s.saved)
  const setQty = useCartStore((s) => s.setQty)
  const removeItem = useCartStore((s) => s.removeItem)
  const saveForLater = useCartStore((s) => s.saveForLater)
  const moveSavedToCart = useCartStore((s) => s.moveSavedToCart)
  const couponCode = useCartStore((s) => s.couponCode)
  const setCoupon = useCartStore((s) => s.setCoupon)
  const toggleWish = useWishlistStore((s) => s.toggle)
  const coupons = useCatalogStore((s) => s.coupons)
  const deliverySettings = useSettingsStore((s) => s.settings.delivery)
  const toast = useToast()
  const [code, setCode] = useState(couponCode)

  const coupon = coupons.find((c) => c.code.toLowerCase() === couponCode.toLowerCase())
  const subtotal = items.reduce((n, i) => n + i.salePrice * i.qty, 0)
  const valid = coupon ? validateCoupon(coupon, { subtotal }) : { ok: false }
  const totals = calculateOrderTotals({
    items,
    coupon: valid.ok ? coupon : null,
    deliveryCharge: getDeliveryCharge(deliverySettings, 'Dhaka'),
  })

  if (!items.length && !saved.length) {
    return <EmptyState icon={ShoppingBag} title="Your cart is empty" message="Browse premium gadgets and add them here." to="/shop" action="Go to shop" />
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 grid lg:grid-cols-[1fr_320px] gap-6">
      <div className="space-y-3">
        <h1 className="text-2xl font-bold mb-4">Cart</h1>
        <AdSlot placement="cart" />
        {items.map((i) => (
          <div key={`${i.productId}-${i.variant}`} className="rounded-2xl bg-[#111] border border-white/8 p-3 flex gap-3">
            <img src={i.image} alt="" className="w-24 h-24 rounded-xl object-cover" />
            <div className="flex-1">
              <Link to={`/product/${i.productId}`} className="font-medium">{i.name}</Link>
              <p className="text-xs text-white/40">{i.variant}</p>
              <p className="text-[#F5A623] mt-1">{formatBdt(i.salePrice)}</p>
              <div className="flex items-center gap-2 mt-2">
                <button className="w-8 h-8 rounded bg-white/10" onClick={() => setQty(i.productId, i.variant, i.qty - 1)}><Minus size={12} className="mx-auto" /></button>
                <span>{i.qty}</span>
                <button className="w-8 h-8 rounded bg-white/10" onClick={() => setQty(i.productId, i.variant, i.qty + 1)}><Plus size={12} className="mx-auto" /></button>
                <button className="ml-auto text-white/50" onClick={() => { toggleWish(i.productId); saveForLater(i.productId, i.variant) }} aria-label="Move to wishlist"><Heart size={16} /></button>
                <button className="text-white/50" onClick={() => saveForLater(i.productId, i.variant)}>Save</button>
                <button className="text-red-400" onClick={() => removeItem(i.productId, i.variant)}><Trash2 size={16} /></button>
              </div>
            </div>
          </div>
        ))}
        {saved.length ? (
          <div className="pt-4">
            <h2 className="font-semibold mb-2">Saved for later</h2>
            {saved.map((i) => (
              <div key={`s-${i.productId}`} className="flex items-center gap-3 py-2">
                <img src={i.image} alt="" className="w-12 h-12 rounded object-cover" />
                <span className="flex-1 text-sm">{i.name}</span>
                <Button variant="dark" className="!py-1" onClick={() => moveSavedToCart(i.productId, i.variant)}>Move to cart</Button>
              </div>
            ))}
          </div>
        ) : null}
      </div>
      <aside className="rounded-2xl bg-[#111] border border-white/8 p-4 h-fit space-y-2">
        <h2 className="font-semibold">Summary</h2>
        <div className="flex gap-2">
          <input className="flex-1 bg-[#1A1A1A] rounded-lg px-3" value={code} onChange={(e) => setCode(e.target.value)} placeholder="Coupon code" />
          <Button
            variant="outline"
            onClick={() => {
              const c = coupons.find((x) => x.code.toLowerCase() === code.trim().toLowerCase())
              const v = validateCoupon(c, { subtotal })
              if (!v.ok) return toast({ type: 'error', title: v.message })
              setCoupon(c.code)
              toast({ type: 'success', title: 'Coupon applied' })
            }}
          >
            Apply
          </Button>
        </div>
        <Row label="Subtotal" value={formatBdt(totals.subtotal)} />
        <Row label="Coupon" value={`- ${formatBdt(totals.couponDiscount)}`} />
        <Row label="Delivery (Dhaka est.)" value={formatBdt(totals.delivery)} />
        <Row label="Grand total" value={formatBdt(totals.grandTotal)} bold />
        <Link to="/checkout"><Button className="w-full mt-2">Checkout</Button></Link>
        <Link to="/shop" className="block text-center text-sm text-white/50">Continue shopping</Link>
      </aside>
    </div>
  )
}

function Row({ label, value, bold }) {
  return (
    <div className={`flex justify-between text-sm ${bold ? 'font-bold text-lg pt-2 border-t border-white/10' : ''}`}>
      <span className="text-white/60">{label}</span>
      <span>{value}</span>
    </div>
  )
}

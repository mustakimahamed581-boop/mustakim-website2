import { useMemo } from 'react'
import { useCatalogStore } from '../store/catalogStore'
import ProductCard from '../components/product/ProductCard'
import { useSeo } from '../hooks/useSeo'
import EmptyState from '../components/ui/EmptyState'

export default function Deals() {
  useSeo({ title: 'Deals' })
  const allProducts = useCatalogStore((s) => s.products)
  const flash = useCatalogStore((s) => s.flashSale)
  const products = useMemo(() => (allProducts || []).filter((p) => p.enabled), [allProducts])
  const expired = flash.end && Date.now() > new Date(flash.end).getTime()
  const deals = useMemo(() => {
    const ids = new Set(flash.productIds || [])
    return products.filter((p) => p.salePrice < p.price || ids.has(p.id) || p.flags.flashSale)
  }, [products, flash])
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold">Deals & Flash Sale</h1>
      <p className="text-white/50 text-sm mt-1">{flash.title} — {expired ? 'This flash sale has expired.' : flash.subtitle}</p>
      {deals.length === 0 ? (
        <EmptyState title="No deals right now" message="Check back soon for flash offers." to="/shop" />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mt-6">
          {deals.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}

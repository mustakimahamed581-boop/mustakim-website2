import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'

import {
  Truck, BadgeCheck, ShieldCheck, CreditCard, RefreshCcw, ChevronLeft, ChevronRight, ArrowRight,
} from 'lucide-react'
import { iconByName } from '../utils/icons'
import { useCatalogStore } from '../store/catalogStore'
import { useSeo } from '../hooks/useSeo'
import ProductCard from '../components/product/ProductCard'
import QuickView from '../components/product/QuickView'
import Button from '../components/ui/Button'
import AdSlot from '../components/ads/AdSlot'
import { formatBdt } from '../utils/format'

const trust = [
  { icon: Truck, title: 'Fast Delivery', sub: 'Across Bangladesh' },
  { icon: CreditCard, title: 'Cash on Delivery', sub: 'Available' },
  { icon: BadgeCheck, title: '100% Original', sub: 'Products' },
  { icon: ShieldCheck, title: 'Secure Payment', sub: 'bKash / Nagad / Card' },
  { icon: RefreshCcw, title: 'Easy Return', sub: 'Within 7 days' },
]

export default function Home() {
  useSeo({ title: 'Home' })
  const allProducts = useCatalogStore((s) => s.products)
  const allCategories = useCatalogStore((s) => s.categories)
  const heroSlides = useCatalogStore((s) => s.heroSlides)
  const allBanners = useCatalogStore((s) => s.banners)
  const flash = useCatalogStore((s) => s.flashSale)
  const products = useMemo(() => (allProducts || []).filter((p) => p.enabled), [allProducts])
  const categories = useMemo(
    () => (allCategories || []).filter((c) => c.enabled).sort((a, b) => a.order - b.order),
    [allCategories],
  )
  const slides = useMemo(
    () => (heroSlides || []).filter((h) => h.enabled).sort((a, b) => a.order - b.order),
    [heroSlides],
  )
  const banners = useMemo(
    () => (allBanners || []).filter((b) => b.enabled && b.type === 'offer'),
    [allBanners],
  )
  const [idx, setIdx] = useState(0)
  const [qv, setQv] = useState(null)

  useEffect(() => {
    if (slides.length < 2) return
    const t = setInterval(() => setIdx((i) => (i + 1) % slides.length), 6000)
    return () => clearInterval(t)
  }, [slides.length])

  const slide = slides[idx] || slides[0]
  const featured = products.filter((p) => p.flags.featured).slice(0, 8)
  const trending = products.filter((p) => p.flags.trending).slice(0, 8)
  const flashProducts = useMemo(
    () => products.filter((p) => flash.productIds?.includes(p.id)),
    [products, flash],
  )

  return (
    <div>
      {slide ? (
        <section className="relative overflow-hidden" style={{ background: slide.background }}>
          <div className="absolute -right-20 top-10 w-80 h-80 rounded-full bg-[#F5A623]/20 blur-3xl hero-glow pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 py-10 sm:py-16 grid lg:grid-cols-2 gap-8 items-center">
            <div>
              {slide.badge ? (
                <span className="inline-block text-xs font-bold tracking-widest text-[#F5A623] border border-[#F5A623]/40 rounded-full px-3 py-1 mb-4">
                  {slide.badge}
                </span>
              ) : null}
              <h1 className="text-4xl sm:text-6xl font-extrabold leading-tight">
                {slide.heading}
                <span className="block text-gold-gradient">{slide.headingAccent}</span>
              </h1>
              <p className="text-white/70 mt-4 max-w-md">{slide.subtitle}</p>
              <div className="flex flex-wrap gap-3 mt-6">
                <Link to={slide.buttonUrl || '/shop'}><Button className="px-6">{slide.buttonText}</Button></Link>
                <Link to={slide.secondaryUrl || '/deals'}><Button variant="outline">{slide.secondaryText}</Button></Link>
              </div>
            </div>
            <div className="relative">
              <img src={slide.image} alt="" className="w-full max-h-[420px] object-contain drop-shadow-2xl" />
            </div>
          </div>
          {slides.length > 1 ? (
            <div className="absolute bottom-4 inset-x-0 flex justify-center gap-2">
              {slides.map((s, i) => (
                <button key={s.id} aria-label={`Slide ${i + 1}`} onClick={() => setIdx(i)} className={`h-1.5 rounded-full ${i === idx ? 'w-8 bg-[#F5A623]' : 'w-3 bg-white/30'}`} />
              ))}
            </div>
          ) : null}
          {slides.length > 1 ? (
            <>
              <button aria-label="Prev" className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40" onClick={() => setIdx((i) => (i - 1 + slides.length) % slides.length)}>
                <ChevronLeft />
              </button>
              <button aria-label="Next" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40" onClick={() => setIdx((i) => (i + 1) % slides.length)}>
                <ChevronRight />
              </button>
            </>
          ) : null}
        </section>
      ) : null}

      <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 -mt-4 relative z-10">
        {trust.map((t) => (
          <div key={t.title} className="rounded-2xl bg-[#111] border border-white/8 p-3 flex gap-3 items-center">
            <t.icon className="text-[#F5A623] shrink-0" size={20} />
            <div>
              <p className="text-xs font-semibold">{t.title}</p>
              <p className="text-[11px] text-white/50">{t.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="flex items-end justify-between mb-5">
          <div>
            <h2 className="text-2xl font-bold">Shop by Category</h2>
            <p className="text-white/50 text-sm">Find the perfect gadget for your needs</p>
          </div>
          <Link to="/categories" className="text-sm text-[#F5A623] flex items-center gap-1">View all <ArrowRight size={14} /></Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {categories.map((c) => {
            const Icon = iconByName(c.icon)
            const count = products.filter((p) => p.categoryId === c.id).length
            return (
              <Link key={c.id} to={`/categories/${c.slug}`} className="rounded-2xl bg-[#111] border border-white/8 p-3 hover:border-[#F5A623]/50 transition text-center">
                <div className="w-14 h-14 mx-auto rounded-xl overflow-hidden bg-[#1A1A1A] mb-2 grid place-items-center">
                  {c.image ? <img src={c.image} alt={c.name} className="w-full h-full object-cover" /> : <Icon size={22} className="text-[#F5A623]" />}
                </div>
                <p className="text-xs font-medium line-clamp-1">{c.name}</p>
                <p className="text-[10px] text-white/40">{count} items</p>
              </Link>
            )
          })}
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4"><AdSlot placement="home-top" /></div>

      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="flex items-end justify-between mb-5">
          <h2 className="text-2xl font-bold">Trending Now</h2>
          <Link to="/shop?sort=popular" className="text-sm text-[#F5A623]">View all</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {trending.map((p) => <ProductCard key={p.id} product={p} onQuickView={setQv} />)}
        </div>
      </section>

      {flash.enabled ? (
        <section className="max-w-7xl mx-auto px-4 mt-12">
          <FlashBanner flash={flash} products={flashProducts} />
        </section>
      ) : null}

      {banners[0] ? (
        <section className="max-w-7xl mx-auto px-4 mt-12">
          <Link to={banners[0].url || '/deals'} className="relative block overflow-hidden rounded-3xl border border-[#F5A623]/30">
            <img src={banners[0].image} alt="" className="w-full h-48 sm:h-64 object-cover opacity-60" />
            <div className="absolute inset-0 p-6 sm:p-10 flex flex-col justify-center bg-gradient-to-r from-black via-black/70 to-transparent">
              <p className="text-[#F5A623] text-xs font-bold tracking-widest">{banners[0].title}</p>
              <h3 className="text-2xl sm:text-4xl font-extrabold mt-1">{banners[0].subtitle}</h3>
              <span className="mt-4 inline-flex w-fit"><Button>{banners[0].button}</Button></span>
            </div>
          </Link>
        </section>
      ) : null}

      <div className="max-w-7xl mx-auto px-4"><AdSlot placement="home-middle" /></div>

      <section className="max-w-7xl mx-auto px-4 mt-12">
        <h2 className="text-2xl font-bold mb-5">Featured Products</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {featured.map((p) => <ProductCard key={p.id} product={p} onQuickView={setQv} />)}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 mt-16 grid sm:grid-cols-4 gap-4 text-center">
        {[
          ['100% Genuine', 'Original products only'],
          ['7 Days Return', 'Easy return policy'],
          ['Expert Support', '24/7 assistance'],
          ['Best Price', 'Guaranteed value'],
        ].map(([t, s]) => (
          <div key={t} className="rounded-2xl border border-white/8 p-5 bg-[#111]">
            <p className="font-semibold">{t}</p>
            <p className="text-xs text-white/50 mt-1">{s}</p>
          </div>
        ))}
      </section>

      <div className="max-w-7xl mx-auto px-4"><AdSlot placement="home-bottom" /></div>
      <QuickView product={qv} onClose={() => setQv(null)} />
    </div>
  )
}

function FlashBanner({ flash, products }) {
  const [left, setLeft] = useState('')
  useEffect(() => {
    const tick = () => {
      const end = new Date(flash.end).getTime()
      const d = Math.max(0, end - Date.now())
      if (!d) return setLeft('Expired')
      const h = Math.floor(d / 3600000)
      const m = Math.floor((d % 3600000) / 60000)
      const s = Math.floor((d % 60000) / 1000)
      setLeft(`${h}h ${m}m ${s}s`)
    }
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [flash.end])
  return (
    <div className="rounded-3xl border border-[#F5A623]/30 p-5 bg-gradient-to-br from-[#1A1208] to-[#111]">
      <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
        <div>
          <p className="text-[#F5A623] text-xs font-bold tracking-widest">FLASH SALE</p>
          <h3 className="text-2xl font-bold">{flash.title}</h3>
          <p className="text-white/50 text-sm">{flash.subtitle}</p>
        </div>
        <div className="rounded-xl bg-black/40 px-4 py-2 text-[#F5A623] font-mono">{left}</div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {products.slice(0, 4).map((p) => (
          <Link key={p.id} to={`/product/${p.id}`} className="rounded-xl bg-black/30 p-3 flex gap-3 items-center">
            <img src={p.images[0]} alt="" className="w-14 h-14 rounded-lg object-cover" />
            <div className="min-w-0">
              <p className="text-xs line-clamp-2">{p.name}</p>
              <p className="text-[#F5A623] text-sm font-semibold">{formatBdt(p.salePrice)}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}

import { useCms } from '../../context/CmsContext'
import { defaultFaqs } from '../../data/seed'
import Button from '../../components/ui/Button'
import { useSeo } from '../../hooks/useSeo'
import { useState } from 'react'
import { useToast } from '../../hooks/useToast'

export function About() {
  useSeo({ title: 'About' })
  const { cms } = useCms()
  return (
    <article className="max-w-3xl mx-auto px-4 py-10 prose-invert">
      <h1 className="text-3xl font-bold">About {cms.shopName}</h1>
      <p className="text-white/70 mt-4">{cms.tagline}</p>
      <p className="text-white/60 mt-4">{cms.footer.about} Based in {cms.contact.address}, we deliver original gadgets nationwide with warranty support and Cash on Delivery.</p>
    </article>
  )
}

export function Contact() {
  useSeo({ title: 'Contact' })
  const { cms } = useCms()
  const toast = useToast()
  const [form, setForm] = useState({ name: '', phone: '', message: '' })
  return (
    <div className="max-w-lg mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">Contact</h1>
      <p className="text-white/60 mt-2">{cms.contact.phone} · {cms.contact.email}</p>
      <p className="text-white/40 text-sm">{cms.contact.address} · {cms.contact.hours}</p>
      <form
        className="mt-6 space-y-3"
        onSubmit={(e) => {
          e.preventDefault()
          toast({ type: 'success', title: 'Message received', message: 'We will reply during business hours.' })
          setForm({ name: '', phone: '', message: '' })
        }}
      >
        <input className="w-full bg-[#111] p-3 rounded-xl" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className="w-full bg-[#111] p-3 rounded-xl" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} required />
        <textarea className="w-full bg-[#111] p-3 rounded-xl" rows={4} placeholder="Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
        <Button type="submit">Send</Button>
      </form>
    </div>
  )
}

export function Faq() {
  useSeo({ title: 'FAQ' })
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">FAQ</h1>
      <div className="space-y-3">
        {defaultFaqs.map((f) => (
          <details key={f.q} className="rounded-xl bg-[#111] p-4">
            <summary className="cursor-pointer font-medium">{f.q}</summary>
            <p className="text-white/60 text-sm mt-2">{f.a}</p>
          </details>
        ))}
      </div>
    </div>
  )
}

export function Privacy() {
  useSeo({ title: 'Privacy Policy' })
  return (
    <article className="max-w-3xl mx-auto px-4 py-10 text-white/70 text-sm space-y-3">
      <h1 className="text-3xl font-bold text-white">Privacy Policy</h1>
      <p>Mustakim Gadgets collects name, phone, email and delivery address solely to fulfil orders. We do not sell personal data. Payment secrets are never stored in the public frontend. For production, data is protected by backend rules and encryption in transit.</p>
    </article>
  )
}

export function Terms() {
  useSeo({ title: 'Terms' })
  return (
    <article className="max-w-3xl mx-auto px-4 py-10 text-white/70 text-sm space-y-3">
      <h1 className="text-3xl font-bold text-white">Terms & Conditions</h1>
      <p>Orders are confirmed after stock and payment verification. Prices are in BDT. Warranty follows manufacturer or store terms listed on the product page. Demo payment and courier adapters do not process live funds or parcels until a backend is connected.</p>
    </article>
  )
}

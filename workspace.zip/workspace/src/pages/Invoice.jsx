import { useParams } from 'react-router-dom'
import { useOrderStore } from '../store/orderStore'
import { useCms } from '../context/CmsContext'
import { formatBdt, formatDate } from '../utils/format'
import { PAYMENT_LABELS, STATUS_LABELS } from '../data/constants'
import Button from '../components/ui/Button'

export default function Invoice() {
  const { id } = useParams()
  const order = useOrderStore((s) => s.orders.find((o) => o.id === id))
  const { cms } = useCms()
  if (!order) return <p className="p-8">Invoice not found.</p>
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 bg-white text-black min-h-dvh">
      <div className="flex justify-between items-start no-print">
        <div className="flex items-center gap-2">
          {cms.invoiceLogoUrl || cms.logoUrl ? <img src={cms.invoiceLogoUrl || cms.logoUrl} alt="" className="h-10" /> : null}
          <h1 className="text-2xl font-bold">{cms.shopName}</h1>
        </div>
        <Button className="!text-black" onClick={() => window.print()}>Print / Download</Button>
      </div>
      <p className="text-sm text-zinc-500">{cms.tagline}</p>
      <p className="text-sm mt-1">{cms.contact.address} · {cms.contact.phone}</p>
      <hr className="my-4" />
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="font-semibold">Bill to</p>
          <p>{order.customer.name}</p>
          <p>{order.customer.phone}</p>
          <p>{order.address.address}, {order.address.upazila}, {order.address.district}</p>
        </div>
        <div className="text-right">
          <p className="font-mono font-bold">{order.id}</p>
          <p>{formatDate(order.createdAt)}</p>
          <p>Status: {STATUS_LABELS[order.status]}</p>
          <p>Payment: {PAYMENT_LABELS[order.paymentMethod]} ({order.paymentStatus})</p>
          <p>Tracking: {order.courier?.trackingCode || '—'}</p>
        </div>
      </div>
      <table className="w-full mt-6 text-sm">
        <thead>
          <tr className="border-b">
            <th className="text-left py-2">Product</th>
            <th>Qty</th>
            <th className="text-right">Price</th>
            <th className="text-right">Total</th>
          </tr>
        </thead>
        <tbody>
          {order.items.map((i) => (
            <tr key={i.productId} className="border-b">
              <td className="py-2">{i.name}<div className="text-xs text-zinc-500">{i.variant}</div></td>
              <td className="text-center">{i.qty}</td>
              <td className="text-right">{formatBdt(i.salePrice)}</td>
              <td className="text-right">{formatBdt(i.salePrice * i.qty)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 text-sm space-y-1 max-w-xs ml-auto">
        <p className="flex justify-between"><span>Subtotal</span><span>{formatBdt(order.totals.subtotal)}</span></p>
        <p className="flex justify-between"><span>Discount</span><span>- {formatBdt(order.totals.couponDiscount)}</span></p>
        <p className="flex justify-between"><span>Delivery</span><span>{formatBdt(order.totals.delivery)}</span></p>
        <p className="flex justify-between font-bold text-lg"><span>Grand Total</span><span>{formatBdt(order.totals.grandTotal)}</span></p>
      </div>
    </div>
  )
}

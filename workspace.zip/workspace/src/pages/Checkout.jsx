import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { divisions, getDistricts, getUpazilas } from '../data/bdLocations'
import { useCartStore } from '../store/cartStore'
import { useCatalogStore } from '../store/catalogStore'
import { useSettingsStore } from '../store/settingsStore'
import { useOrderStore } from '../store/orderStore'
import { useUserStore } from '../store/userStore'
import { calculateOrderTotals, getDeliveryCharge } from '../utils/calculate'
import { validateCoupon } from '../utils/coupon'
import { formatBdt } from '../utils/format'
import { mockPayment } from '../services/adapters'
import { playSound } from '../services/sound'
import { useUiStore } from '../store/uiStore'
import Button from '../components/ui/Button'
import { useSeo } from '../hooks/useSeo'
import { useToast } from '../hooks/useToast'
import { PAYMENT_LABELS } from '../data/constants'

const STEPS = ['Customer', 'Address', 'Delivery', 'Payment', 'Review', 'Done']

export default function Checkout() {
  useSeo({ title: 'Checkout' })
  const items = useCartStore((s) => s.items)
  const couponCode = useCartStore((s) => s.couponCode)
  const clearCart = useCartStore((s) => s.clearCart)
  const coupons = useCatalogStore((s) => s.coupons)
  const incrementCouponUse = useCatalogStore((s) => s.incrementCouponUse)
  const payments = useSettingsStore((s) => s.payments)
  const deliverySettings = useSettingsStore((s) => s.settings.delivery)
  const addOrder = useOrderStore((s) => s.addOrder)
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId))
  const addNotification = useUserStore((s) => s.addNotification)
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  const toast = useToast()
  const navigate = useNavigate()

  const [step, setStep] = useState(0)
  const [form, setForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    division: 'Dhaka',
    district: 'Dhaka',
    upazila: 'Dhanmondi',
    address: '',
    note: '',
    delivery: 'inside',
    payment: 'cod',
    mockOutcome: 'pending',
  })
  const [placed, setPlaced] = useState(null)

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))
  const districts = getDistricts(form.division)
  const upazilas = getUpazilas(form.district)
  const deliveryCharge = form.delivery === 'inside' || form.district === 'Dhaka'
    ? getDeliveryCharge(deliverySettings, 'Dhaka')
    : getDeliveryCharge(deliverySettings, form.district)

  const coupon = coupons.find((c) => c.code.toLowerCase() === couponCode.toLowerCase())
  const subtotal = items.reduce((n, i) => n + i.salePrice * i.qty, 0)
  const valid = coupon ? validateCoupon(coupon, { subtotal }) : { ok: false }
  const totals = calculateOrderTotals({ items, coupon: valid.ok ? coupon : null, deliveryCharge })

  const methods = useMemo(
    () => Object.entries(payments).filter(([, v]) => v.enabled),
    [payments],
  )

  if (!items.length && !placed) {
    return (
      <div className="py-20 text-center">
        <p>Your cart is empty.</p>
        <Button className="mt-4" onClick={() => navigate('/shop')}>Shop</Button>
      </div>
    )
  }

  const next = () => {
    if (step === 0 && (!form.name || !form.phone)) return toast({ type: 'error', title: 'Name and phone required' })
    if (step === 1 && !form.address) return toast({ type: 'error', title: 'Full address required' })
    setStep((s) => Math.min(s + 1, STEPS.length - 1))
  }

  const place = async () => {
    const pay = await mockPayment({ method: form.payment, mockOutcome: form.mockOutcome })
    const order = addOrder({
      userId: user?.id || 'guest',
      customer: { name: form.name, phone: form.phone, email: form.email },
      address: {
        division: form.division,
        district: form.district,
        upazila: form.upazila,
        address: form.address,
        note: form.note,
      },
      items,
      totals,
      couponCode: valid.ok ? coupon.code : '',
      paymentMethod: form.payment,
      paymentStatus: pay.status,
      status: 'pending',
    })
    if (valid.ok) incrementCouponUse(coupon.code)
    addNotification({
      userId: user?.id || 'guest',
      title: 'Order received',
      body: `${order.id} placed. Payment: ${pay.status.toUpperCase()}.`,
      type: 'order',
    })
    playSound(pay.status === 'failed' ? 'error' : 'success', soundEnabled)
    clearCart()
    setPlaced({ order, pay })
    setStep(5)
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6">
        {STEPS.map((s, i) => (
          <div key={s} className={`text-xs px-3 py-1 rounded-full ${i === step ? 'bg-[#F5A623] text-black' : i < step ? 'bg-white/10' : 'bg-white/5 text-white/40'}`}>{i + 1}. {s}</div>
        ))}
      </div>
      {step < 5 ? (
        <div className="grid lg:grid-cols-[1fr_300px] gap-6">
          <div className="rounded-2xl bg-[#111] border border-white/8 p-5 space-y-3">
            {step === 0 && (
              <>
                <Field label="Full Name" value={form.name} onChange={(v) => set('name', v)} />
                <Field label="Phone" value={form.phone} onChange={(v) => set('phone', v)} />
                <Field label="Email" value={form.email} onChange={(v) => set('email', v)} />
              </>
            )}
            {step === 1 && (
              <>
                <label className="block text-sm">Division
                  <select className="w-full mt-1 bg-[#1A1A1A] p-2 rounded-lg" value={form.division} onChange={(e) => set('division', e.target.value)}>
                    {divisions.map((d) => <option key={d}>{d}</option>)}
                  </select>
                </label>
                <label className="block text-sm">District
                  <select className="w-full mt-1 bg-[#1A1A1A] p-2 rounded-lg" value={form.district} onChange={(e) => set('district', e.target.value)}>
                    {districts.map((d) => <option key={d}>{d}</option>)}
                  </select>
                </label>
                <label className="block text-sm">Upazila
                  <select className="w-full mt-1 bg-[#1A1A1A] p-2 rounded-lg" value={form.upazila} onChange={(e) => set('upazila', e.target.value)}>
                    {upazilas.map((d) => <option key={d}>{d}</option>)}
                  </select>
                </label>
                <Field label="Full Address" value={form.address} onChange={(v) => set('address', v)} />
                <Field label="Delivery Note" value={form.note} onChange={(v) => set('note', v)} />
              </>
            )}
            {step === 2 && (
              <>
                <label className="flex items-center gap-3 p-3 rounded-xl border border-white/10">
                  <input type="radio" checked={form.delivery === 'inside'} onChange={() => set('delivery', 'inside')} />
                  Inside Dhaka — {formatBdt(deliverySettings.insideDhaka)}
                </label>
                <label className="flex items-center gap-3 p-3 rounded-xl border border-white/10">
                  <input type="radio" checked={form.delivery === 'outside'} onChange={() => set('delivery', 'outside')} />
                  Outside Dhaka — {formatBdt(deliverySettings.outsideDhaka)}
                </label>
              </>
            )}
            {step === 3 && (
              <>
                {methods.map(([key, cfg]) => (
                  <label key={key} className={`flex items-center gap-3 p-3 rounded-xl border ${form.payment === key ? 'border-[#F5A623]' : 'border-white/10'}`}>
                    <input type="radio" checked={form.payment === key} onChange={() => set('payment', key)} />
                    <span>{cfg.label || PAYMENT_LABELS[key]}</span>
                    {key !== 'cod' && !cfg.connected ? <span className="ml-auto text-[10px] text-white/40">DEMO / NOT CONNECTED</span> : null}
                  </label>
                ))}
                {form.payment !== 'cod' ? (
                  <label className="block text-sm mt-3">Demo outcome
                    <select className="w-full mt-1 bg-[#1A1A1A] p-2 rounded-lg" value={form.mockOutcome} onChange={(e) => set('mockOutcome', e.target.value)}>
                      <option value="pending">PAYMENT PENDING</option>
                      <option value="success">PAYMENT SUCCESS (demo)</option>
                      <option value="failed">PAYMENT FAILED (demo)</option>
                    </select>
                  </label>
                ) : null}
              </>
            )}
            {step === 4 && (
              <div className="text-sm space-y-2">
                <p><strong>{form.name}</strong> · {form.phone}</p>
                <p>{form.address}, {form.upazila}, {form.district}, {form.division}</p>
                <p>Payment: {PAYMENT_LABELS[form.payment]}</p>
                {items.map((i) => (
                  <p key={i.productId}>{i.qty} × {i.name} — {formatBdt(i.salePrice * i.qty)}</p>
                ))}
              </div>
            )}
            <div className="flex gap-2 pt-4">
              {step > 0 ? <Button variant="dark" onClick={() => setStep((s) => s - 1)}>Back</Button> : null}
              {step < 4 ? <Button onClick={next} className="ml-auto">Continue</Button> : <Button onClick={place} className="ml-auto">Place order</Button>}
            </div>
          </div>
          <aside className="rounded-2xl bg-[#111] p-4 h-fit text-sm space-y-1">
            <p className="font-semibold mb-2">Order summary</p>
            <p className="flex justify-between"><span>Subtotal</span><span>{formatBdt(totals.subtotal)}</span></p>
            <p className="flex justify-between"><span>Coupon</span><span>- {formatBdt(totals.couponDiscount)}</span></p>
            <p className="flex justify-between"><span>Delivery</span><span>{formatBdt(totals.delivery)}</span></p>
            <p className="flex justify-between font-bold text-[#F5A623] pt-2"><span>Total</span><span>{formatBdt(totals.grandTotal)}</span></p>
          </aside>
        </div>
      ) : (
        <div className="rounded-2xl bg-[#111] p-8 text-center max-w-lg mx-auto">
          <h1 className="text-2xl font-bold">Order placed</h1>
          <p className="text-[#F5A623] mt-2 font-mono">{placed?.order.id}</p>
          <p className="text-white/60 mt-3 text-sm">{placed?.pay.message}</p>
          <p className="text-xs mt-2 uppercase tracking-wide">Payment: {placed?.pay.status}</p>
          <div className="flex gap-2 justify-center mt-6">
            <Button onClick={() => navigate(`/account/orders/${placed.order.id}`)}>Track order</Button>
            <Button variant="dark" onClick={() => navigate('/shop')}>Continue shopping</Button>
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, value, onChange }) {
  return (
    <label className="block text-sm">
      {label}
      <input className="w-full mt-1 bg-[#1A1A1A] p-2 rounded-lg" value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  )
}

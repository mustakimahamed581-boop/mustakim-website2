import { createContext, useContext } from 'react'
import { useSettingsStore } from '../store/settingsStore'

const CmsContext = createContext(null)

export function CmsProvider({ children }) {
  const cms = useSettingsStore((s) => s.cms)
  const settings = useSettingsStore((s) => s.settings)
  return <CmsContext.Provider value={{ cms, settings }}>{children}</CmsContext.Provider>
}

export function useCms() {
  const ctx = useContext(CmsContext)
  if (!ctx) throw new Error('useCms must be used within CmsProvider')
  return ctx
}

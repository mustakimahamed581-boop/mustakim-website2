import { PAYMENT_LABELS, PAYMENT_STATUS_LABELS } from '../data/constants'

export function normalizePaymentStatus(status) {
  if (status === 'success') return 'approved'
  if (status === 'failed') return 'rejected'
  return status || 'pending'
}

export function paymentStatusLabel(status) {
  const key = normalizePaymentStatus(status)
  return PAYMENT_STATUS_LABELS[key] || PAYMENT_STATUS_LABELS[status] || String(status || 'Pending')
}

export function paymentMethodLabel(id, methods = []) {
  const found = methods.find((m) => m.id === id)
  return found?.name || PAYMENT_LABELS[id] || id || '—'
}

export function generateInvoiceNumber(orderId) {
  if (!orderId) return `INV-${Date.now()}`
  return `INV-${String(orderId).replace(/^MG-/, '')}`
}

export function estimatedDeliveryIso(days = 4) {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString()
}

export function parseVariantParts(variant = '') {
  const parts = String(variant || '').split('/').map((p) => p.trim()).filter(Boolean)
  return {
    color: parts[0] || '',
    storage: parts.find((p) => /\d+\s?(GB|TB)/i.test(p) && !/RAM/i.test(p)) || '',
    ram: parts.find((p) => /RAM|\d+\s?GB$/i.test(p) && /RAM/i.test(p)) || '',
  }
}

export function enrichCartLine(item) {
  const variant = item.variant || ''
  const parsed = parseVariantParts(variant)
  return {
    productId: item.id || item.productId,
    name: item.name,
    brand: item.brand || '',
    image: item.image || item.images?.[0] || '',
    price: item.price,
    salePrice: item.salePrice ?? item.price,
    stock: item.stock,
    variant,
    qty: item.qty || 1,
    color: item.color || item.variants?.color?.[0] || parsed.color,
    ram: item.ram || item.variants?.ram?.[0] || parsed.ram,
    storage: item.storage || item.variants?.storage?.[0] || parsed.storage,
    model: item.model || item.variants?.model?.[0] || '',
    specifications: item.specifications || [],
  }
}

export function isApprovedPayment(status) {
  return normalizePaymentStatus(status) === 'approved'
}

export function canShowVerifiedInvoice(order) {
  return isApprovedPayment(order?.paymentStatus) && !!order?.invoiceGenerated
}

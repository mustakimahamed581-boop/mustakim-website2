export function calculateOrderTotals({
  items = [],
  coupon = null,
  deliveryCharge = 0,
  extraDiscount = 0,
} = {}) {
  const subtotal = items.reduce((sum, item) => {
    const unit = Number(item.salePrice ?? item.price ?? 0)
    return sum + unit * Number(item.qty || 0)
  }, 0)

  const productDiscount = items.reduce((sum, item) => {
    const price = Number(item.price || 0)
    const sale = Number(item.salePrice ?? item.price ?? 0)
    return sum + Math.max(0, price - sale) * Number(item.qty || 0)
  }, 0)

  let couponDiscount = 0
  if (coupon && subtotal >= Number(coupon.minOrder || 0)) {
    if (coupon.type === 'percent') {
      couponDiscount = (subtotal * Number(coupon.value || 0)) / 100
      if (coupon.maxDiscount) couponDiscount = Math.min(couponDiscount, Number(coupon.maxDiscount))
    } else {
      couponDiscount = Number(coupon.value || 0)
    }
  }
  couponDiscount = Math.min(couponDiscount, subtotal)

  const discount = Number(extraDiscount || 0) + couponDiscount
  const delivery = Number(deliveryCharge || 0)
  const grandTotal = Math.max(0, subtotal - couponDiscount + delivery)

  return {
    subtotal: Math.round(subtotal),
    productDiscount: Math.round(productDiscount),
    couponDiscount: Math.round(couponDiscount),
    discount: Math.round(discount),
    delivery: Math.round(delivery),
    grandTotal: Math.round(grandTotal),
  }
}

export function getDeliveryCharge(settings, district) {
  const inside = Number(settings?.insideDhaka ?? 60)
  const outside = Number(settings?.outsideDhaka ?? 120)
  if (!district) return inside
  return String(district).toLowerCase() === 'dhaka' ? inside : outside
}

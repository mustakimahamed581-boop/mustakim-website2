export function validateCoupon(coupon, { subtotal = 0, userId, usedCount = 0, userUsed = 0 } = {}) {
  if (!coupon) return { ok: false, message: 'Enter a coupon code.' }
  const now = Date.now()
  if (!coupon.enabled) return { ok: false, message: 'This coupon is not active.' }
  if (coupon.startDate && now < new Date(coupon.startDate).getTime()) {
    return { ok: false, message: 'This coupon is not yet valid.' }
  }
  if (coupon.endDate && now > new Date(coupon.endDate).getTime()) {
    return { ok: false, message: 'This coupon has expired.' }
  }
  if (coupon.usageLimit && usedCount >= coupon.usageLimit) {
    return { ok: false, message: 'This coupon has reached its usage limit.' }
  }
  if (coupon.perUserLimit && userId && userUsed >= coupon.perUserLimit) {
    return { ok: false, message: 'You have already used this coupon.' }
  }
  if (subtotal < Number(coupon.minOrder || 0)) {
    return { ok: false, message: `Minimum order ৳${coupon.minOrder} required.` }
  }
  return { ok: true, coupon }
}

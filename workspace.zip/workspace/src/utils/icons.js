import {
  Smartphone, Square, Shield, PlugZap, Cable, Headphones, Watch, Speaker,
  BatteryCharging, Gamepad2, Home, Car, Plane, Package, Layers, ShoppingBag,
  Users, Ticket, Zap, Image, Star, Truck, CreditCard, Flame, Plug, Bell,
  Settings, BarChart3, Wrench, LayoutDashboard, Circle, Monitor, Tag,
  Activity, Clock, SlidersHorizontal, User, ShieldCheck,
} from 'lucide-react'

const MAP = {
  Smartphone, Square, Shield, PlugZap, Cable, Headphones, Watch, Speaker,
  BatteryCharging, Gamepad2, Home, Car, Plane, Package, Layers, ShoppingBag,
  Users, Ticket, Zap, Image, Star, Truck, CreditCard, Flame, Plug, Bell,
  Settings, BarChart3, Wrench, LayoutDashboard, Circle, Monitor, Tag,
  Activity, Clock, SlidersHorizontal, User, ShieldCheck,
}

export function iconByName(name) {
  return MAP[name] || Smartphone
}

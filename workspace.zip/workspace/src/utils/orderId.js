export function generateOrderId(existing = []) {
  const now = new Date()
  const dhaka = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' }))
  const y = dhaka.getFullYear()
  const m = String(dhaka.getMonth() + 1).padStart(2, '0')
  const d = String(dhaka.getDate()).padStart(2, '0')
  const prefix = `MG-${y}${m}${d}-`
  const sameDay = existing
    .map((o) => o.id)
    .filter((id) => id?.startsWith(prefix))
    .map((id) => Number(id.split('-').pop()))
  const next = (sameDay.length ? Math.max(...sameDay) : 0) + 1
  return `${prefix}${String(next).padStart(4, '0')}`
}

const BDT = new Intl.NumberFormat('en-BD')

export function formatBdt(amount) {
  const n = Number(amount) || 0
  return `৳${BDT.format(Math.round(n))}`
}

export function formatDate(iso, opts = {}) {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString('en-BD', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...opts,
  })
}

export function formatDateTime(iso) {
  return formatDate(iso, { hour: '2-digit', minute: '2-digit' })
}

export function discountPercent(price, salePrice) {
  if (!price || !salePrice || salePrice >= price) return 0
  return Math.round(((price - salePrice) / price) * 100)
}

export function slugify(text) {
  return String(text || '')
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
}

export function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n))
}

export function initials(name) {
  return String(name || 'U')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('')
}

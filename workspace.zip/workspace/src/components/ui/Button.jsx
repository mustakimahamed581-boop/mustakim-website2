import { cn } from '../../utils/cn'

const variants = {
  gold: 'bg-[#F5A623] hover:bg-[#E8941A] text-black font-semibold',
  dark: 'bg-[#1A1A1A] hover:bg-[#242424] text-white border border-white/10',
  ghost: 'bg-transparent hover:bg-white/5 text-white',
  outline: 'border border-[#F5A623] text-[#F5A623] hover:bg-[#F5A623]/10',
  admin: 'bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-semibold',
  danger: 'bg-red-600 hover:bg-red-700 text-white',
  light: 'bg-white text-black hover:bg-zinc-100 font-semibold',
}

export default function Button({
  variant = 'gold',
  className,
  children,
  type = 'button',
  ...props
}) {
  return (
    <button
      type={type}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm transition disabled:opacity-50 disabled:cursor-not-allowed',
        variants[variant],
        className,
      )}
      {...props}
    >
      {children}
    </button>
  )
}

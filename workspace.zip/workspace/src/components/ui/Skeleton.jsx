import { cn } from '../../utils/cn'

export function Skeleton({ className }) {
  return <div className={cn('animate-pulse rounded-xl bg-white/10', className)} />
}

export function ProductSkeleton() {
  return (
    <div className="rounded-2xl border border-white/5 bg-[#111] p-3">
      <Skeleton className="aspect-square w-full" />
      <Skeleton className="h-4 mt-3 w-2/3" />
      <Skeleton className="h-3 mt-2 w-1/2" />
      <Skeleton className="h-8 mt-3 w-full" />
    </div>
  )
}

export function TableSkeleton({ rows = 6 }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-12 w-full" />
      ))}
    </div>
  )
}

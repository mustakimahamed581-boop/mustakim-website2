import { PackageOpen } from 'lucide-react'
import Button from './Button'
import { Link } from 'react-router-dom'

export default function EmptyState({ icon: Icon = PackageOpen, title, message, action, to }) {
  return (
    <div className="flex flex-col items-center text-center py-16 px-6">
      <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-4">
        <Icon className="text-[#F5A623]" />
      </div>
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="text-white/60 mt-2 max-w-sm text-sm">{message}</p>
      {to ? (
        <Link to={to} className="mt-5">
          <Button>{action || 'Continue shopping'}</Button>
        </Link>
      ) : null}
    </div>
  )
}

import { Component } from 'react'

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { err: null }
  }

  static getDerivedStateFromError(err) {
    return { err }
  }

  componentDidCatch(err) {
    try {
      const logs = JSON.parse(localStorage.getItem('mg-runtime-errors') || '[]')
      logs.unshift({ at: new Date().toISOString(), message: String(err?.message || err) })
      localStorage.setItem('mg-runtime-errors', JSON.stringify(logs.slice(0, 20)))
    } catch {
      /* ignore */
    }
  }

  render() {
    if (!this.state.err) return this.props.children
    return (
      <div className="min-h-dvh bg-[#0A0A0A] text-white px-6 py-16 text-center">
        <p className="text-[#F5A623] text-xs font-bold tracking-[0.3em]">MUSTAKIM GADGETS</p>
        <h1 className="text-2xl font-extrabold mt-4">Something went wrong</h1>
        <p className="text-white/60 mt-2 max-w-md mx-auto text-sm">
          The storefront is still available. A feature failed, but the site is not blocked.
        </p>
        <div className="mt-6 flex gap-3 justify-center">
          <button
            className="rounded-xl bg-[#F5A623] text-black font-semibold px-4 py-2"
            onClick={() => this.setState({ err: null })}
          >
            Try again
          </button>
          <a href="/" className="rounded-xl border border-white/20 px-4 py-2">Go home</a>
        </div>
      </div>
    )
  }
}

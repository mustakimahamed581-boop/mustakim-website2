import { AnimatePresence, motion } from 'framer-motion'
import { useEffect } from 'react'
import { useUiStore } from '../../store/uiStore'
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react'

const icons = {
  success: CheckCircle2,
  error: AlertCircle,
  info: Info,
}

export default function ToastViewport() {
  const toasts = useUiStore((s) => s.toasts)
  const dismissToast = useUiStore((s) => s.dismissToast)

  return (
    <div className="fixed top-4 right-4 z-[90] space-y-2 w-[min(92vw,360px)]">
      <AnimatePresence>
        {toasts.map((t) => (
          <ToastItem key={t.id} t={t} onClose={() => dismissToast(t.id)} />
        ))}
      </AnimatePresence>
    </div>
  )
}

function ToastItem({ t, onClose }) {
  useEffect(() => {
    const id = setTimeout(onClose, 3200)
    return () => clearTimeout(id)
  }, [onClose])
  const Icon = icons[t.type] || Info
  return (
    <motion.div
      initial={{ opacity: 0, x: 24 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 24 }}
      className="glass rounded-xl border border-white/10 p-3 flex gap-3 shadow-xl"
    >
      <Icon size={18} className={t.type === 'error' ? 'text-red-400' : t.type === 'success' ? 'text-emerald-400' : 'text-[#F5A623]'} />
      <div className="flex-1 text-sm">
        <p className="font-medium">{t.title}</p>
        {t.message ? <p className="text-white/60 text-xs mt-0.5">{t.message}</p> : null}
      </div>
      <button onClick={onClose} aria-label="Dismiss">
        <X size={14} />
      </button>
    </motion.div>
  )
}

import { useMemo } from 'react'
import { useSettingsStore } from '../../store/settingsStore'

function deviceKind() {
  if (typeof window === 'undefined') return 'desktop'
  const w = window.innerWidth
  if (w < 768) return 'mobile'
  if (w < 1024) return 'tablet'
  return 'desktop'
}

export default function AdSlot({ placement }) {
  const ads = useSettingsStore((s) => s.ads)
  const flags = useSettingsStore((s) => s.featureFlags)
  const items = useMemo(() => {
    if (!flags?.ads || !Array.isArray(ads)) return []
    const now = Date.now()
    const device = deviceKind()
    return ads
      .filter((a) => a.enabled && a.placement === placement && a.code?.trim())
      .filter((a) => a.devices?.[device] !== false)
      .filter((a) => {
        if (a.startDate && now < new Date(a.startDate).getTime()) return false
        if (a.endDate && now > new Date(a.endDate).getTime()) return false
        return true
      })
      .sort((a, b) => (a.priority || 0) - (b.priority || 0))
  }, [ads, flags, placement])

  if (!items.length) return null

  return (
    <div className="w-full max-w-full overflow-hidden my-4" data-ad-placement={placement}>
      {items.map((a) => (
        <iframe
          key={a.id}
          title={`ad-${a.id}`}
          className="w-full max-w-full border-0 rounded-xl bg-[#111] min-h-[90px]"
          sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"
          srcDoc={`<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;overflow:hidden;background:transparent}</style></head><body>${a.code}</body></html>`}
        />
      ))}
    </div>
  )
}

import { useEffect, useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Heart, Search, ShoppingCart, User, Menu, Volume2, VolumeX } from 'lucide-react'
import Logo from './Logo'
import { useCartStore } from '../../store/cartStore'
import { useWishlistStore } from '../../store/wishlistStore'
import { useUiStore } from '../../store/uiStore'
import { useUserStore } from '../../store/userStore'
import { useSettingsStore } from '../../store/settingsStore'
import { cn } from '../../utils/cn'

const links = [
  { to: '/', label: 'Home' },
  { to: '/shop', label: 'Shop' },
  { to: '/categories', label: 'Categories' },
  { to: '/deals', label: 'Deals' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
]

export default function Header({ onMenu }) {
  const [scrolled, setScrolled] = useState(false)
  const navigate = useNavigate()
  const items = useCartStore((s) => s.items)
  const wish = useWishlistStore((s) => s.ids)
  const setSearchOpen = useUiStore((s) => s.setSearchOpen)
  const setCartOpen = useUiStore((s) => s.setCartOpen)
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  const setSound = useUiStore((s) => s.setSound)
  const user = useUserStore((s) => s.users.find((u) => u.id === s.currentUserId) || null)
  const flags = useSettingsStore((s) => s.featureFlags)
  const count = items.reduce((n, i) => n + i.qty, 0)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header className={cn('sticky top-0 z-50 glass border-b border-white/5 transition-all', scrolled ? 'py-1.5' : 'py-3')}>
      <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center gap-3">
        <button className="lg:hidden p-2" onClick={onMenu} aria-label="Open menu">
          <Menu size={20} />
        </button>
        <Logo compact={scrolled} />
        <nav className="hidden lg:flex items-center gap-5 mx-auto text-sm">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === '/'}
              className={({ isActive }) => cn('hover:text-[#F5A623]', isActive && 'text-[#F5A623] font-semibold')}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-1 sm:gap-2">
          {flags?.search !== false ? (
            <button className="p-2 rounded-lg hover:bg-white/5" onClick={() => setSearchOpen(true)} aria-label="Search">
              <Search size={18} />
            </button>
          ) : null}
          <button
            className="hidden sm:inline-flex p-2 rounded-lg hover:bg-white/5"
            onClick={() => setSound(!soundEnabled)}
            aria-label={soundEnabled ? 'Sound off' : 'Sound on'}
            title={soundEnabled ? 'Sound on' : 'Sound off'}
          >
            {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
          <Link to="/account" className="hidden sm:inline-flex p-2 rounded-lg hover:bg-white/5" aria-label="Account">
            <User size={18} />
          </Link>
          {flags?.wishlist !== false ? (
          <Link to="/wishlist" className="relative p-2 rounded-lg hover:bg-white/5" aria-label="Wishlist">
            <Heart size={18} />
            {wish.length > 0 ? (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-[#F5A623] text-black text-[10px] grid place-items-center font-bold">
                {wish.length}
              </span>
            ) : null}
          </Link>
          ) : null}
          {flags?.cart !== false ? (
          <button className="relative p-2 rounded-lg hover:bg-white/5" onClick={() => setCartOpen(true)} aria-label="Cart">
            <ShoppingCart size={18} />
            {count > 0 ? (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-[#F5A623] text-black text-[10px] grid place-items-center font-bold">
                {count}
              </span>
            ) : null}
          </button>
          ) : null}
          {user ? (
            <button onClick={() => navigate('/account')} className="hidden md:block text-xs text-white/60 max-w-[90px] truncate">
              {user.name.split(' ')[0]}
            </button>
          ) : (
            <Link to="/login" className="hidden md:inline text-xs text-[#F5A623]">Login</Link>
          )}
        </div>
      </div>
    </header>
  )
}

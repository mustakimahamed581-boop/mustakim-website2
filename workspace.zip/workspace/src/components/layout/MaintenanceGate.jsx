import { useLocation } from 'react-router-dom'
import { useSettingsStore } from '../../store/settingsStore'
import { useAdminStore } from '../../store/adminStore'
import Logo from './Logo'

export default function MaintenanceGate({ children }) {
  const enabled = useSettingsStore((s) => s.settings.maintenance.enabled)
  const message = useSettingsStore((s) => s.settings.maintenance.message)
  const loc = useLocation()
  const authed = useAdminStore((s) => s.authed)
  const authedAt = useAdminStore((s) => s.authedAt)
  const timeoutMin = useAdminStore((s) => s.security?.sessionTimeoutMin || 60)
  const adminOk = authed && authedAt && Date.now() - authedAt <= timeoutMin * 60 * 1000
  if (enabled && !loc.pathname.startsWith('/admin') && !adminOk) {
    return (
      <div className="min-h-dvh grid place-items-center px-6 text-center bg-[#0A0A0A]">
        <div>
          <Logo />
          <h1 className="text-3xl font-extrabold mt-8">WE'LL BE BACK SOON</h1>
          <p className="text-white/60 mt-3 max-w-md mx-auto">{message}</p>
        </div>
      </div>
    )
  }
  return children
}

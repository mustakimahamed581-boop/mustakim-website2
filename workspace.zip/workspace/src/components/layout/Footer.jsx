import { Link } from 'react-router-dom'
import { Facebook, Instagram, Youtube, Phone, Mail, MapPin } from 'lucide-react'
import Logo from './Logo'
import { useCms } from '../../context/CmsContext'
import { useCatalogStore } from '../../store/catalogStore'

export default function Footer() {
  const { cms } = useCms()
  const allCategories = useCatalogStore((s) => s.categories)
  const cats = (allCategories || []).filter((c) => c.enabled).slice(0, 6)
  return (
    <footer className="mt-10 border-t border-white/10 bg-[#0A0A0A] pb-20 lg:pb-8">
      <div className="max-w-7xl mx-auto px-4 py-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-sm">
        <div>
          <Logo />
          <p className="text-white/55 mt-3">{cms.footer?.about}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Quick Links</h4>
          <ul className="space-y-2 text-white/60">
            <li><Link to="/shop">Shop</Link></li>
            <li><Link to="/deals">Deals</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/faq">FAQ</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/terms">Terms & Conditions</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Categories</h4>
          <ul className="space-y-2 text-white/60">
            {cats.map((c) => (
              <li key={c.id}><Link to={`/categories/${c.slug}`}>{c.name}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Contact</h4>
          <ul className="space-y-2 text-white/60">
            <li className="flex gap-2"><Phone size={14} className="mt-1" /> {cms.contact.phone}</li>
            <li className="flex gap-2"><Mail size={14} className="mt-1" /> {cms.contact.email}</li>
            <li className="flex gap-2"><MapPin size={14} className="mt-1" /> {cms.contact.address}</li>
          </ul>
          <div className="flex gap-3 mt-4">
            <a href={cms.social.facebook} aria-label="Facebook" className="p-2 rounded-lg bg-white/5"><Facebook size={16} /></a>
            <a href={cms.social.instagram} aria-label="Instagram" className="p-2 rounded-lg bg-white/5"><Instagram size={16} /></a>
            <a href={cms.social.youtube} aria-label="YouTube" className="p-2 rounded-lg bg-white/5"><Youtube size={16} /></a>
          </div>
        </div>
      </div>
      <p className="text-center text-xs text-white/40 pb-6">{cms.footer?.copyright}</p>
    </footer>
  )
}

import { useEffect, useLayoutEffect, useRef } from 'react'
import { useLocation, useNavigationType } from 'react-router-dom'

const saved = new Map()

function jumpTop() {
  const html = document.documentElement
  const body = document.body
  html.scrollTop = 0
  body.scrollTop = 0
  window.scrollTo(0, 0)
  document.querySelectorAll('main, [data-scroll-root]').forEach((el) => {
    el.scrollTop = 0
  })
}

export default function ScrollControl() {
  const loc = useLocation()
  const navType = useNavigationType()
  const prevKey = useRef(loc.key)

  useLayoutEffect(() => {
    try {
      if ('scrollRestoration' in window.history) window.history.scrollRestoration = 'manual'
    } catch {
      /* ignore */
    }
  }, [])

  useLayoutEffect(() => {
    const key = loc.key || loc.pathname + loc.search
    if (navType === 'POP' && saved.has(key)) {
      const y = saved.get(key) || 0
      window.scrollTo(0, y)
      return
    }
    jumpTop()
    requestAnimationFrame(jumpTop)
    prevKey.current = key
  }, [loc.pathname, loc.search, loc.hash, loc.key, navType])

  useEffect(() => {
    const key = loc.key || loc.pathname + loc.search
    const onScroll = () => saved.set(key, window.scrollY || document.documentElement.scrollTop || 0)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [loc.key, loc.pathname, loc.search])

  return null
}

import { NavLink } from 'react-router-dom'
import { Home, LayoutGrid, ShoppingBag, Zap, User } from 'lucide-react'
import { useCartStore } from '../../store/cartStore'

const items = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/categories', label: 'Categories', icon: LayoutGrid },
  { to: '/shop', label: 'Shop', icon: ShoppingBag },
  { to: '/deals', label: 'Deals', icon: Zap },
  { to: '/account', label: 'Account', icon: User },
]

export default function MobileBottomNav() {
  const itemsCart = useCartStore((s) => s.items)
  const count = itemsCart.reduce((n, i) => n + i.qty, 0)
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-50 bg-[#111]/95 backdrop-blur border-t border-white/10 pb-[env(safe-area-inset-bottom)]">
      <ul className="grid grid-cols-5">
        {items.map((it) => {
          const Icon = it.icon
          return (
            <li key={it.to}>
              <NavLink
                to={it.to}
                end={it.end}
                className={({ isActive }) =>
                  `relative flex flex-col items-center py-2 text-[10px] ${isActive ? 'text-[#F5A623]' : 'text-white/55'}`
                }
              >
                {({ isActive }) => (
                  <>
                    <span className={`relative ${isActive ? 'bg-[#F5A623] text-black rounded-full p-2 -mt-5 shadow-lg' : 'p-1'}`}>
                      <Icon size={isActive ? 20 : 18} />
                      {it.to === '/shop' && count > 0 ? (
                        <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-white text-black text-[9px] grid place-items-center font-bold">
                          {count}
                        </span>
                      ) : null}
                    </span>
                    {it.label}
                  </>
                )}
              </NavLink>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}

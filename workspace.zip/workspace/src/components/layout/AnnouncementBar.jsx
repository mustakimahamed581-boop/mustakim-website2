import { Truck } from 'lucide-react'
import { useCms } from '../../context/CmsContext'

export default function AnnouncementBar() {
  const { cms } = useCms()
  const a = cms.announcement
  if (!a?.enabled) return null
  return (
    <div className="text-center text-xs sm:text-sm py-1.5 px-3" style={{ background: a.background, color: a.textColor }}>
      <span className="inline-flex items-center gap-2">
        <Truck size={14} />
        {a.text}
      </span>
    </div>
  )
}

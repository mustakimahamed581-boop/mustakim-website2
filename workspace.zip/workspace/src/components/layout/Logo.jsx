import { Link } from 'react-router-dom'
import { useCms } from '../../context/CmsContext'

export default function Logo({ compact, light }) {
  const { cms } = useCms()
  return (
    <Link to="/" className="flex items-center gap-2 min-w-0">
      {cms.logoUrl ? (
        <img src={compact ? (cms.mobileLogoUrl || cms.logoUrl) : cms.logoUrl} alt={cms.shopName} className="h-9 w-9 rounded-full object-cover shrink-0" />
      ) : (
        <span className="w-9 h-9 rounded-full gold-gradient grid place-items-center text-black font-extrabold text-sm shrink-0 shadow-[0_0_18px_rgba(245,166,35,0.35)]">
          {cms.logoText || 'MG'}
        </span>
      )}
      {compact ? null : (
        <span className={`leading-tight min-w-0 ${light ? 'text-white' : ''}`}>
          <span className="block font-extrabold tracking-wide text-sm truncate">{cms.shopName}</span>
          <span className="hidden sm:block text-[10px] text-[#F5A623] tracking-wider truncate">{cms.tagline}</span>
        </span>
      )}
    </Link>
  )
}

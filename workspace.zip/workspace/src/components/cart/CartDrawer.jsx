import { AnimatePresence, motion } from 'framer-motion'
import { X, Minus, Plus, Trash2 } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useUiStore } from '../../store/uiStore'
import { useCartStore } from '../../store/cartStore'
import { formatBdt } from '../../utils/format'
import { calculateOrderTotals } from '../../utils/calculate'
import Button from '../ui/Button'
import EmptyState from '../ui/EmptyState'
import { ShoppingBag } from 'lucide-react'

export default function CartDrawer() {
  const open = useUiStore((s) => s.cartOpen)
  const setCartOpen = useUiStore((s) => s.setCartOpen)
  const items = useCartStore((s) => s.items)
  const setQty = useCartStore((s) => s.setQty)
  const removeItem = useCartStore((s) => s.removeItem)
  const totals = calculateOrderTotals({ items })

  return (
    <AnimatePresence>
      {open ? (
        <motion.aside className="fixed inset-0 z-[75]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <button className="absolute inset-0 bg-black/60" onClick={() => setCartOpen(false)} aria-label="Close cart" />
          <motion.div
            initial={{ x: 360 }}
            animate={{ x: 0 }}
            exit={{ x: 360 }}
            className="absolute right-0 top-0 h-full w-[min(100%,400px)] bg-[#111] border-l border-white/10 flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h3 className="font-semibold">Your Cart ({items.reduce((n, i) => n + i.qty, 0)})</h3>
              <button onClick={() => setCartOpen(false)} aria-label="Close"><X /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {items.length === 0 ? (
                <EmptyState icon={ShoppingBag} title="Cart is empty" message="Add premium gadgets to get started." to="/shop" action="Shop now" />
              ) : (
                items.map((i) => (
                  <div key={`${i.productId}-${i.variant}`} className="flex gap-3">
                    <img src={i.image} alt="" className="w-16 h-16 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm line-clamp-2">{i.name}</p>
                      {i.variant ? <p className="text-[11px] text-white/40">{i.variant}</p> : null}
                      <p className="text-[#F5A623] text-sm">{formatBdt(i.salePrice)}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <button className="w-7 h-7 rounded bg-white/10" onClick={() => setQty(i.productId, i.variant, i.qty - 1)} aria-label="Decrease"><Minus size={12} className="mx-auto" /></button>
                        <span className="text-sm w-5 text-center">{i.qty}</span>
                        <button className="w-7 h-7 rounded bg-white/10" onClick={() => setQty(i.productId, i.variant, i.qty + 1)} aria-label="Increase"><Plus size={12} className="mx-auto" /></button>
                        <button className="ml-auto text-red-400" onClick={() => removeItem(i.productId, i.variant)} aria-label="Remove"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
            {items.length > 0 ? (
              <div className="p-4 border-t border-white/10 space-y-2">
                <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatBdt(totals.subtotal)}</span></div>
                <Link to="/cart" onClick={() => setCartOpen(false)}><Button variant="dark" className="w-full">View cart</Button></Link>
                <Link to="/checkout" onClick={() => setCartOpen(false)}><Button className="w-full">Checkout</Button></Link>
              </div>
            ) : null}
          </motion.div>
        </motion.aside>
      ) : null}
    </AnimatePresence>
  )
}

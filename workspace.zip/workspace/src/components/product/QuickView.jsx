import Modal from '../ui/Modal'
import { formatBdt, discountPercent } from '../../utils/format'
import Button from '../ui/Button'
import { Link } from 'react-router-dom'
import { useCartStore } from '../../store/cartStore'
import { useUiStore } from '../../store/uiStore'
import { playSound } from '../../services/sound'

export default function QuickView({ product, onClose }) {
  const addItem = useCartStore((s) => s.addItem)
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  if (!product) return null
  const off = discountPercent(product.price, product.salePrice)
  return (
    <Modal open={!!product} onClose={onClose} title="Quick View" wide>
      <div className="grid sm:grid-cols-2 gap-5">
        <img src={product.images?.[0]} alt={product.name} className="rounded-xl w-full aspect-square object-cover bg-[#1A1A1A]" />
        <div>
          <p className="text-xs text-white/50">{product.brand}</p>
          <h3 className="text-xl font-semibold mt-1">{product.name}</h3>
          <p className="text-[#F5A623] text-lg font-bold mt-3">
            {formatBdt(product.salePrice)}{' '}
            {off > 0 ? <span className="text-sm text-white/40 line-through font-normal">{formatBdt(product.price)}</span> : null}
          </p>
          <p className="text-sm text-white/60 mt-3 line-clamp-4">{product.description}</p>
          <div className="flex gap-2 mt-5">
            <Button
              onClick={() => {
                addItem(product, 1)
                playSound('cart', soundEnabled)
                onClose()
              }}
            >
              Add to Cart
            </Button>
            <Link to={`/product/${product.id}`} onClick={onClose}>
              <Button variant="outline">View details</Button>
            </Link>
          </div>
        </div>
      </div>
    </Modal>
  )
}

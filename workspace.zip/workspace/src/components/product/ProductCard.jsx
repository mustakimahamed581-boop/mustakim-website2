import { Heart, Eye, ShoppingCart, Zap } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { formatBdt, discountPercent } from '../../utils/format'
import { useWishlistStore } from '../../store/wishlistStore'
import { useCartStore } from '../../store/cartStore'
import { useUiStore } from '../../store/uiStore'
import { playSound } from '../../services/sound'
import { useToast } from '../../hooks/useToast'
import { BADGE_STYLES } from '../../data/constants'

export default function ProductCard({ product, onQuickView, compact }) {
  const navigate = useNavigate()
  const toast = useToast()
  const toggleWish = useWishlistStore((s) => s.toggle)
  const wished = useWishlistStore((s) => s.ids.includes(product.id))
  const addItem = useCartStore((s) => s.addItem)
  const soundEnabled = useUiStore((s) => s.soundEnabled)
  const setCartOpen = useUiStore((s) => s.setCartOpen)

  const off = discountPercent(product.price, product.salePrice)
  const badges = []
  if (product.flags?.bestSeller) badges.push('BEST SELLER')
  if (product.flags?.trending) badges.push('TRENDING')
  if (product.flags?.featured && !product.flags?.bestSeller) badges.push('POPULAR')
  if (product.flags?.newArrival) badges.push('NEW')
  if (off >= 10) badges.push('SALE')
  if (product.stock > 0 && product.stock <= (product.lowStock || 5)) badges.push('LOW STOCK')

  const add = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (product.stock <= 0) return toast({ type: 'error', title: 'Out of stock' })
    addItem(product, 1)
    playSound('cart', soundEnabled)
    toast({ type: 'success', title: 'Added to cart', message: product.name })
    setCartOpen(true)
  }

  const buy = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (product.stock <= 0) return toast({ type: 'error', title: 'Out of stock' })
    addItem(product, 1)
    playSound('buy', soundEnabled)
    navigate('/checkout')
  }

  return (
    <motion.article
      layout
      whileHover={{ y: compact ? 0 : -4 }}
      className="group relative rounded-2xl border border-white/8 bg-[#111] overflow-hidden flex flex-col"
    >
      <Link to={`/product/${product.id}`} className="relative block aspect-square bg-[#1A1A1A]">
        <img
          src={product.images?.[0]}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {badges.slice(0, compact ? 1 : 2).map((b) => (
            <span key={b} className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${BADGE_STYLES[b]}`}>
              {b}
            </span>
          ))}
        </div>
        <button
          className={`absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center ${wished ? 'bg-red-500 text-white' : 'bg-black/50 text-white'}`}
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            toggleWish(product.id)
          }}
          aria-label="Wishlist"
        >
          <Heart size={14} fill={wished ? 'currentColor' : 'none'} />
        </button>
        {product.stock <= 0 ? (
          <div className="absolute inset-0 bg-black/55 grid place-items-center text-sm font-semibold">Out of stock</div>
        ) : null}
      </Link>
      <div className="p-3 flex flex-col gap-1 flex-1">
        <p className="text-[11px] uppercase tracking-wide text-white/45">{product.brand}</p>
        <Link to={`/product/${product.id}`} className="font-medium text-sm line-clamp-2 hover:text-[#F5A623]">
          {product.name}
        </Link>
        <p className="text-xs text-amber-400">
          {'★'.repeat(Math.round(product.rating || 0))}
          <span className="text-white/50 ml-1">{product.rating} ({product.reviewCount})</span>
        </p>
        <div className="flex items-baseline gap-2 mt-1">
          <span className="text-[#F5A623] font-bold">{formatBdt(product.salePrice)}</span>
          {off > 0 ? <span className="text-xs text-white/40 line-through">{formatBdt(product.price)}</span> : null}
          {off > 0 ? <span className="text-[11px] text-emerald-400">{off}% OFF</span> : null}
        </div>
        <div className={`mt-auto pt-2 grid gap-1.5 ${compact ? 'grid-cols-1' : 'grid-cols-2'}`}>
          <button
            onClick={add}
            className="rounded-lg bg-[#F5A623] text-black text-xs font-semibold py-2 flex items-center justify-center gap-1"
          >
            <ShoppingCart size={13} /> Add to Cart
          </button>
          {!compact ? (
            <button
              onClick={buy}
              className="rounded-lg bg-white/10 text-white text-xs font-semibold py-2 flex items-center justify-center gap-1"
            >
              <Zap size={13} /> Buy Now
            </button>
          ) : null}
        </div>
        {!compact ? (
          <button
            onClick={(e) => {
              e.preventDefault()
              onQuickView?.(product)
            }}
            className="text-[11px] text-white/50 hover:text-white flex items-center justify-center gap-1 py-1"
          >
            <Eye size={12} /> Quick View
          </button>
        ) : null}
      </div>
    </motion.article>
  )
}

import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Search, X, Clock } from 'lucide-react'
import { useUiStore } from '../../store/uiStore'
import { useCatalogStore } from '../../store/catalogStore'
import { Link } from 'react-router-dom'
import { formatBdt } from '../../utils/format'
import { createPersisted } from '../../store/persist'

const useRecent = createPersisted('mg-recent-search', (set, get) => ({
  items: ['iPhone', 'AirPods', 'Charger'],
  push: (q) => {
    const t = q.trim()
    if (!t) return
    set({ items: [t, ...get().items.filter((x) => x.toLowerCase() !== t.toLowerCase())].slice(0, 8) })
  },
}))

export default function SearchOverlay() {
  const open = useUiStore((s) => s.searchOpen)
  const setSearchOpen = useUiStore((s) => s.setSearchOpen)
  const products = useCatalogStore((s) => s.products)
  const [q, setQ] = useState('')
  const recent = useRecent((s) => s.items)
  const push = useRecent((s) => s.push)
  const popular = ['iPhone 15', 'Galaxy S24', 'Earbuds', 'Power Bank']

  const results = useMemo(() => {
    const s = q.trim().toLowerCase()
    if (!s) return []
    return products.filter((p) =>
      [p.name, p.brand, p.sku, p.keywords?.join(' '), p.categoryId]
        .join(' ')
        .toLowerCase()
        .includes(s),
    ).slice(0, 8)
  }, [q, products])

  if (!open) return null
  return (
    <AnimatePresence>
      <motion.div className="fixed inset-0 z-[70]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <button className="absolute inset-0 bg-black/70" onClick={() => setSearchOpen(false)} aria-label="Close search" />
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative mx-auto mt-4 sm:mt-16 w-[min(92vw,720px)] rounded-2xl bg-[#111] border border-white/10 p-4"
        >
          <div className="flex items-center gap-2 rounded-xl bg-white/5 px-3">
            <Search size={18} className="text-white/40" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search phones, accessories, SKU..."
              className="flex-1 bg-transparent py-3 outline-none"
            />
            <button onClick={() => setSearchOpen(false)} aria-label="Close">
              <X size={18} />
            </button>
          </div>
          {!q ? (
            <div className="grid sm:grid-cols-2 gap-4 mt-4 text-sm">
              <div>
                <p className="text-white/50 mb-2 flex items-center gap-1"><Clock size={14} /> Recent</p>
                {recent.map((r) => (
                  <button key={r} className="block py-1 hover:text-[#F5A623]" onClick={() => setQ(r)}>
                    {r}
                  </button>
                ))}
              </div>
              <div>
                <p className="text-white/50 mb-2">Popular</p>
                {popular.map((r) => (
                  <button key={r} className="block py-1 hover:text-[#F5A623]" onClick={() => setQ(r)}>
                    {r}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <p className="text-center text-white/50 py-8">No products found</p>
          ) : (
            <ul className="mt-3 divide-y divide-white/5">
              {results.map((p) => (
                <li key={p.id}>
                  <Link
                    to={`/product/${p.id}`}
                    onClick={() => {
                      push(q)
                      setSearchOpen(false)
                    }}
                    className="flex items-center gap-3 py-2 hover:bg-white/5 rounded-lg px-1"
                  >
                    <img src={p.images[0]} alt="" className="w-12 h-12 rounded-lg object-cover" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{p.name}</p>
                      <p className="text-xs text-white/50">{p.brand} · {p.sku}</p>
                    </div>
                    <span className="text-[#F5A623] text-sm">{formatBdt(p.salePrice)}</span>
                  </Link>
                </li>
              ))}
              <li className="pt-2">
                <Link to={`/shop?q=${encodeURIComponent(q)}`} onClick={() => { push(q); setSearchOpen(false) }} className="text-sm text-[#F5A623]">
                  View all results
                </Link>
              </li>
            </ul>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

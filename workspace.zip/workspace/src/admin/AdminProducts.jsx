import { useMemo, useState } from 'react'
import { useCatalogStore } from '../store/catalogStore'
import { formatBdt } from '../utils/format'
import Button from '../components/ui/Button'
import { useToast } from '../hooks/useToast'
import { slugify } from '../utils/format'

const empty = () => ({
  id: '',
  name: '',
  brand: '',
  categoryId: 'cat-phones',
  sku: '',
  barcode: '',
  price: 0,
  salePrice: 0,
  stock: 0,
  lowStock: 5,
  weight: 0,
  rating: 5,
  reviewCount: 0,
  images: ['', '', '', '', '', '', '', '', '', ''],
  video: '',
  description: '',
  specifications: [{ label: '', value: '' }],
  features: [''],
  warranty: '1 Year Official Warranty',
  variants: { color: [], storage: [], ram: [], size: [], model: [] },
  flags: { featured: false, trending: false, bestSeller: false, newArrival: false, flashSale: false, recommended: false },
  enabled: true,
  keywords: [],
})

export default function AdminProducts() {
  const products = useCatalogStore((s) => s.products)
  const categories = useCatalogStore((s) => s.categories)
  const upsertProduct = useCatalogStore((s) => s.upsertProduct)
  const deleteProduct = useCatalogStore((s) => s.deleteProduct)
  const duplicateProduct = useCatalogStore((s) => s.duplicateProduct)
  const setProductEnabled = useCatalogStore((s) => s.setProductEnabled)
  const adjustStock = useCatalogStore((s) => s.adjustStock)
  const setStock = useCatalogStore((s) => s.setStock)
  const bulkUpdate = useCatalogStore((s) => s.bulkUpdate)
  const importProducts = useCatalogStore((s) => s.importProducts)
  const toast = useToast()
  const [q, setQ] = useState('')
  const [edit, setEdit] = useState(null)
  const [sel, setSel] = useState([])
  const [filter, setFilter] = useState({ cat: '', brand: '', stock: '', vis: '' })
  const list = useMemo(() => {
    return products.filter((p) => {
      const hit = [p.name, p.sku, p.brand, p.barcode].join(' ').toLowerCase().includes(q.toLowerCase())
      if (!hit) return false
      if (filter.cat && p.categoryId !== filter.cat) return false
      if (filter.brand && p.brand !== filter.brand) return false
      if (filter.stock === 'out' && p.stock > 0) return false
      if (filter.stock === 'low' && !(p.stock > 0 && p.stock <= (p.lowStock || 5))) return false
      if (filter.vis === 'hidden' && p.enabled) return false
      if (filter.vis === 'shown' && !p.enabled) return false
      return true
    })
  }, [products, q, filter])
  const brands = [...new Set(products.map((p) => p.brand))].sort()

  const save = (e) => {
    e.preventDefault()
    const p = {
      ...edit,
      id: edit.id || `p-${slugify(edit.name)}-${Date.now().toString(36)}`,
      images: (edit.images || []).filter(Boolean),
      features: (edit.features || []).filter(Boolean),
      keywords: String(edit.keywords || '').split(',').map((s) => s.trim()).filter(Boolean),
      price: Number(edit.price),
      salePrice: Number(edit.salePrice),
      stock: Number(edit.stock),
    }
    upsertProduct(p)
    toast({ type: 'success', title: 'Product saved' })
    setEdit(null)
  }

  return (
    <div>
      <div className="flex flex-wrap gap-2 justify-between mb-4">
        <h1 className="text-2xl font-bold text-violet-950">Products</h1>
        <Button variant="admin" onClick={() => setEdit(empty())}>Add product</Button>
      </div>
      <div className="flex flex-wrap gap-2 mb-3">
        <input className="flex-1 min-w-[180px] border rounded-xl px-3 py-2" placeholder="Search name / SKU / brand / barcode" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="border rounded-xl px-2" value={filter.cat} onChange={(e) => setFilter({ ...filter, cat: e.target.value })}>
          <option value="">All categories</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select className="border rounded-xl px-2" value={filter.brand} onChange={(e) => setFilter({ ...filter, brand: e.target.value })}>
          <option value="">All brands</option>
          {brands.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
        <select className="border rounded-xl px-2" value={filter.stock} onChange={(e) => setFilter({ ...filter, stock: e.target.value })}>
          <option value="">Any stock</option>
          <option value="low">Low stock</option>
          <option value="out">Out of stock</option>
        </select>
        <select className="border rounded-xl px-2" value={filter.vis} onChange={(e) => setFilter({ ...filter, vis: e.target.value })}>
          <option value="">Shown + Hidden</option>
          <option value="shown">Published</option>
          <option value="hidden">Hidden</option>
        </select>
      </div>
      {sel.length ? (
        <div className="flex flex-wrap gap-2 mb-3 text-sm">
          <Button variant="admin" className="!py-1.5" onClick={() => { bulkUpdate(sel, { enabled: true }); setSel([]); toast({ type: 'success', title: 'Published' }) }}>Publish</Button>
          <Button variant="dark" className="!py-1.5" onClick={() => { bulkUpdate(sel, { enabled: false }); setSel([]); toast({ title: 'Hidden' }) }}>Hide</Button>
          <Button variant="admin" className="!py-1.5" onClick={() => { bulkUpdate(sel, { flags: { featured: true } }); setSel([]) }}>Featured</Button>
          <Button variant="danger" className="!py-1.5" onClick={() => { if (confirm(`Delete ${sel.length} products?`)) { sel.forEach(deleteProduct); setSel([]) } }}>Delete</Button>
        </div>
      ) : null}
      <label className="text-xs text-zinc-500 block mb-3">
        Import JSON
        <input type="file" accept="application/json" className="block mt-1" onChange={async (e) => {
          const f = e.target.files?.[0]
          if (!f) return
          try {
            const data = JSON.parse(await f.text())
            const listIn = Array.isArray(data) ? data : data.products
            if (!Array.isArray(listIn)) throw new Error('Invalid')
            importProducts(listIn)
            toast({ type: 'success', title: `Imported ${listIn.length} products` })
          } catch {
            toast({ type: 'error', title: 'Import failed' })
          }
        }} />
      </label>
      <div className="bg-white rounded-2xl shadow-sm overflow-x-auto">
        <table className="w-full text-sm min-w-[860px]">
          <thead className="bg-violet-50 text-left">
            <tr>
              <th className="p-3"><input type="checkbox" onChange={(e) => setSel(e.target.checked ? list.map((p) => p.id) : [])} /></th>
              <th>Product</th>
              <th>SKU</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="p-3"><input type="checkbox" checked={sel.includes(p.id)} onChange={() => setSel((s) => s.includes(p.id) ? s.filter((x) => x !== p.id) : [...s, p.id])} /></td>
                <td className="p-3 flex items-center gap-2">
                  <img src={p.images?.[0]} alt="" className="w-10 h-10 rounded object-cover" />
                  <span>{p.name}</span>
                </td>
                <td className="font-mono text-xs">{p.sku}</td>
                <td>{formatBdt(p.salePrice)}</td>
                <td className={p.stock <= (p.lowStock || 5) ? 'text-red-600' : ''}>
                  {p.stock}
                  <div className="flex gap-1 mt-1">
                    <button className="text-xs px-1 bg-zinc-100 rounded" onClick={() => adjustStock(p.id, 10)}>+10</button>
                    <button className="text-xs px-1 bg-zinc-100 rounded" onClick={() => adjustStock(p.id, -5)}>-5</button>
                    <button className="text-xs px-1 bg-zinc-100 rounded" onClick={() => { const n = prompt('Set stock', p.stock); if (n != null) setStock(p.id, n) }}>Set</button>
                  </div>
                </td>
                <td>
                  <button className={`text-xs px-2 py-0.5 rounded-full ${p.enabled ? 'bg-emerald-100 text-emerald-700' : 'bg-zinc-200'}`} onClick={() => setProductEnabled(p.id, !p.enabled)}>
                    {p.enabled ? 'Published' : 'Hidden'}
                  </button>
                </td>
                <td className="p-3 space-x-2 whitespace-nowrap">
                  <button className="text-violet-600" onClick={() => setEdit({ ...p, keywords: (p.keywords || []).join(', '), images: [...(p.images || []), ...Array(Math.max(0, 10 - (p.images || []).length)).fill('')].slice(0, 10) })}>Edit</button>
                  <button className="text-zinc-500" onClick={() => duplicateProduct(p.id)}>Duplicate</button>
                  <button className="text-red-500" onClick={() => { if (confirm('Delete this product?')) deleteProduct(p.id) }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {edit ? (
        <div className="fixed inset-0 z-50 bg-black/40 grid place-items-center p-4">
          <form onSubmit={save} className="bg-white rounded-2xl p-5 w-full max-w-2xl max-h-[90dvh] overflow-y-auto space-y-2 text-sm">
            <h2 className="text-lg font-bold">{edit.id ? 'Edit' : 'Add'} product</h2>
            {['name', 'brand', 'sku', 'barcode', 'warranty', 'video'].map((k) => (
              <input key={k} className="w-full border rounded-lg p-2" placeholder={k} value={edit[k] || ''} onChange={(e) => setEdit({ ...edit, [k]: e.target.value })} />
            ))}
            <select className="w-full border rounded-lg p-2" value={edit.categoryId} onChange={(e) => setEdit({ ...edit, categoryId: e.target.value })}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <div className="grid grid-cols-2 gap-2">
              {['price', 'salePrice', 'stock', 'lowStock', 'weight'].map((k) => (
                <input key={k} type="number" className="border rounded-lg p-2" placeholder={k} value={edit[k]} onChange={(e) => setEdit({ ...edit, [k]: e.target.value })} />
              ))}
            </div>
            <textarea className="w-full border rounded-lg p-2" rows={3} placeholder="Description" value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
            <p className="font-semibold">Images (max 10) — URL or upload</p>
            {(edit.images || []).slice(0, 10).map((src, i) => (
              <div key={i} className="flex gap-2 items-center">
                {src ? <img src={src} alt="" className="w-10 h-10 rounded object-cover" /> : <span className="w-10 h-10 bg-zinc-100 rounded" />}
                <input className="flex-1 border rounded-lg p-2" placeholder={`Image ${i + 1} URL`} value={src} onChange={(e) => {
                  const images = [...(edit.images || [])]
                  images[i] = e.target.value
                  setEdit({ ...edit, images })
                }} />
                <input type="file" accept="image/*" onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  const reader = new FileReader()
                  reader.onload = () => {
                    const images = [...(edit.images || [])]
                    images[i] = reader.result
                    setEdit({ ...edit, images })
                  }
                  reader.readAsDataURL(f)
                }} />
                <button type="button" className="text-xs" onClick={() => {
                  const images = [...(edit.images || [])]
                  if (i > 0) { const t = images[i - 1]; images[i - 1] = images[i]; images[i] = t; setEdit({ ...edit, images }) }
                }}>Up</button>
                <button type="button" className="text-red-500 text-xs" onClick={() => {
                  const images = [...(edit.images || [])]
                  images[i] = ''
                  setEdit({ ...edit, images })
                }}>Del</button>
              </div>
            ))}
            {(edit.images || []).filter(Boolean).length < 10 ? (
              <button type="button" className="text-xs text-violet-700" onClick={() => setEdit({ ...edit, images: [...(edit.images || []), ''].slice(0, 10) })}>+ Add image slot</button>
            ) : null}
            <input className="w-full border rounded-lg p-2" placeholder="Features comma-separated" value={(edit.features || []).join(', ')} onChange={(e) => setEdit({ ...edit, features: e.target.value.split(',').map((s) => s.trim()) })} />
            <input className="w-full border rounded-lg p-2" placeholder="Keywords comma-separated" value={edit.keywords || ''} onChange={(e) => setEdit({ ...edit, keywords: e.target.value })} />
            <div className="flex flex-wrap gap-3">
              {Object.keys(edit.flags).map((k) => (
                <label key={k} className="flex items-center gap-1 capitalize">
                  <input type="checkbox" checked={edit.flags[k]} onChange={(e) => setEdit({ ...edit, flags: { ...edit.flags, [k]: e.target.checked } })} /> {k}
                </label>
              ))}
              <label className="flex items-center gap-1"><input type="checkbox" checked={edit.enabled} onChange={(e) => setEdit({ ...edit, enabled: e.target.checked })} /> Enabled</label>
            </div>
            <p className="text-xs text-zinc-500">Variants (comma-separated)</p>
            {['color', 'storage', 'ram', 'size', 'model'].map((k) => (
              <input key={k} className="w-full border rounded-lg p-2" placeholder={k} value={(edit.variants?.[k] || []).join(', ')} onChange={(e) => setEdit({ ...edit, variants: { ...edit.variants, [k]: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) } })} />
            ))}
            <div className="flex gap-2 pt-2">
              <Button variant="admin" type="submit">Save</Button>
              <Button variant="dark" className="!text-white" type="button" onClick={() => setEdit(null)}>Cancel</Button>
            </div>
          </form>
        </div>
      ) : null}
    </div>
  )
}

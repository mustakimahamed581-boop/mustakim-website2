import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { useOrderStore } from '../store/orderStore'
import { useCatalogStore } from '../store/catalogStore'
import { useUserStore } from '../store/userStore'
import { formatBdt, formatDate } from '../utils/format'
import { STATUS_LABELS } from '../data/constants'

export default function AdminDashboard() {
  const orders = useOrderStore((s) => s.orders)
  const products = useCatalogStore((s) => s.products)
  const users = useUserStore((s) => s.users)
  const sales = orders.filter((o) => o.status !== 'cancelled').reduce((n, o) => n + (o.totals?.grandTotal || 0), 0)
  const low = products.filter((p) => p.stock <= (p.lowStock || 5))
  const top = [...products].sort((a, b) => b.reviewCount - a.reviewCount).slice(0, 5)
  const chart = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date()
      d.setDate(d.getDate() - (6 - i))
      const key = d.toISOString().slice(0, 10)
      const dayOrders = orders.filter((o) => o.createdAt?.slice(0, 10) === key)
      return { key: key.slice(5), value: dayOrders.reduce((n, o) => n + (o.totals?.grandTotal || 0), 0), count: dayOrders.length }
    })
    const max = Math.max(...days.map((d) => d.value), 1)
    return days.map((d) => ({ ...d, h: Math.round((d.value / max) * 100) }))
  }, [orders])

  const cards = [
    ['Total Sales', formatBdt(sales), 'text-violet-700'],
    ['Total Orders', orders.length, 'text-fuchsia-700'],
    ['Pending', orders.filter((o) => o.status === 'pending' || o.status === 'processing').length, 'text-amber-600'],
    ['Delivered', orders.filter((o) => o.status === 'delivered').length, 'text-emerald-600'],
    ['Customers', users.length, 'text-sky-700'],
    ['Products', products.length, 'text-violet-600'],
    ['Low Stock', low.length, 'text-red-600'],
    ['Returns', orders.filter((o) => o.status === 'returned').length, 'text-zinc-600'],
  ]

  return (
    <div>
      <h1 className="text-2xl font-bold text-violet-950 mb-4">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map(([l, v, c]) => (
          <div key={l} className="bg-white rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-zinc-500">{l}</p>
            <p className={`text-2xl font-bold ${c}`}>{v}</p>
          </div>
        ))}
      </div>
      <div className="grid lg:grid-cols-2 gap-4 mt-6">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-semibold mb-3">Sales overview</h2>
          <div className="flex items-end gap-2 h-40">
            {chart.map((d) => (
              <div key={d.key} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full bg-violet-500 rounded-t" style={{ height: `${Math.max(d.h, 8)}%` }} title={formatBdt(d.value)} />
                <span className="text-[10px] text-zinc-400">{d.key}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-semibold mb-3">Recent orders</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <tbody>
                {orders.slice(0, 6).map((o) => (
                  <tr key={o.id} className="border-b border-zinc-100">
                    <td className="py-2 font-mono text-xs">{o.id}</td>
                    <td>{formatBdt(o.totals.grandTotal)}</td>
                    <td><span className="text-xs px-2 py-0.5 rounded-full bg-violet-50">{STATUS_LABELS[o.status]}</span></td>
                    <td className="text-zinc-400 text-xs">{formatDate(o.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-semibold mb-2">Top products</h2>
          {top.map((p) => (
            <div key={p.id} className="flex justify-between text-sm py-1">
              <span>{p.name}</span>
              <span className="text-zinc-400">{p.reviewCount} sold-eq</span>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex justify-between">
            <h2 className="font-semibold">Low stock alerts</h2>
            <Link to="/admin/products" className="text-violet-600 text-sm">Manage</Link>
          </div>
          {low.map((p) => (
            <p key={p.id} className="text-sm py-1 text-red-600">{p.name} — {p.stock} left</p>
          ))}
        </div>
      </div>
    </div>
  )
}

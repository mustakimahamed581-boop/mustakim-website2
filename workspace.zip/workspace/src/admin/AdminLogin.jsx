import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAdminStore } from '../store/adminStore'
import { Shield } from 'lucide-react'

export default function AdminLogin() {
  const login = useAdminStore((s) => s.login)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = (e) => {
    e.preventDefault()
    const res = login(password)
    if (!res.ok) {
      setError(res.message)
      return
    }
    navigate('/admin')
  }

  return (
    <div className="min-h-dvh admin-app grid place-items-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm bg-white rounded-2xl shadow-xl p-8">
        <div className="w-12 h-12 rounded-2xl bg-violet-600 text-white grid place-items-center mx-auto mb-4">
          <Shield />
        </div>
        <h1 className="text-center text-xl font-bold text-violet-900">ADMIN PANEL</h1>
        <p className="text-center text-sm text-zinc-500 mt-1">Mustakim Gadgets</p>
        <label className="block mt-8 text-xs font-semibold tracking-widest text-zinc-500">ENTER ADMIN PASSWORD</label>
        <input
          type="password"
          autoFocus
          value={password}
          onChange={(e) => { setPassword(e.target.value); setError('') }}
          className="w-full mt-2 border rounded-xl px-3 py-3 tracking-widest"
          placeholder="********"
        />
        {error ? <p className="text-red-600 text-sm mt-2">{error}</p> : null}
        <button type="submit" className="w-full mt-5 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl py-3">
          LOGIN
        </button>
      </form>
    </div>
  )
}

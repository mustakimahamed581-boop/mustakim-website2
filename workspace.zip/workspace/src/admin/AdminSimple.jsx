import { useState } from 'react'
import { useCatalogStore } from '../store/catalogStore'
import { useOrderStore } from '../store/orderStore'
import { useUserStore } from '../store/userStore'
import { useSettingsStore } from '../store/settingsStore'
import { useAdminStore } from '../store/adminStore'
import { formatBdt, formatDate, formatDateTime } from '../utils/format'
import { STATUS_LABELS, ORDER_STATUSES, PAYMENT_LABELS } from '../data/constants'
import Button from '../components/ui/Button'
import { useToast } from '../hooks/useToast'
import { testConnection, createCourierParcel } from '../services/adapters'
import { Link } from 'react-router-dom'
import { slugify } from '../utils/format'

export function AdminCategories() {
  const categories = useCatalogStore((s) => s.categories)
  const upsertCategory = useCatalogStore((s) => s.upsertCategory)
  const deleteCategory = useCatalogStore((s) => s.deleteCategory)
  const reorderCategories = useCatalogStore((s) => s.reorderCategories)
  const toast = useToast()
  const [form, setForm] = useState({ id: '', name: '', nameBn: '', slug: '', icon: 'Smartphone', image: '', enabled: true, order: categories.length + 1 })
  return (
    <AdminCard title="Categories">
      <form
        className="grid sm:grid-cols-2 gap-2 mb-4"
        onSubmit={(e) => {
          e.preventDefault()
          upsertCategory({ ...form, id: form.id || `cat-${slugify(form.name)}`, slug: form.slug || slugify(form.name) })
          toast({ type: 'success', title: 'Category saved' })
          setForm({ id: '', name: '', nameBn: '', slug: '', icon: 'Smartphone', image: '', enabled: true, order: categories.length + 1 })
        }}
      >
        {['name', 'nameBn', 'slug', 'icon', 'image'].map((k) => (
          <input key={k} className="border rounded-lg p-2" placeholder={k} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
        ))}
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} /> Enabled</label>
        <Button variant="admin" type="submit">Save</Button>
      </form>
      <ul className="space-y-2">
        {categories.map((c, i) => (
          <li key={c.id} className="flex items-center gap-2 bg-violet-50/50 rounded-xl p-2 text-sm">
            <span className="w-8 text-zinc-400">{c.order}</span>
            <span className="flex-1">{c.name}</span>
            <button onClick={() => { const arr = [...categories]; if (i) { [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; reorderCategories(arr.map((x, idx) => ({ ...x, order: idx + 1 }))) } }}>Up</button>
            <button className="text-violet-600" onClick={() => setForm(c)}>Edit</button>
            <button className="text-red-500" onClick={() => deleteCategory(c.id)}>Delete</button>
            <button onClick={() => upsertCategory({ ...c, enabled: !c.enabled })}>{c.enabled ? 'Disable' : 'Enable'}</button>
          </li>
        ))}
      </ul>
    </AdminCard>
  )
}

export function AdminOrders() {
  const orders = useOrderStore((s) => s.orders)
  const setStatus = useOrderStore((s) => s.setStatus)
  const setCourier = useOrderStore((s) => s.setCourier)
  const courier = useSettingsStore((s) => s.courier)
  const toast = useToast()
  const [q, setQ] = useState('')
  const [status, setSt] = useState('')
  const list = orders.filter((o) => (!status || o.status === status) && o.id.toLowerCase().includes(q.toLowerCase()))
  return (
    <AdminCard title="Orders">
      <div className="flex gap-2 mb-3">
        <input className="border rounded-lg px-3 py-2 flex-1" placeholder="Search order ID" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="border rounded-lg px-2" value={status} onChange={(e) => setSt(e.target.value)}>
          <option value="">All</option>
          {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[800px]">
          <thead><tr className="text-left text-zinc-500"><th className="py-2">ID</th><th>Customer</th><th>Total</th><th>Pay</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {list.map((o) => (
              <tr key={o.id} className="border-t">
                <td className="py-2 font-mono text-xs">{o.id}</td>
                <td>{o.customer.name}</td>
                <td>{formatBdt(o.totals.grandTotal)}</td>
                <td>{PAYMENT_LABELS[o.paymentMethod]}</td>
                <td>
                  <select className="border rounded p-1" value={o.status} onChange={(e) => setStatus(o.id, e.target.value)}>
                    {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
                  </select>
                </td>
                <td className="space-x-2 whitespace-nowrap">
                  <Link className="text-violet-600" to={`/account/orders/${o.id}/invoice`}>Invoice</Link>
                  <button
                    className="text-violet-600"
                    onClick={async () => {
                      const res = await createCourierParcel({ mockMode: courier.mockMode, order: o })
                      if (!res.ok) return toast({ type: 'error', title: res.message })
                      setCourier(o.id, { consignmentId: res.consignmentId, trackingCode: res.trackingCode, status: res.status })
                      toast({ type: 'success', title: res.message })
                    }}
                  >
                    Create parcel
                  </button>
                  <button
                    onClick={() => {
                      const tracking = prompt('Tracking ID', o.courier?.trackingCode || '')
                      if (tracking != null) setCourier(o.id, { trackingCode: tracking, status: 'in_transit' })
                    }}
                  >
                    Tracking
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminCard>
  )
}

export function AdminCustomers() {
  const users = useUserStore((s) => s.users)
  const orders = useOrderStore((s) => s.orders)
  const setUserStatus = useUserStore((s) => s.setUserStatus)
  const deleteUser = useUserStore((s) => s.deleteUser)
  return (
    <AdminCard title="Customers">
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[700px]">
          <thead><tr className="text-left text-zinc-500"><th className="py-2">Name</th><th>Phone</th><th>Email</th><th>Joined</th><th>Orders</th><th>Spent</th><th>Status</th><th /></tr></thead>
          <tbody>
            {users.map((u) => {
              const uo = orders.filter((o) => o.userId === u.id)
              const spent = uo.reduce((n, o) => n + (o.totals?.grandTotal || 0), 0)
              return (
                <tr key={u.id} className="border-t">
                  <td className="py-2">{u.name}</td>
                  <td>{u.phone}</td>
                  <td>{u.email}</td>
                  <td>{formatDate(u.registeredAt)}</td>
                  <td>{uo.length}</td>
                  <td>{formatBdt(spent)}</td>
                  <td>{u.status}</td>
                  <td className="space-x-2">
                    <button className="text-violet-600" onClick={() => setUserStatus(u.id, u.status === 'blocked' ? 'active' : 'blocked')}>{u.status === 'blocked' ? 'Unblock' : 'Block'}</button>
                    <button className="text-red-500" onClick={() => { if (confirm('Delete customer?')) deleteUser(u.id) }}>Delete</button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </AdminCard>
  )
}

export function AdminCoupons() {
  const coupons = useCatalogStore((s) => s.coupons)
  const upsertCoupon = useCatalogStore((s) => s.upsertCoupon)
  const deleteCoupon = useCatalogStore((s) => s.deleteCoupon)
  const toast = useToast()
  const [form, setForm] = useState({ id: '', code: '', type: 'percent', value: 10, minOrder: 0, maxDiscount: 0, startDate: '', endDate: '', usageLimit: 100, perUserLimit: 1, usedCount: 0, enabled: true })
  return (
    <AdminCard title="Coupons">
      <form
        className="grid sm:grid-cols-3 gap-2 mb-4"
        onSubmit={(e) => {
          e.preventDefault()
          upsertCoupon({ ...form, id: form.id || `cp-${form.code}`, value: Number(form.value), minOrder: Number(form.minOrder), maxDiscount: Number(form.maxDiscount) })
          toast({ type: 'success', title: 'Coupon saved' })
        }}
      >
        <input className="border rounded-lg p-2" placeholder="CODE" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} />
        <select className="border rounded-lg p-2" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
          <option value="percent">Percentage</option>
          <option value="fixed">Fixed amount</option>
        </select>
        <input type="number" className="border rounded-lg p-2" placeholder="Value" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
        <input type="number" className="border rounded-lg p-2" placeholder="Min order" value={form.minOrder} onChange={(e) => setForm({ ...form, minOrder: e.target.value })} />
        <input type="number" className="border rounded-lg p-2" placeholder="Max discount" value={form.maxDiscount} onChange={(e) => setForm({ ...form, maxDiscount: e.target.value })} />
        <input type="date" className="border rounded-lg p-2" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
        <input type="date" className="border rounded-lg p-2" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
        <Button variant="admin" type="submit">Save coupon</Button>
      </form>
      {coupons.map((c) => (
        <div key={c.id} className="flex justify-between py-2 border-t text-sm">
          <span className="font-mono">{c.code}</span>
          <span>{c.type} {c.value} · used {c.usedCount}/{c.usageLimit}</span>
          <span>
            <button className="text-violet-600 mr-2" onClick={() => setForm(c)}>Edit</button>
            <button className="text-red-500" onClick={() => deleteCoupon(c.id)}>Delete</button>
          </span>
        </div>
      ))}
    </AdminCard>
  )
}

export function AdminFlash() {
  const flash = useCatalogStore((s) => s.flashSale)
  const products = useCatalogStore((s) => s.products)
  const setFlashSale = useCatalogStore((s) => s.setFlashSale)
  const toast = useToast()
  const [form, setForm] = useState(flash)
  return (
    <AdminCard title="Flash Sale">
      <label className="flex items-center gap-2 mb-3"><input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} /> Enabled</label>
      <input className="w-full border rounded-lg p-2 mb-2" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <input className="w-full border rounded-lg p-2 mb-2" value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} />
      <input className="w-full border rounded-lg p-2 mb-2" type="datetime-local" value={form.start?.slice(0, 16)} onChange={(e) => setForm({ ...form, start: e.target.value })} />
      <input className="w-full border rounded-lg p-2 mb-2" type="datetime-local" value={form.end?.slice(0, 16)} onChange={(e) => setForm({ ...form, end: e.target.value })} />
      <p className="text-sm mb-2">Products</p>
      <div className="grid sm:grid-cols-2 gap-1 max-h-64 overflow-y-auto text-sm">
        {products.map((p) => (
          <label key={p.id} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.productIds.includes(p.id)}
              onChange={(e) => setForm({
                ...form,
                productIds: e.target.checked ? [...form.productIds, p.id] : form.productIds.filter((id) => id !== p.id),
              })}
            />
            {p.name}
          </label>
        ))}
      </div>
      <Button variant="admin" className="mt-3" onClick={() => { setFlashSale(form); toast({ type: 'success', title: 'Flash sale saved' }) }}>Save</Button>
    </AdminCard>
  )
}

export function AdminBanners() {
  const banners = useCatalogStore((s) => s.banners)
  const heroSlides = useCatalogStore((s) => s.heroSlides)
  const upsertBanner = useCatalogStore((s) => s.upsertBanner)
  const deleteBanner = useCatalogStore((s) => s.deleteBanner)
  const upsertHero = useCatalogStore((s) => s.upsertHero)
  const deleteHero = useCatalogStore((s) => s.deleteHero)
  const toast = useToast()
  const [hero, setHero] = useState(heroSlides[0])
  return (
    <div className="space-y-6">
      <AdminCard title="Hero slides">
        <div className="grid sm:grid-cols-2 gap-2">
          {['heading', 'headingAccent', 'subtitle', 'buttonText', 'buttonUrl', 'secondaryText', 'secondaryUrl', 'image', 'badge'].map((k) => (
            <input key={k} className="border rounded-lg p-2" placeholder={k} value={hero?.[k] || ''} onChange={(e) => setHero({ ...hero, [k]: e.target.value })} />
          ))}
        </div>
        <label className="flex items-center gap-2 mt-2 text-sm"><input type="checkbox" checked={hero?.enabled} onChange={(e) => setHero({ ...hero, enabled: e.target.checked })} /> Enabled</label>
        <Button variant="admin" className="mt-3" onClick={() => { upsertHero(hero); toast({ type: 'success', title: 'Hero saved' }) }}>Save hero</Button>
        <ul className="mt-3 text-sm">
          {heroSlides.map((h) => (
            <li key={h.id} className="flex justify-between py-1">
              <button onClick={() => setHero(h)}>{h.heading}</button>
              <button className="text-red-500" onClick={() => deleteHero(h.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </AdminCard>
      <AdminCard title="Banners">
        {banners.map((b) => (
          <div key={b.id} className="flex justify-between py-2 border-t text-sm">
            <span>{b.title} · {b.type}</span>
            <span>
              <button className="text-violet-600 mr-2" onClick={() => upsertBanner({ ...b, enabled: !b.enabled })}>{b.enabled ? 'Disable' : 'Enable'}</button>
              <button className="text-red-500" onClick={() => deleteBanner(b.id)}>Delete</button>
            </span>
          </div>
        ))}
      </AdminCard>
    </div>
  )
}

export function AdminReviews() {
  const reviews = useCatalogStore((s) => s.reviews)
  const setReviewStatus = useCatalogStore((s) => s.setReviewStatus)
  const deleteReview = useCatalogStore((s) => s.deleteReview)
  return (
    <AdminCard title="Reviews">
      {reviews.map((r) => (
        <div key={r.id} className="border-t py-3 text-sm">
          <p className="font-medium">{r.title} · {r.rating}★ · {r.status}</p>
          <p className="text-zinc-500">{r.comment}</p>
          <div className="flex gap-2 mt-1">
            <button className="text-emerald-600" onClick={() => setReviewStatus(r.id, 'approved')}>Approve</button>
            <button className="text-amber-600" onClick={() => setReviewStatus(r.id, 'hidden')}>Hide</button>
            <button className="text-red-500" onClick={() => deleteReview(r.id)}>Delete</button>
          </div>
        </div>
      ))}
    </AdminCard>
  )
}

function SecretHint() {
  return <p className="text-xs text-amber-700 bg-amber-50 rounded-lg p-2 my-2">Secrets are stored only in this browser for the prototype. Production must use server-side environment variables — never ship private keys in public JS.</p>
}

export function AdminCourier() {
  const courier = useSettingsStore((s) => s.courier)
  const setCourier = useSettingsStore((s) => s.setCourier)
  const setIntegration = useSettingsStore((s) => s.setIntegration)
  const toast = useToast()
  const [form, setForm] = useState(courier)
  const test = async () => {
    toast({ title: 'Testing...' })
    const res = await testConnection({ mockMode: form.mockMode, configured: !!(form.apiKey && form.secretKey) })
    setCourier({ ...form, connected: res.ok, lastTest: new Date().toISOString() })
    setIntegration('steadfast', { status: res.status, mockMode: form.mockMode })
    toast({ type: res.ok ? 'success' : 'error', title: res.message })
  }
  return (
    <AdminCard title="Steadfast Courier">
      <SecretHint />
      {['apiKey', 'secretKey', 'merchantId', 'pickupName', 'pickupPhone', 'pickupAddress'].map((k) => (
        <input key={k} className="w-full border rounded-lg p-2 mb-2" placeholder={k} type={k.toLowerCase().includes('secret') || k === 'apiKey' ? 'password' : 'text'} value={form[k] || ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
      ))}
      <input type="number" className="w-full border rounded-lg p-2 mb-2" placeholder="Default delivery charge" value={form.defaultCharge} onChange={(e) => setForm({ ...form, defaultCharge: Number(e.target.value) })} />
      <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={form.mockMode} onChange={(e) => setForm({ ...form, mockMode: e.target.checked })} /> Enable DEMO MODE</label>
      <p className="text-sm mb-3">Status: <strong>{form.mockMode && form.connected ? 'DEMO CONNECTED' : form.connected ? 'CONNECTED' : 'NOT CONNECTED'}</strong></p>
      <div className="flex gap-2">
        <Button variant="admin" onClick={() => { setCourier(form); toast({ type: 'success', title: 'Saved locally' }) }}>Save</Button>
        <Button variant="dark" className="!text-white" onClick={test}>Test connection</Button>
      </div>
    </AdminCard>
  )
}

export function AdminPayments() {
  const payments = useSettingsStore((s) => s.payments)
  const setPayments = useSettingsStore((s) => s.setPayments)
  const setIntegration = useSettingsStore((s) => s.setIntegration)
  const toast = useToast()
  const [form, setForm] = useState(payments)
  const test = async (key) => {
    toast({ title: 'Testing...' })
    const cfg = form[key]
    const res = await testConnection({ mockMode: cfg.mockMode, configured: !!(cfg.apiKey || cfg.storeId || cfg.merchantId) })
    const next = { ...form, [key]: { ...cfg, connected: res.ok } }
    setForm(next)
    setPayments(next)
    setIntegration(key === 'sslcommerz' ? 'sslcommerz' : key, { status: res.status, mockMode: cfg.mockMode })
    toast({ type: res.ok ? 'success' : 'error', title: res.message })
  }
  return (
    <AdminCard title="Payment Settings">
      <SecretHint />
      {Object.entries(form).map(([key, cfg]) => (
        <div key={key} className="border rounded-xl p-3 mb-3">
          <div className="flex justify-between">
            <p className="font-semibold capitalize">{cfg.label || key}</p>
            <span className="text-xs">{cfg.mockMode && cfg.connected ? 'DEMO CONNECTED' : cfg.connected ? 'CONNECTED' : 'NOT CONNECTED'}</span>
          </div>
          <label className="flex items-center gap-2 text-sm mt-2"><input type="checkbox" checked={cfg.enabled} onChange={(e) => setForm({ ...form, [key]: { ...cfg, enabled: e.target.checked } })} /> Enable</label>
          {key !== 'cod' ? (
            <>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={cfg.sandbox} onChange={(e) => setForm({ ...form, [key]: { ...cfg, sandbox: e.target.checked } })} /> Sandbox</label>
              <label className="flex items-center gap-2 text-sm mb-2"><input type="checkbox" checked={cfg.mockMode} onChange={(e) => setForm({ ...form, [key]: { ...cfg, mockMode: e.target.checked } })} /> DEMO MODE</label>
              {key === 'sslcommerz' ? (
                <>
                  <input className="w-full border rounded-lg p-2 mb-1" placeholder="Store ID" value={cfg.storeId || ''} onChange={(e) => setForm({ ...form, [key]: { ...cfg, storeId: e.target.value } })} />
                  <input type="password" className="w-full border rounded-lg p-2 mb-1" placeholder="Store password" value={cfg.storePassword || ''} onChange={(e) => setForm({ ...form, [key]: { ...cfg, storePassword: e.target.value } })} />
                </>
              ) : (
                <>
                  <input className="w-full border rounded-lg p-2 mb-1" placeholder="Merchant ID" value={cfg.merchantId || ''} onChange={(e) => setForm({ ...form, [key]: { ...cfg, merchantId: e.target.value } })} />
                  <input type="password" className="w-full border rounded-lg p-2 mb-1" placeholder="API Key" value={cfg.apiKey || ''} onChange={(e) => setForm({ ...form, [key]: { ...cfg, apiKey: e.target.value } })} />
                  <input type="password" className="w-full border rounded-lg p-2 mb-1" placeholder="Secret" value={cfg.secret || cfg.password || ''} onChange={(e) => setForm({ ...form, [key]: { ...cfg, secret: e.target.value } })} />
                </>
              )}
              <Button variant="dark" className="!text-white !py-1 mt-1" onClick={() => test(key)}>Test connection</Button>
            </>
          ) : null}
        </div>
      ))}
      <Button variant="admin" onClick={() => { setPayments(form); toast({ type: 'success', title: 'Payments saved' }) }}>Save</Button>
    </AdminCard>
  )
}

export function AdminFirebase() {
  const firebase = useSettingsStore((s) => s.firebase)
  const setFirebase = useSettingsStore((s) => s.setFirebase)
  const setIntegration = useSettingsStore((s) => s.setIntegration)
  const toast = useToast()
  const [form, setForm] = useState(firebase)
  const configured = !!(form.apiKey && form.projectId)
  return (
    <AdminCard title="Firebase Configuration">
      <p className="text-xs text-zinc-500 mb-2">Public web config only. Never paste a service account JSON here.</p>
      {['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId', 'measurementId', 'databaseURL'].map((k) => (
        <input key={k} className="w-full border rounded-lg p-2 mb-2" placeholder={k} value={form[k] || ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
      ))}
      <div className="grid sm:grid-cols-2 gap-2 text-sm mb-3">
        {Object.keys(form.services).map((k) => (
          <label key={k} className="flex items-center gap-2 capitalize">
            <input type="checkbox" checked={form.services[k]} onChange={(e) => setForm({ ...form, services: { ...form.services, [k]: e.target.checked } })} /> {k}
          </label>
        ))}
      </div>
      <p className="text-sm mb-3">Status: <strong>{configured ? 'Configured (client)' : 'Not Configured'}</strong></p>
      <Button variant="admin" onClick={() => { setFirebase({ ...form, configured }); setIntegration('firebase', { status: configured ? 'connected' : 'not_connected' }); toast({ type: 'success', title: 'Firebase settings saved' }) }}>Save</Button>
    </AdminCard>
  )
}

export function AdminIntegrations() {
  const integrations = useSettingsStore((s) => s.integrations)
  const setIntegration = useSettingsStore((s) => s.setIntegration)
  const customApis = useSettingsStore((s) => s.customApis)
  const upsertCustomApi = useSettingsStore((s) => s.upsertCustomApi)
  const toast = useToast()
  const [custom, setCustom] = useState({ name: '', baseUrl: '', apiKey: '', secret: '', clientId: '', clientSecret: '', webhookUrl: '', docsUrl: '', notes: '' })
  return (
    <div>
      <h1 className="text-2xl font-bold text-violet-950 mb-4">API & Integrations Center</h1>
      <p className="text-sm text-zinc-500 mb-4">Never pretends a live connection exists until you test or enable DEMO MODE. Secrets stay in Admin storage — they are not sent to live vendors from the public frontend.</p>
      <Button
        variant="admin"
        className="mb-4"
        onClick={async () => {
          for (const i of integrations) {
            const res = await testConnection({ mockMode: i.mockMode, configured: i.status === 'connected' })
            setIntegration(i.id, { status: res.status, lastTest: new Date().toISOString() })
          }
          toast({ type: 'success', title: 'Test all finished' })
        }}
      >
        Test all APIs
      </Button>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {integrations.map((i) => (
          <div key={i.id} className="bg-white rounded-2xl p-4 shadow-sm">
            <p className="font-semibold">{i.name}</p>
            <p className="text-xs text-zinc-500 mt-1">{i.description}</p>
            <p className="text-xs mt-2 font-bold uppercase tracking-wide">
              {i.status === 'demo_connected' ? 'DEMO CONNECTED' : i.status === 'connected' ? 'CONNECTED' : i.status === 'error' ? 'ERROR' : 'NOT CONNECTED'}
            </p>
            <div className="flex flex-wrap gap-2 mt-3">
              <Link to={i.id === 'firebase' ? '/admin/firebase' : i.id === 'steadfast' ? '/admin/courier' : ['bkash', 'nagad', 'rocket', 'sslcommerz'].includes(i.id) ? '/admin/payments' : '/admin/integrations'} className="text-xs px-2 py-1 rounded-lg bg-violet-100 text-violet-800">Configure</Link>
              <button
                className="text-xs px-2 py-1 rounded-lg bg-zinc-100"
                onClick={async () => {
                  toast({ title: 'Testing...' })
                  const res = await testConnection({ mockMode: i.mockMode, configured: false })
                  setIntegration(i.id, { status: res.status })
                  toast({ type: res.ok ? 'success' : 'error', title: res.message })
                }}
              >
                Test connection
              </button>
              <button className="text-xs px-2 py-1 rounded-lg bg-zinc-100" onClick={() => setIntegration(i.id, { mockMode: !i.mockMode, status: !i.mockMode ? i.status : 'not_connected' })}>
                {i.mockMode ? 'Disable demo' : 'Enable demo'}
              </button>
            </div>
          </div>
        ))}
      </div>
      <AdminCard title="Custom API">
        <p className="text-xs text-zinc-500 mb-2">Stores a definition only. Arbitrary JavaScript is not executed.</p>
        {['name', 'baseUrl', 'apiKey', 'secret', 'clientId', 'clientSecret', 'webhookUrl', 'docsUrl', 'notes'].map((k) => (
          <input key={k} className="w-full border rounded-lg p-2 mb-2" placeholder={k} type={['apiKey', 'secret', 'clientSecret'].includes(k) ? 'password' : 'text'} value={custom[k]} onChange={(e) => setCustom({ ...custom, [k]: e.target.value })} />
        ))}
        <Button variant="admin" onClick={() => { upsertCustomApi(custom); toast({ type: 'success', title: 'Custom API saved (definition only)' }) }}>Save definition</Button>
        <ul className="mt-3 text-sm">{customApis.map((a) => <li key={a.id}>{a.name} — {a.baseUrl}</li>)}</ul>
      </AdminCard>
    </div>
  )
}

export function AdminNotifications() {
  const addNotification = useUserStore((s) => s.addNotification)
  const users = useUserStore((s) => s.users)
  const toast = useToast()
  const [form, setForm] = useState({ title: '', body: '', type: 'offer', target: 'all' })
  return (
    <AdminCard title="Notification Center">
      <input className="w-full border rounded-lg p-2 mb-2" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
      <textarea className="w-full border rounded-lg p-2 mb-2" placeholder="Body" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
      <select className="border rounded-lg p-2 mb-2" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
        <option value="announcement">Announcement</option>
        <option value="offer">Offer</option>
        <option value="flash">Flash Sale</option>
        <option value="order">Order</option>
      </select>
      <select className="border rounded-lg p-2 mb-3 ml-2" value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })}>
        <option value="all">All customers</option>
        {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
      </select>
      <Button
        variant="admin"
        onClick={() => {
          const targets = form.target === 'all' ? users : users.filter((u) => u.id === form.target)
          targets.forEach((u) => addNotification({ ...form, userId: u.id }))
          toast({ type: 'success', title: 'Notifications queued' })
        }}
      >
        Send
      </Button>
    </AdminCard>
  )
}

export function AdminSettings() {
  const cms = useSettingsStore((s) => s.cms)
  const settings = useSettingsStore((s) => s.settings)
  const setCms = useSettingsStore((s) => s.setCms)
  const setSettings = useSettingsStore((s) => s.setSettings)
  const toast = useToast()
  const [c, setC] = useState(cms)
  const [s, setS] = useState(settings)
  return (
    <AdminCard title="Website Settings">
      <input className="w-full border rounded-lg p-2 mb-2" value={c.shopName} onChange={(e) => setC({ ...c, shopName: e.target.value })} />
      <input className="w-full border rounded-lg p-2 mb-2" value={c.tagline} onChange={(e) => setC({ ...c, tagline: e.target.value })} />
      <p className="text-xs font-semibold mt-2">Logo Manager</p>
      {['logoText', 'logoUrl', 'mobileLogoUrl', 'invoiceLogoUrl', 'favicon', 'adminLogoUrl', 'loginLogoUrl'].map((k) => (
        <input key={k} className="w-full border rounded-lg p-2 mb-2" placeholder={k} value={c[k] || ''} onChange={(e) => setC({ ...c, [k]: e.target.value })} />
      ))}
      <input className="w-full border rounded-lg p-2 mb-2" value={c.contact.phone} onChange={(e) => setC({ ...c, contact: { ...c.contact, phone: e.target.value } })} />
      <input className="w-full border rounded-lg p-2 mb-2" value={c.contact.email} onChange={(e) => setC({ ...c, contact: { ...c.contact, email: e.target.value } })} />
      <input className="w-full border rounded-lg p-2 mb-2" value={c.contact.address} onChange={(e) => setC({ ...c, contact: { ...c.contact, address: e.target.value } })} />
      <input className="w-full border rounded-lg p-2 mb-2" value={c.announcement.text} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, text: e.target.value } })} />
      <div className="flex gap-2 mb-2">
        <input className="border rounded-lg p-2" placeholder="Announcement bg" value={c.announcement.background} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, background: e.target.value } })} />
        <input className="border rounded-lg p-2" placeholder="Text color" value={c.announcement.textColor} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, textColor: e.target.value } })} />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={c.announcement.enabled} onChange={(e) => setC({ ...c, announcement: { ...c.announcement, enabled: e.target.checked } })} /> Show bar</label>
      </div>
      <div className="grid grid-cols-2 gap-2 mb-3">
        <label className="text-sm">Inside Dhaka ৳<input type="number" className="w-full border rounded-lg p-2" value={s.delivery.insideDhaka} onChange={(e) => setS({ ...s, delivery: { ...s.delivery, insideDhaka: Number(e.target.value) } })} /></label>
        <label className="text-sm">Outside Dhaka ৳<input type="number" className="w-full border rounded-lg p-2" value={s.delivery.outsideDhaka} onChange={(e) => setS({ ...s, delivery: { ...s.delivery, outsideDhaka: Number(e.target.value) } })} /></label>
      </div>
      <textarea className="w-full border rounded-lg p-2 mb-2" value={c.footer.about} onChange={(e) => setC({ ...c, footer: { ...c.footer, about: e.target.value } })} />
      <Button variant="admin" onClick={() => { setCms(c); setSettings(s); toast({ type: 'success', title: 'Website updated' }) }}>Save CMS</Button>
    </AdminCard>
  )
}

export function AdminAnalytics() {
  const orders = useOrderStore((s) => s.orders)
  const products = useCatalogStore((s) => s.products)
  const cfg = useSettingsStore((s) => s.analyticsConfig)
  const setAnalyticsConfig = useSettingsStore((s) => s.setAnalyticsConfig)
  const [form, setForm] = useState(cfg)
  const revenue = orders.filter((o) => o.status !== 'cancelled').reduce((n, o) => n + o.totals.grandTotal, 0)
  const conv = products.length ? ((orders.length / Math.max(products.reduce((n, p) => n + p.reviewCount, 1), 1)) * 100).toFixed(1) : 0
  return (
    <div>
      <h1 className="text-2xl font-bold text-violet-950 mb-4">Analytics</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        {[
          ['Visitors (est.)', '1,128'],
          ['Product views (est.)', products.reduce((n, p) => n + p.reviewCount * 8, 0)],
          ['Orders', orders.length],
          ['Revenue', formatBdt(revenue)],
        ].map(([l, v]) => (
          <div key={l} className="bg-white rounded-2xl p-4 shadow-sm"><p className="text-xs text-zinc-500">{l}</p><p className="text-xl font-bold">{v}</p></div>
        ))}
      </div>
      <p className="text-sm text-zinc-500 mb-4">Conversion (demo estimate): {conv}%</p>
      <AdminCard title="Tracking IDs">
        <input className="w-full border rounded-lg p-2 mb-2" placeholder="Google Analytics ID" value={form.gaId} onChange={(e) => setForm({ ...form, gaId: e.target.value })} />
        <input className="w-full border rounded-lg p-2 mb-2" placeholder="Facebook Pixel ID" value={form.pixelId} onChange={(e) => setForm({ ...form, pixelId: e.target.value })} />
        <Button variant="admin" onClick={() => setAnalyticsConfig(form)}>Save</Button>
      </AdminCard>
    </div>
  )
}

export function AdminSecurity() {
  const security = useAdminStore((s) => s.security)
  const sessions = useAdminStore((s) => s.sessions)
  const logoutAll = useAdminStore((s) => s.logoutAll)
  const changePassword = useAdminStore((s) => s.changePassword)
  const setTimeoutMin = useAdminStore((s) => s.setTimeoutMin)
  const toast = useToast()
  const [pw, setPw] = useState({ current: '', next: '' })
  return (
    <AdminCard title="Security Center">
      <p className="text-sm">Last login: {security.lastLogin ? formatDateTime(security.lastLogin) : '—'}</p>
      <p className="text-sm">Failed attempts: {security.failedAttempts}</p>
      <p className="text-sm">Session timeout: {security.sessionTimeoutMin} min</p>
      <input type="number" className="border rounded-lg p-2 my-2" value={security.sessionTimeoutMin} onChange={(e) => setTimeoutMin(Number(e.target.value))} />
      <h3 className="font-semibold mt-4">Active sessions</h3>
      {sessions.map((s) => <p key={s.id} className="text-sm text-zinc-500">{s.device} · {formatDateTime(s.started)}</p>)}
      <Button variant="danger" className="mt-3" onClick={() => { logoutAll(); toast({ title: 'All sessions cleared' }) }}>Logout all sessions</Button>
      <div className="mt-6 space-y-2">
        <p className="font-semibold">Change admin password</p>
        <input type="password" className="w-full border rounded-lg p-2" placeholder="Current" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
        <input type="password" className="w-full border rounded-lg p-2" placeholder="New" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
        <Button
          variant="admin"
          onClick={() => {
            const res = changePassword(pw.current, pw.next)
            toast({ type: res.ok ? 'success' : 'error', title: res.ok ? 'Password updated' : res.message })
          }}
        >
          Update password
        </Button>
        <p className="text-xs text-zinc-400">Prototype only. Production must hash passwords on a backend — never store them in plaintext.</p>
      </div>
    </AdminCard>
  )
}

export function AdminMaintenance() {
  const settings = useSettingsStore((s) => s.settings)
  const setSettings = useSettingsStore((s) => s.setSettings)
  const toast = useToast()
  const [m, setM] = useState(settings.maintenance)
  return (
    <AdminCard title="Maintenance Mode">
      <label className="flex items-center gap-2 mb-3"><input type="checkbox" checked={m.enabled} onChange={(e) => setM({ ...m, enabled: e.target.checked })} /> Enable maintenance mode</label>
      <textarea className="w-full border rounded-lg p-2 mb-3" rows={4} value={m.message} onChange={(e) => setM({ ...m, message: e.target.value })} />
      <Button variant="admin" onClick={() => { setSettings({ ...settings, maintenance: m }); toast({ type: 'success', title: m.enabled ? 'Store is in maintenance' : 'Store is live' }) }}>Save</Button>
      <p className="text-xs text-zinc-500 mt-3">Admin panel remains accessible.</p>
    </AdminCard>
  )
}

export function AdminAds() {
  const ads = useSettingsStore((s) => s.ads)
  const upsertAd = useSettingsStore((s) => s.upsertAd)
  const deleteAd = useSettingsStore((s) => s.deleteAd)
  const toast = useToast()
  const [form, setForm] = useState({ id: '', code: '', placement: 'home-top', enabled: true, priority: 1, startDate: '', endDate: '', devices: { mobile: true, tablet: true, desktop: true } })
  return (
    <AdminCard title="Ads Manager (Adsterra)">
      <p className="text-xs text-zinc-500 mb-3">Paste official Adsterra publisher code. Adult ads are not supported. Failed ads never block the store.</p>
      <textarea className="w-full border rounded-lg p-2 mb-2 font-mono text-xs" rows={5} placeholder="Paste Adsterra code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
      <select className="border rounded-lg p-2 mb-2 w-full" value={form.placement} onChange={(e) => setForm({ ...form, placement: e.target.value })}>
        {['home-top', 'home-middle', 'home-bottom', 'category', 'shop', 'search', 'product', 'cart', 'footer', 'custom'].map((p) => <option key={p} value={p}>{p}</option>)}
      </select>
      <div className="flex gap-3 text-sm mb-2">
        {['mobile', 'tablet', 'desktop'].map((d) => (
          <label key={d}><input type="checkbox" checked={form.devices[d]} onChange={(e) => setForm({ ...form, devices: { ...form.devices, [d]: e.target.checked } })} /> {d}</label>
        ))}
        <label><input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} /> Enable</label>
      </div>
      <Button variant="admin" onClick={() => {
        if (!form.code.trim()) return toast({ type: 'error', title: 'Paste an Adsterra code first' })
        upsertAd({ ...form, id: form.id || `ad-${Date.now()}` })
        toast({ type: 'success', title: 'Ad saved' })
        setForm({ id: '', code: '', placement: 'home-top', enabled: true, priority: 1, startDate: '', endDate: '', devices: { mobile: true, tablet: true, desktop: true } })
      }}>Save ad</Button>
      <ul className="mt-4 space-y-2 text-sm">
        {ads.map((a) => (
          <li key={a.id} className="border rounded-xl p-3">
            <p className="font-semibold">{a.placement} · {a.enabled ? 'ACTIVE' : 'DISABLED'}</p>
            <p className="text-xs text-zinc-500 truncate">{a.code.slice(0, 80)}</p>
            <div className="flex gap-2 mt-2">
              <button className="text-violet-700" onClick={() => upsertAd({ ...a, enabled: !a.enabled })}>{a.enabled ? 'Disable' : 'Enable'}</button>
              <button className="text-red-600" onClick={() => { if (confirm('Delete this ad?')) deleteAd(a.id) }}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </AdminCard>
  )
}

export function AdminIcons() {
  const icons = useSettingsStore((s) => s.icons)
  const setIcons = useSettingsStore((s) => s.setIcons)
  const toast = useToast()
  const [form, setForm] = useState(icons)
  return (
    <AdminCard title="Icon / Emoji Manager">
      {Object.keys(form || {}).map((k) => (
        <label key={k} className="block text-sm mb-2 capitalize">{k}
          <input className="w-full border rounded-lg p-2" value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
        </label>
      ))}
      <Button variant="admin" onClick={() => { setIcons(form); toast({ type: 'success', title: 'Icons saved' }) }}>Save</Button>
    </AdminCard>
  )
}

export function AdminHealth() {
  const integrations = useSettingsStore((s) => s.integrations)
  const firebase = useSettingsStore((s) => s.firebase)
  const settings = useSettingsStore((s) => s.settings)
  const [errors, setErrors] = useState([])
  return (
    <AdminCard title="System Health">
      <p>Website: <strong>Online</strong></p>
      <p>Version: {settings.version || '1.0.0'}</p>
      <p>Database (local): <strong>OK</strong></p>
      <p>Authentication: <strong>Local session</strong></p>
      <p>Firebase: <strong>{firebase.configured ? 'Configured' : 'Not configured'}</strong></p>
      <p>APIs connected: {integrations.filter((i) => i.status === 'connected' || i.status === 'demo_connected').length}/{integrations.length}</p>
      <Button variant="admin" className="mt-3" onClick={() => {
        try { setErrors(JSON.parse(localStorage.getItem('mg-runtime-errors') || '[]')) } catch { setErrors([]) }
      }}>Refresh runtime errors</Button>
      <ul className="mt-3 text-xs text-red-600 space-y-1">{errors.map((e, i) => <li key={i}>{e.at} — {e.message}</li>)}</ul>
    </AdminCard>
  )
}

export function AdminBackup() {
  const exportBackup = useSettingsStore((s) => s.exportBackup)
  const importBackup = useSettingsStore((s) => s.importBackup)
  const products = useCatalogStore((s) => s.products)
  const toast = useToast()
  return (
    <AdminCard title="Backup / Restore">
      <Button variant="admin" onClick={() => {
        const blob = new Blob([JSON.stringify({ ...exportBackup(), products }, null, 2)], { type: 'application/json' })
        const a = document.createElement('a')
        a.href = URL.createObjectURL(blob)
        a.download = 'mustakim-gadgets-backup.json'
        a.click()
      }}>Export data</Button>
      <label className="block mt-4 text-sm">Restore JSON
        <input type="file" accept="application/json" className="block mt-1" onChange={async (e) => {
          const f = e.target.files?.[0]
          if (!f) return
          if (!confirm('Restore will overwrite current settings. Continue?')) return
          try {
            const data = JSON.parse(await f.text())
            importBackup(data)
            toast({ type: 'success', title: 'Restored' })
          } catch {
            toast({ type: 'error', title: 'Invalid backup' })
          }
        }} />
      </label>
    </AdminCard>
  )
}

export function AdminActivity() {
  const log = useSettingsStore((s) => s.activityLog)
  return (
    <AdminCard title="Activity Log">
      <ul className="space-y-2 text-sm">
        {(log || []).map((a) => (
          <li key={a.id} className="border-b pb-2">{a.action} · {a.admin} · {formatDateTime(a.at)}</li>
        ))}
      </ul>
    </AdminCard>
  )
}

export function AdminFeatures() {
  const flags = useSettingsStore((s) => s.featureFlags)
  const setFeatureFlags = useSettingsStore((s) => s.setFeatureFlags)
  const toast = useToast()
  return (
    <AdminCard title="Feature Control">
      {Object.keys(flags || {}).map((k) => (
        <label key={k} className="flex items-center justify-between py-2 border-b text-sm capitalize">
          {k}
          <input type="checkbox" checked={!!flags[k]} onChange={(e) => { setFeatureFlags({ [k]: e.target.checked }); toast({ title: `${k} ${e.target.checked ? 'ON' : 'OFF'}` }) }} />
        </label>
      ))}
    </AdminCard>
  )
}

export function AdminLoginPage() {
  const page = useSettingsStore((s) => s.loginPage)
  const setLoginPage = useSettingsStore((s) => s.setLoginPage)
  const providers = useSettingsStore((s) => s.authProviders)
  const setAuthProviders = useSettingsStore((s) => s.setAuthProviders)
  const toast = useToast()
  const [form, setForm] = useState(page)
  return (
    <AdminCard title="Login Page Manager">
      {['title', 'subtitle', 'loginButton', 'registerButton', 'background', 'termsText', 'supportLink'].map((k) => (
        <input key={k} className="w-full border rounded-lg p-2 mb-2" placeholder={k} value={form[k] || ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
      ))}
      <Button variant="admin" onClick={() => { setLoginPage(form); toast({ type: 'success', title: 'Login page saved' }) }}>Save</Button>
      <h3 className="font-semibold mt-6">Providers</h3>
      {Object.keys(providers || {}).map((k) => (
        <label key={k} className="flex items-center justify-between py-2 text-sm">
          {k} · {providers[k].status}
          <input type="checkbox" checked={providers[k].enabled} onChange={(e) => setAuthProviders({ [k]: { ...providers[k], enabled: e.target.checked } })} />
        </label>
      ))}
    </AdminCard>
  )
}

export function AdminPublishCheck() {
  const products = useCatalogStore((s) => s.products)
  const integrations = useSettingsStore((s) => s.integrations)
  const [result, setResult] = useState(null)
  return (
    <AdminCard title="Publish Check">
      <Button variant="admin" onClick={() => {
        setResult([
          ['HTML', 'ok'],
          ['JavaScript', 'ok'],
          ['CSS', 'ok'],
          ['Product data', products.length ? 'ok' : 'error'],
          ['Images', products.some((p) => p.images?.[0]) ? 'ok' : 'warning'],
          ['Admin panel', 'ok'],
          ['Customer panel', 'ok'],
          ['APIs', integrations.some((i) => i.status === 'connected') ? 'ok' : 'warning'],
        ])
      }}>Run pre-publish check</Button>
      {result ? (
        <ul className="mt-4 text-sm space-y-1">
          {result.map(([k, v]) => <li key={k}>{k}: <strong className={v === 'ok' ? 'text-emerald-600' : 'text-amber-600'}>{v}</strong></li>)}
        </ul>
      ) : null}
    </AdminCard>
  )
}

export function AdminPreview() {
  return (
    <AdminCard title="Preview Mode">
      <p className="text-sm mb-3">Open storefront views in a new tab.</p>
      <div className="flex flex-wrap gap-2">
        {['/', '/categories', '/shop', '/cart', '/account', '/admin'].map((p) => (
          <Link key={p} to={p} className="px-3 py-2 rounded-xl bg-violet-100 text-violet-800 text-sm">{p}</Link>
        ))}
      </div>
    </AdminCard>
  )
}

function AdminCard({ title, children }) {
  return (
    <div>
      <h1 className="text-2xl font-bold text-violet-950 mb-4">{title}</h1>
      <div className="bg-white rounded-2xl p-5 shadow-sm">{children}</div>
    </div>
  )
}

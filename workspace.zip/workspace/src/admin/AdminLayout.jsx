import { useCallback, useEffect, useState } from 'react'
import { Navigate, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { Menu, LogOut, Bell, X } from 'lucide-react'
import { iconByName } from '../utils/icons'
import { useAdminStore } from '../store/adminStore'
import { ADMIN_NAV } from '../data/constants'
import ToastViewport from '../components/ui/Toast'

export default function AdminLayout() {
  const authedFlag = useAdminStore((s) => s.authed)
  const authedAt = useAdminStore((s) => s.authedAt)
  const timeoutMin = useAdminStore((s) => s.security?.sessionTimeoutMin || 60)
  const authed = authedFlag && authedAt && Date.now() - authedAt <= timeoutMin * 60 * 1000
  const logout = useAdminStore((s) => s.logout)
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  const closeMenu = useCallback((e) => {
    if (e) {
      e.preventDefault()
      e.stopPropagation()
    }
    setOpen(false)
  }, [])

  const openMenu = useCallback((e) => {
    if (e) {
      e.preventDefault()
      e.stopPropagation()
    }
    setOpen(true)
  }, [])

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    let startX = 0
    let startY = 0
    const onStart = (e) => {
      const t = e.changedTouches?.[0]
      if (!t) return
      startX = t.clientX
      startY = t.clientY
    }
    const onEnd = (e) => {
      const t = e.changedTouches?.[0]
      if (!t) return
      const dx = t.clientX - startX
      const dy = t.clientY - startY
      if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return
      if (dx > 0 && startX < 28) setOpen(true)
      if (dx < 0 && startX > 40) setOpen(false)
    }
    window.addEventListener('touchstart', onStart, { passive: true })
    window.addEventListener('touchend', onEnd, { passive: true })
    return () => {
      window.removeEventListener('touchstart', onStart)
      window.removeEventListener('touchend', onEnd)
    }
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [open])

  if (!authed) return <Navigate to="/admin/login" replace />

  const Nav = ({ onNavigate }) => (
    <nav className="space-y-0.5">
      {ADMIN_NAV.map((n) => {
        const Icon = iconByName(n.icon)
        return (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.to === '/admin'}
            onClick={() => onNavigate?.()}
            className={({ isActive }) =>
              `flex items-center gap-2 px-3 py-2 rounded-xl text-sm ${isActive ? 'bg-violet-600 text-white' : 'text-zinc-600 hover:bg-violet-50'}`
            }
          >
            <Icon size={16} /> {n.label}
          </NavLink>
        )
      })}
    </nav>
  )

  return (
    <div className="min-h-dvh admin-app flex relative">
      <aside className="hidden lg:flex w-60 bg-white border-r border-violet-100 p-4 flex-col shrink-0">
        <p className="font-extrabold text-violet-800 mb-6">MUSTAKIM ADMIN</p>
        <Nav />
        <button
          type="button"
          className="mt-auto flex items-center gap-2 px-3 py-2 text-red-500 text-sm"
          onClick={() => { logout(); navigate('/admin/login') }}
        >
          <LogOut size={16} /> Logout
        </button>
      </aside>

      {open ? (
        <div className="lg:hidden fixed inset-0 z-[200]" role="dialog" aria-modal="true">
          <button
            type="button"
            className="absolute inset-0 bg-black/40"
            aria-label="Close sidebar"
            onClick={closeMenu}
          />
          <aside
            className="absolute left-0 top-0 h-full w-[min(84vw,288px)] bg-white p-4 overflow-y-auto shadow-2xl z-[201]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <p className="font-bold text-violet-800">MUSTAKIM ADMIN</p>
              <button
                type="button"
                className="p-2 rounded-lg hover:bg-violet-50"
                aria-label="Close menu"
                onClick={closeMenu}
              >
                <X size={18} />
              </button>
            </div>
            <Nav onNavigate={() => setOpen(false)} />
            <button
              type="button"
              className="mt-6 flex items-center gap-2 px-3 py-2 text-red-500 text-sm"
              onClick={() => { setOpen(false); logout(); navigate('/admin/login') }}
            >
              <LogOut size={16} /> Logout
            </button>
          </aside>
        </div>
      ) : null}

      <div className="flex-1 min-w-0">
        <header className="sticky top-0 z-[60] bg-white/90 backdrop-blur border-b border-violet-100 px-4 py-3 flex items-center gap-3">
          <button
            id="admin-hamburger"
            type="button"
            className="lg:hidden p-2 rounded-lg hover:bg-violet-50 touch-manipulation"
            aria-label="Open menu"
            aria-expanded={open}
            onClick={openMenu}
          >
            <Menu />
          </button>
          <p className="font-semibold text-violet-900">Admin</p>
          <span className="ml-auto text-xs px-2 py-1 rounded-full bg-amber-100 text-amber-800">DEMO MODE</span>
          <Bell size={16} className="text-zinc-400" />
        </header>
        <main className="p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
      <ToastViewport />
    </div>
  )
}

import { lazy, Suspense } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { CmsProvider } from './context/CmsContext'
import CustomerLayout from './layouts/CustomerLayout'
import ErrorBoundary from './components/ui/ErrorBoundary'
import ScrollControl from './components/layout/ScrollControl'

const Home = lazy(() => import('./pages/Home'))
const Shop = lazy(() => import('./pages/Shop'))
const Categories = lazy(() => import('./pages/Categories'))
const ProductDetails = lazy(() => import('./pages/ProductDetails'))
const Deals = lazy(() => import('./pages/Deals'))
const Wishlist = lazy(() => import('./pages/Wishlist'))
const Cart = lazy(() => import('./pages/Cart'))
const Checkout = lazy(() => import('./pages/Checkout'))
const Auth = lazy(() => import('./pages/Auth'))
const Invoice = lazy(() => import('./pages/Invoice'))
const AccountLayout = lazy(() => import('./pages/account/AccountLayout'))
const AdminLogin = lazy(() => import('./admin/AdminLogin'))
const AdminLayout = lazy(() => import('./admin/AdminLayout'))
const AdminDashboard = lazy(() => import('./admin/AdminDashboard'))
const AdminProducts = lazy(() => import('./admin/AdminProducts'))

function Screen() {
  return (
    <div data-app-ready="1" className="min-h-[50vh] grid place-items-center text-white/50 text-sm bg-[#0A0A0A]">
      Loading Mustakim Gadgets...
    </div>
  )
}

function StaticPage({ name }) {
  const Comp = lazy(async () => {
    const m = await import('./pages/content/StaticPages')
    return { default: m[name] }
  })
  return (
    <Suspense fallback={<Screen />}>
      <Comp />
    </Suspense>
  )
}

function AccountPage({ name }) {
  const Comp = lazy(async () => {
    const m = await import('./pages/account/AccountPages')
    return { default: m[name] }
  })
  return (
    <Suspense fallback={<Screen />}>
      <Comp />
    </Suspense>
  )
}

function AdminPage({ name }) {
  const Comp = lazy(async () => {
    const m = await import('./admin/AdminSimple')
    return { default: m[name] }
  })
  return (
    <Suspense fallback={<Screen />}>
      <Comp />
    </Suspense>
  )
}

function NotFound() {
  return (
    <div data-app-ready="1" className="py-24 text-center">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="text-white/50 mt-2">The page you requested does not exist.</p>
      <a href="/" className="text-[#F5A623] mt-4 inline-block">Go home</a>
    </div>
  )
}

export default function App() {
  return (
    <div data-app-ready="1">
      <CmsProvider>
        <BrowserRouter>
          <ScrollControl />
          <ErrorBoundary>
            <Suspense fallback={<Screen />}>
              <Routes>
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route path="/admin" element={<AdminLayout />}>
                  <Route index element={<AdminDashboard />} />
                  <Route path="dashboard" element={<Navigate to="/admin" replace />} />
                  <Route path="products" element={<AdminProducts />} />
                  <Route path="categories" element={<AdminPage name="AdminCategories" />} />
                  <Route path="orders" element={<AdminPage name="AdminOrders" />} />
                  <Route path="customers" element={<AdminPage name="AdminCustomers" />} />
                  <Route path="coupons" element={<AdminPage name="AdminCoupons" />} />
                  <Route path="flash-sale" element={<AdminPage name="AdminFlash" />} />
                  <Route path="banners" element={<AdminPage name="AdminBanners" />} />
                  <Route path="reviews" element={<AdminPage name="AdminReviews" />} />
                  <Route path="courier" element={<AdminPage name="AdminCourier" />} />
                  <Route path="payments" element={<AdminPage name="AdminPayments" />} />
                  <Route path="firebase" element={<AdminPage name="AdminFirebase" />} />
                  <Route path="integrations" element={<AdminPage name="AdminIntegrations" />} />
                  <Route path="api" element={<Navigate to="/admin/integrations" replace />} />
                  <Route path="ads" element={<AdminPage name="AdminAds" />} />
                  <Route path="icons" element={<AdminPage name="AdminIcons" />} />
                  <Route path="health" element={<AdminPage name="AdminHealth" />} />
                  <Route path="backup" element={<AdminPage name="AdminBackup" />} />
                  <Route path="activity" element={<AdminPage name="AdminActivity" />} />
                  <Route path="features" element={<AdminPage name="AdminFeatures" />} />
                  <Route path="login-page" element={<AdminPage name="AdminLoginPage" />} />
                  <Route path="publish-check" element={<AdminPage name="AdminPublishCheck" />} />
                  <Route path="preview" element={<AdminPage name="AdminPreview" />} />
                  <Route path="notifications" element={<AdminPage name="AdminNotifications" />} />
                  <Route path="settings" element={<AdminPage name="AdminSettings" />} />
                  <Route path="analytics" element={<AdminPage name="AdminAnalytics" />} />
                  <Route path="security" element={<AdminPage name="AdminSecurity" />} />
                  <Route path="maintenance" element={<AdminPage name="AdminMaintenance" />} />
                </Route>

                <Route element={<CustomerLayout />}>
                  <Route path="/" element={<Home />} />
                  <Route path="/shop" element={<Shop />} />
                  <Route path="/categories" element={<Categories />} />
                  <Route path="/categories/:slug" element={<Categories />} />
                  <Route path="/product/:id" element={<ProductDetails />} />
                  <Route path="/deals" element={<Deals />} />
                  <Route path="/wishlist" element={<Wishlist />} />
                  <Route path="/cart" element={<Cart />} />
                  <Route path="/checkout" element={<Checkout />} />
                  <Route path="/login" element={<Auth mode="login" />} />
                  <Route path="/register" element={<Auth mode="register" />} />
                  <Route path="/about" element={<StaticPage name="About" />} />
                  <Route path="/contact" element={<StaticPage name="Contact" />} />
                  <Route path="/faq" element={<StaticPage name="Faq" />} />
                  <Route path="/privacy" element={<StaticPage name="Privacy" />} />
                  <Route path="/terms" element={<StaticPage name="Terms" />} />
                  <Route path="account" element={<AccountLayout />}>
                    <Route index element={<AccountPage name="AccountHome" />} />
                    <Route path="profile" element={<AccountPage name="AccountProfile" />} />
                    <Route path="orders" element={<AccountPage name="AccountOrders" />} />
                    <Route path="orders/:id" element={<AccountPage name="AccountOrderDetail" />} />
                    <Route path="wishlist" element={<AccountPage name="AccountWishlist" />} />
                    <Route path="addresses" element={<AccountPage name="AccountAddresses" />} />
                    <Route path="notifications" element={<AccountPage name="AccountNotifications" />} />
                    <Route path="recent" element={<AccountPage name="AccountRecent" />} />
                    <Route path="settings" element={<AccountPage name="AccountSettings" />} />
                  </Route>
                  <Route path="*" element={<NotFound />} />
                </Route>

                <Route path="/account/orders/:id/invoice" element={<Invoice />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </BrowserRouter>
      </CmsProvider>
    </div>
  )
}

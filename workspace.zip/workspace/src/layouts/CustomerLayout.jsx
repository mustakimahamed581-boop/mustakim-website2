import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import AnnouncementBar from '../components/layout/AnnouncementBar'
import Header from '../components/layout/Header'
import Footer from '../components/layout/Footer'
import MobileBottomNav from '../components/layout/MobileBottomNav'
import MobileMenu from '../components/layout/MobileMenu'
import SearchOverlay from '../components/search/SearchOverlay'
import CartDrawer from '../components/cart/CartDrawer'
import ToastViewport from '../components/ui/Toast'
import MaintenanceGate from '../components/layout/MaintenanceGate'
import AdSlot from '../components/ads/AdSlot'

export default function CustomerLayout() {
  const [menu, setMenu] = useState(false)
  return (
    <MaintenanceGate>
      <div className="min-h-dvh bg-[#0A0A0A] text-white">
        <AnnouncementBar />
        <Header onMenu={() => setMenu(true)} />
        <main className="min-h-[60vh]">
          <Outlet />
        </main>
        <div className="max-w-7xl mx-auto px-4"><AdSlot placement="footer" /></div>
        <Footer />
        <MobileBottomNav />
        <MobileMenu open={menu} onClose={() => setMenu(false)} />
        <SearchOverlay />
        <CartDrawer />
        <ToastViewport />
      </div>
    </MaintenanceGate>
  )
}

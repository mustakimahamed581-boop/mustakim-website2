import { defaultCategories } from './categories'
import { defaultProducts } from './products'

export const defaultCms = {
  shopName: 'MUSTAKIM GADGETS',
  tagline: 'SMART TECHNOLOGY. BETTER EVERYDAY.',
  logoText: 'MG',
  logoUrl: '',
  mobileLogoUrl: '',
  invoiceLogoUrl: '',
  favicon: '/favicon.svg',
  adminLogoUrl: '',
  loginLogoUrl: '',
  footerLogoUrl: '',
  socialLogos: {
    facebook: '',
    instagram: '',
    youtube: '',
    tiktok: '',
    whatsapp: '',
  },
  contact: {
    phone: '+880 1700 000000',
    email: 'mustakimgadgets@gmail.com',
    address: 'Mymensingh, Bangladesh',
    hours: '10:00 AM – 10:00 PM (Asia/Dhaka)',
  },
  social: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    tiktok: '',
    whatsapp: 'https://wa.me/8801700000000',
  },
  announcement: {
    enabled: true,
    text: 'Fast Delivery Across Bangladesh  |  Cash on Delivery Available',
    icon: 'Truck',
    background: '#111111',
    textColor: '#F5A623',
  },
  footer: {
    about: 'Premium phones, accessories and smart gadgets with nationwide delivery and genuine warranty.',
    copyright: '© 2026 MUSTAKIM GADGETS. All Rights Reserved.',
  },
  seo: {
    title: 'Mustakim Gadgets | Smart Technology. Better Everyday.',
    description: 'Discover premium phones, accessories and smart gadgets at the best price in Bangladesh.',
  },
}

export const defaultHeroSlides = [
  {
    id: 'hero-1',
    enabled: true,
    order: 1,
    heading: 'SMART GADGETS.',
    headingAccent: 'BETTER EVERYDAY.',
    subtitle: 'Discover premium phones, accessories and smart gadgets at the best price.',
    buttonText: 'SHOP NOW',
    buttonUrl: '/shop',
    secondaryText: 'EXPLORE DEALS',
    secondaryUrl: '/deals',
    background: 'linear-gradient(135deg, #0A0A0A 0%, #1A1208 55%, #0A0A0A 100%)',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1600&q=80',
    badge: 'UP TO 50% OFF',
  },
  {
    id: 'hero-2',
    enabled: true,
    order: 2,
    heading: 'FLASH SALE.',
    headingAccent: 'LIMITED STOCK.',
    subtitle: 'Flagship phones and accessories with exclusive Mustakim Gadgets pricing.',
    buttonText: 'SHOP FLASH SALE',
    buttonUrl: '/deals',
    secondaryText: 'VIEW PHONES',
    secondaryUrl: '/categories/mobile-phones',
    background: 'linear-gradient(135deg, #0A0A0A 0%, #1A0A14 55%, #0A0A0A 100%)',
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=1600&q=80',
    badge: 'UP TO 40% OFF',
  },
]

export const defaultBanners = [
  {
    id: 'ban-accessories',
    type: 'offer',
    enabled: true,
    title: 'LIMITED TIME OFFER',
    subtitle: 'Up to 40% Off Top Mobile Accessories',
    button: 'Grab the Deal',
    url: '/deals',
    image: 'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?auto=format&fit=crop&w=1400&q=80',
    startDate: null,
    endDate: null,
    priority: 1,
  },
  {
    id: 'ban-popup',
    type: 'popup',
    enabled: false,
    title: 'Welcome Offer',
    subtitle: 'Use WELCOME10 for 10% off your first order.',
    button: 'Shop Now',
    url: '/shop',
    image: '',
    startDate: null,
    endDate: null,
    priority: 10,
  },
]

export const defaultCoupons = [
  {
    id: 'cp-welcome',
    code: 'WELCOME10',
    type: 'percent',
    value: 10,
    minOrder: 2000,
    maxDiscount: 1500,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    usageLimit: 1000,
    perUserLimit: 1,
    usedCount: 42,
    enabled: true,
  },
  {
    id: 'cp-flash',
    code: 'FLASH500',
    type: 'fixed',
    value: 500,
    minOrder: 5000,
    maxDiscount: 500,
    startDate: '2026-10-01',
    endDate: '2026-10-31',
    usageLimit: 200,
    perUserLimit: 2,
    usedCount: 18,
    enabled: true,
  },
]

export const defaultFlashSale = {
  enabled: true,
  title: 'Limited Time Offer',
  subtitle: 'Up to 40% Off Top Accessories',
  start: '2026-10-01T00:00:00+06:00',
  end: '2026-12-31T23:59:59+06:00',
  productIds: ['p-iphone-15-pm', 'p-s24-ultra', 'p-tws-pro', 'p-watch-fit', 'p-wireless-charger', 'p-glass-s24', 'p-bulb'],
  discountNote: 'Up to 40% Off',
}

export const defaultSettings = {
  currency: 'BDT',
  timezone: 'Asia/Dhaka',
  language: 'en',
  delivery: { insideDhaka: 60, outsideDhaka: 120 },
  maintenance: { enabled: false, message: "WE'LL BE BACK SOON. Mustakim Gadgets is upgrading your shopping experience." },
  demoMode: true,
  soundEnabled: false,
  version: '1.0.0',
  lastUpdated: '2026-10-05',
}

export const defaultFeatureFlags = {
  search: true,
  wishlist: true,
  cart: true,
  reviews: true,
  productVideo: true,
  multipleImages: true,
  deals: true,
  banner: true,
  notifications: true,
  invoice: true,
  featured: true,
  bestSellers: true,
  categories: true,
  ads: true,
}

export const defaultAuthProviders = {
  email: { enabled: true, configured: true, status: 'connected' },
  phone: { enabled: true, configured: false, status: 'not_configured' },
  google: { enabled: true, configured: false, status: 'not_configured' },
  facebook: { enabled: true, configured: false, status: 'not_configured' },
  github: { enabled: true, configured: false, status: 'not_configured' },
  otp: { enabled: true, configured: false, status: 'not_configured' },
  registration: { enabled: true, configured: true, status: 'connected' },
}

export const defaultLoginPage = {
  title: 'Welcome back',
  subtitle: 'Sign in to track orders, wishlist and checkout faster.',
  loginButton: 'Login',
  registerButton: 'Create account',
  background: '',
  termsText: 'By continuing you agree to our Terms and Privacy Policy.',
  supportLink: '/contact',
}

export const defaultAds = []

export const defaultActivityLog = [
  { id: 'act-1', action: 'System initialized', admin: 'Mustakim', at: '2026-10-05T12:00:00+06:00' },
]

export const defaultIcons = {
  home: 'Home',
  categories: 'Layers',
  shop: 'ShoppingBag',
  deals: 'Zap',
  account: 'User',
}

export const defaultPayments = {
  cod: { enabled: true, label: 'Cash on Delivery' },
  bkash: { enabled: true, label: 'bKash', sandbox: true, merchantId: '', apiKey: '', secret: '', connected: false, mockMode: false },
  nagad: { enabled: true, label: 'Nagad', sandbox: true, merchantId: '', apiKey: '', secret: '', connected: false, mockMode: false },
  rocket: { enabled: true, label: 'Rocket', sandbox: true, merchantId: '', username: '', password: '', connected: false, mockMode: false },
  sslcommerz: { enabled: true, label: 'SSLCommerz', sandbox: true, storeId: '', storePassword: '', connected: false, mockMode: false },
}

const DEFAULT_PAY_WARNING =
  'Payment করার আগে Account Number এবং Amount ভালোভাবে যাচাই করুন। Payment করার পর সঠিক Transaction ID প্রদান করুন। ভুল তথ্য দিলে Payment Verification বিলম্বিত হতে পারে। Admin Approval ছাড়া Order Confirmed হবে না।'

const DEFAULT_PAY_STEPS = `1. উপরের Account/Number-এ Payment করুন।
2. Payment করার পর Transaction ID লিখুন।
3. Payment-এর সঠিক Amount প্রদান করুন।
4. Submit Payment চাপুন।
5. Admin Payment verify করে Approval দিলে Order Confirm হবে।`

export const defaultPaymentMethods = [
  {
    id: 'cod',
    name: 'Cash on Delivery',
    logo: '',
    color: '#F5A623',
    accountNumber: '',
    merchantNumber: '',
    qrCode: '',
    instructions: 'Pay in cash when your parcel arrives. Keep the exact amount ready for the courier.',
    warning: 'COD orders stay pending until Mustakim Gadgets confirms the order. Please keep your phone reachable.',
    trxRequired: false,
    enabled: true,
  },
  {
    id: 'bkash',
    name: 'bKash',
    logo: '',
    color: '#E2136E',
    accountNumber: '01700000000',
    merchantNumber: '01700000000',
    qrCode: '',
    instructions: DEFAULT_PAY_STEPS,
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
  {
    id: 'nagad',
    name: 'Nagad',
    logo: '',
    color: '#F26522',
    accountNumber: '01700000000',
    merchantNumber: '01700000000',
    qrCode: '',
    instructions: DEFAULT_PAY_STEPS,
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
  {
    id: 'rocket',
    name: 'Rocket',
    logo: '',
    color: '#8C3494',
    accountNumber: '01700000000',
    merchantNumber: '01700000000',
    qrCode: '',
    instructions: DEFAULT_PAY_STEPS,
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
  {
    id: 'upay',
    name: 'Upay',
    logo: '',
    color: '#00A991',
    accountNumber: '01700000000',
    merchantNumber: '01700000000',
    qrCode: '',
    instructions: DEFAULT_PAY_STEPS,
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
  {
    id: 'bank',
    name: 'Bank Transfer',
    logo: '',
    color: '#1A365D',
    accountNumber: 'Mustakim Gadgets — 1234567890123 — Dutch-Bangla Bank',
    merchantNumber: '',
    qrCode: '',
    instructions: DEFAULT_PAY_STEPS,
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
  {
    id: 'card',
    name: 'Visa / Card',
    logo: '',
    color: '#1A1F71',
    accountNumber: '',
    merchantNumber: '',
    qrCode: '',
    instructions: 'Card checkout uses a backend adapter. In DEMO MODE, submit with a reference ID. Live charging is never done from this frontend.',
    warning: DEFAULT_PAY_WARNING,
    trxRequired: true,
    enabled: true,
  },
]

export const defaultInvoiceDesign = {
  logoUrl: '',
  header: 'TAX / SALES INVOICE',
  businessName: 'MUSTAKIM GADGETS',
  address: 'Mymensingh, Bangladesh',
  phone: '+880 1700 000000',
  email: 'mustakimgadgets@gmail.com',
  website: 'mustakimgadgets.com',
  footerText: 'Thank you for shopping with MUSTAKIM GADGETS. Genuine gadgets. Nationwide delivery.',
  warrantyTitle: 'Official Warranty',
  warrantyReplacement: '7 Days Replacement Warranty',
  warrantyService: '2 Years Service Warranty',
  terms: 'Unused products may be returned within 7 days subject to inspection. Warranty is valid with this invoice. Admin-verified payments only are marked Approved.',
  signature: '',
  stamp: '',
  paymentInfo: 'Pay only to official Mustakim Gadgets accounts shown at checkout.',
  customNotes: 'Please keep this invoice for warranty claims and after-sales service.',
  background: '#FFFBF3',
  cardStyle: 'rounded',
  borderStyle: 'gold',
  fontSize: 'md',
  theme: 'gold',
  decoration: true,
  showProductImage: true,
  showWarranty: true,
  showCustomer: true,
  showPayment: true,
  successTitle: 'Payment Successful',
  successBody: 'Thank you for your purchase from MUSTAKIM GADGETS. Your payment has been successfully verified and your order is now confirmed.',
  verifiedBanner: 'Payment Verified Successfully. Your payment has been verified by MUSTAKIM GADGETS. Your order is now confirmed. Thank you for shopping with us.',
  pendingBody: 'Payment Submitted Successfully. Your payment is currently waiting for admin approval.',
}

export const defaultCourier = {
  provider: 'steadfast',
  apiKey: '',
  secretKey: '',
  merchantId: '',
  pickupName: 'Mustakim Gadgets',
  pickupPhone: '+8801700000000',
  pickupAddress: 'Mymensingh, Bangladesh',
  defaultCharge: 60,
  connected: false,
  mockMode: false,
  lastTest: null,
}

export const defaultFirebase = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
  measurementId: '',
  databaseURL: '',
  services: {
    authentication: false,
    firestore: false,
    realtime: false,
    storage: false,
    messaging: false,
  },
  configured: false,
}

export const defaultIntegrations = [
  { id: 'firebase', name: 'Firebase', description: 'Auth, Firestore, Storage and Cloud Messaging.', status: 'not_connected', mockMode: false },
  { id: 'steadfast', name: 'Steadfast Courier', description: 'Create parcels, tracking and status sync.', status: 'not_connected', mockMode: false },
  { id: 'bkash', name: 'bKash', description: 'Mobile financial payment for Bangladesh.', status: 'not_connected', mockMode: false },
  { id: 'nagad', name: 'Nagad', description: 'Nagad checkout adapter.', status: 'not_connected', mockMode: false },
  { id: 'rocket', name: 'Rocket', description: 'Dutch-Bangla Rocket payments.', status: 'not_connected', mockMode: false },
  { id: 'sslcommerz', name: 'SSLCommerz', description: 'Card and mobile banking gateway.', status: 'not_connected', mockMode: false },
  { id: 'sms', name: 'SMS Gateway', description: 'OTP and order SMS notifications.', status: 'not_connected', mockMode: false },
  { id: 'smtp', name: 'Email SMTP', description: 'Transactional emails and invoices.', status: 'not_connected', mockMode: false },
  { id: 'ga', name: 'Google Analytics', description: 'Traffic and conversion tracking.', status: 'not_connected', mockMode: false },
  { id: 'pixel', name: 'Facebook Pixel', description: 'Ads conversion and remarketing.', status: 'not_connected', mockMode: false },
  { id: 'maps', name: 'Google Maps', description: 'Store locator and address maps.', status: 'not_connected', mockMode: false },
  { id: 'custom', name: 'Custom API', description: 'Define a custom integration adapter.', status: 'not_connected', mockMode: false },
  { id: 'youtube', name: 'YouTube', description: 'Product video embeds.', status: 'not_connected', mockMode: false },
  { id: 'tmdb', name: 'TMDB', description: 'Optional media metadata. Not required for gadgets.', status: 'not_connected', mockMode: false },
  { id: 'gemini', name: 'Gemini', description: 'Optional AI assistant. Secret keys stay server-side.', status: 'not_connected', mockMode: false },
  { id: 'adsterra', name: 'Adsterra', description: 'Publisher ads via Ads Manager paste box.', status: 'not_connected', mockMode: false },
]

export const defaultCustomers = [
  {
    id: 'u-demo',
    name: 'Mustakim Ahamed',
    phone: '01700000000',
    email: 'mustakim@gmail.com',
    password: 'demo1234',
    photo: '',
    registeredAt: '2026-03-12T10:00:00+06:00',
    status: 'active',
    addresses: [
      {
        id: 'addr-1',
        label: 'Home',
        name: 'Mustakim Ahamed',
        phone: '01700000000',
        division: 'Mymensingh',
        district: 'Mymensingh',
        upazila: 'Mymensingh Sadar',
        address: 'House 12, Road No. 5, Mymensingh',
        isDefault: true,
      },
    ],
  },
]

export const defaultReviews = [
  {
    id: 'rv-1',
    productId: 'p-iphone-15-pm',
    userId: 'u-demo',
    userName: 'Mustakim Ahamed',
    rating: 5,
    title: 'Premium feel',
    comment: 'Camera and battery are excellent. Genuine product with official warranty.',
    images: [],
    verified: true,
    status: 'approved',
    createdAt: '2026-09-18T12:00:00+06:00',
  },
  {
    id: 'rv-2',
    productId: 'p-s24-ultra',
    userId: 'u-demo',
    userName: 'Rafi Islam',
    rating: 5,
    title: 'Best Android',
    comment: 'S Pen and display are outstanding. Fast delivery from Mustakim Gadgets.',
    images: [],
    verified: true,
    status: 'approved',
    createdAt: '2026-09-02T09:00:00+06:00',
  },
  {
    id: 'rv-3',
    productId: 'p-airpods-pro-2',
    userId: 'guest',
    userName: 'Nusrat',
    rating: 4,
    title: 'Great ANC',
    comment: 'Noise cancellation is superb for the price in BD.',
    images: [],
    verified: true,
    status: 'approved',
    createdAt: '2026-08-21T18:20:00+06:00',
  },
]

export const defaultOrders = [
  {
    id: 'MG-20261001-0008',
    userId: 'u-demo',
    customer: { name: 'Mustakim Ahamed', phone: '01700000000', email: 'mustakim@gmail.com' },
    address: {
      division: 'Mymensingh',
      district: 'Mymensingh',
      upazila: 'Mymensingh Sadar',
      address: 'House 12, Road No. 5, Mymensingh',
      note: '',
    },
    items: [
      { productId: 'p-s24-ultra', name: 'Samsung Galaxy S24 Ultra', brand: 'Samsung', image: defaultProducts[1].images[0], qty: 1, price: 179999, salePrice: 119999, variant: 'Titanium Black / 256GB', color: 'Titanium Black', ram: '12GB', storage: '256GB', model: 'S24 Ultra' },
    ],
    totals: { subtotal: 119999, couponDiscount: 0, delivery: 120, grandTotal: 120119 },
    couponCode: '',
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    trxId: '',
    invoiceNumber: 'INV-20261001-0008',
    invoiceGenerated: false,
    estimatedDelivery: '2026-10-05',
    status: 'processing',
    timeline: [
      { status: 'pending', at: '2026-10-01T11:10:00+06:00' },
      { status: 'confirmed', at: '2026-10-01T11:40:00+06:00' },
      { status: 'processing', at: '2026-10-02T09:15:00+06:00' },
    ],
    courier: { consignmentId: '', trackingCode: '', status: '' },
    createdAt: '2026-10-01T11:10:00+06:00',
  },
  {
    id: 'MG-20260928-0006',
    userId: 'u-demo',
    customer: { name: 'Mustakim Ahamed', phone: '01700000000', email: 'mustakim@gmail.com' },
    address: {
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Dhanmondi',
      address: 'Road 7A, Dhanmondi',
      note: '',
    },
    items: [
      { productId: 'p-airpods-pro-2', name: 'AirPods Pro (2nd Gen)', brand: 'Apple', image: defaultProducts[5].images[0], qty: 1, price: 34999, salePrice: 32999, variant: 'White', color: 'White', ram: '', storage: '', model: 'AirPods Pro 2' },
    ],
    totals: { subtotal: 32999, couponDiscount: 0, delivery: 60, grandTotal: 33059 },
    couponCode: '',
    paymentMethod: 'bkash',
    paymentStatus: 'approved',
    trxId: 'BKA8X29Q1M',
    invoiceNumber: 'INV-20260928-0006',
    invoiceGenerated: true,
    paymentSubmittedAt: '2026-09-28T10:05:00+06:00',
    paymentApprovedAt: '2026-09-28T10:20:00+06:00',
    estimatedDelivery: '2026-10-02',
    status: 'shipped',
    timeline: [
      { status: 'pending', at: '2026-09-28T10:00:00+06:00' },
      { status: 'confirmed', at: '2026-09-28T10:20:00+06:00' },
      { status: 'processing', at: '2026-09-28T16:00:00+06:00' },
      { status: 'packed', at: '2026-09-29T09:00:00+06:00' },
      { status: 'shipped', at: '2026-09-29T14:00:00+06:00' },
    ],
    courier: { consignmentId: 'SF-demo-1001', trackingCode: 'TRK1001', status: 'in_transit' },
    createdAt: '2026-09-28T10:00:00+06:00',
  },
  {
    id: 'MG-20260920-0005',
    userId: 'u-demo',
    customer: { name: 'Mustakim Ahamed', phone: '01700000000', email: 'mustakim@gmail.com' },
    address: {
      division: 'Mymensingh',
      district: 'Mymensingh',
      upazila: 'Mymensingh Sadar',
      address: 'House 12, Road No. 5, Mymensingh',
      note: '',
    },
    items: [
      { productId: 'p-watch-fit', name: 'Mustakim Fit Watch S3', brand: 'Mustakim', image: defaultProducts[10].images[0], qty: 1, price: 5999, salePrice: 3999, variant: 'Black', color: 'Black', ram: '', storage: '', model: 'Fit Watch S3' },
    ],
    totals: { subtotal: 3999, couponDiscount: 0, delivery: 120, grandTotal: 4119 },
    couponCode: '',
    paymentMethod: 'cod',
    paymentStatus: 'approved',
    trxId: '',
    invoiceNumber: 'INV-20260920-0005',
    invoiceGenerated: true,
    paymentApprovedAt: '2026-09-20T12:30:00+06:00',
    estimatedDelivery: '2026-09-22',
    status: 'delivered',
    timeline: [
      { status: 'pending', at: '2026-09-20T12:00:00+06:00' },
      { status: 'confirmed', at: '2026-09-20T12:30:00+06:00' },
      { status: 'processing', at: '2026-09-20T16:00:00+06:00' },
      { status: 'packed', at: '2026-09-21T09:00:00+06:00' },
      { status: 'shipped', at: '2026-09-21T14:00:00+06:00' },
      { status: 'out_for_delivery', at: '2026-09-22T10:00:00+06:00' },
      { status: 'delivered', at: '2026-09-22T16:40:00+06:00' },
    ],
    courier: { consignmentId: 'SF-demo-0992', trackingCode: 'TRK0992', status: 'delivered' },
    createdAt: '2026-09-20T12:00:00+06:00',
  },
  {
    id: 'MG-20260910-0003',
    userId: 'u-demo',
    customer: { name: 'Mustakim Ahamed', phone: '01700000000', email: 'mustakim@gmail.com' },
    address: {
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Gulshan',
      address: 'Gulshan 2',
      note: '',
    },
    items: [
      { productId: 'p-usbc-cable', name: 'USB-C to USB-C 100W Cable 2m', brand: 'Mustakim', image: defaultProducts[8].images[0], qty: 2, price: 1999, salePrice: 1499, variant: 'Black / 2m', color: 'Black', ram: '', storage: '', model: '' },
    ],
    totals: { subtotal: 2998, couponDiscount: 0, delivery: 60, grandTotal: 3058 },
    couponCode: '',
    paymentMethod: 'nagad',
    paymentStatus: 'rejected',
    trxId: 'NGD000111',
    invoiceNumber: 'INV-20260910-0003',
    invoiceGenerated: false,
    status: 'cancelled',
    timeline: [
      { status: 'pending', at: '2026-09-10T08:00:00+06:00' },
      { status: 'cancelled', at: '2026-09-10T08:20:00+06:00' },
    ],
    courier: { consignmentId: '', trackingCode: '', status: '' },
    createdAt: '2026-09-10T08:00:00+06:00',
  },
]

export const defaultNotifications = [
  { id: 'n1', userId: 'u-demo', title: 'Order confirmed', body: 'MG-20261001-0008 has been confirmed.', type: 'order', read: false, createdAt: '2026-10-01T11:40:00+06:00' },
  { id: 'n2', userId: 'u-demo', title: 'Flash Sale live', body: 'Up to 40% off selected gadgets today.', type: 'flash', read: false, createdAt: '2026-10-04T09:00:00+06:00' },
  { id: 'n3', userId: 'u-demo', title: 'Out for delivery', body: 'MG-20260928-0006 is on the way.', type: 'shipping', read: true, createdAt: '2026-09-30T10:00:00+06:00' },
]

export const defaultQuestions = [
  { id: 'q1', productId: 'p-iphone-15-pm', userName: 'Hasan', question: 'Is this official Apple warranty in Bangladesh?', answer: 'Yes, 1 year official warranty.', createdAt: '2026-09-01T10:00:00+06:00' },
]

export const defaultAdminSecurity = {
  lastLogin: null,
  failedAttempts: 0,
  sessionTimeoutMin: 60,
  passwordHashHint: 'prototype-only',
}

export const defaultFaqs = [
  { q: 'Do you offer Cash on Delivery?', a: 'Yes. COD is available across Bangladesh. Inside Dhaka ৳60, outside Dhaka ৳120 (admin editable).' },
  { q: 'Are products original?', a: 'Yes. We sell 100% original products with manufacturer or store warranty as listed on each page.' },
  { q: 'How long is delivery?', a: 'Dhaka: 1–2 days. Nationwide: 2–5 days depending on courier.' },
  { q: 'Can I return a product?', a: 'Unused products can be returned within 7 days subject to our return policy.' },
]

export { defaultCategories, defaultProducts }

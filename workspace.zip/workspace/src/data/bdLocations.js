export const divisions = [
  'Dhaka',
  'Chattogram',
  'Rajshahi',
  'Khulna',
  'Barishal',
  'Sylhet',
  'Rangpur',
  'Mymensingh',
]

export const districtsByDivision = {
  Dhaka: ['Dhaka', 'Gazipur', 'Narayanganj', 'Tangail', 'Faridpur', 'Manikganj', 'Munshiganj'],
  Chattogram: ['Chattogram', 'Cox\'s Bazar', 'Cumilla', 'Feni', 'Noakhali', 'Rangamati'],
  Rajshahi: ['Rajshahi', 'Bogura', 'Pabna', 'Natore', 'Sirajganj'],
  Khulna: ['Khulna', 'Jessore', 'Kushtia', 'Satkhira', 'Bagerhat'],
  Barishal: ['Barishal', 'Patuakhali', 'Bhola', 'Pirojpur'],
  Sylhet: ['Sylhet', 'Moulvibazar', 'Habiganj', 'Sunamganj'],
  Rangpur: ['Rangpur', 'Dinajpur', 'Kurigram', 'Lalmonirhat'],
  Mymensingh: ['Mymensingh', 'Jamalpur', 'Netrokona', 'Sherpur'],
}

export const upazilasByDistrict = {
  Dhaka: ['Dhanmondi', 'Gulshan', 'Mirpur', 'Uttara', 'Motijheel', 'Mohammadpur', 'Tejgaon'],
  Gazipur: ['Gazipur Sadar', 'Tongi', 'Kaliakair', 'Kapasia'],
  Narayanganj: ['Narayanganj Sadar', 'Fatullah', 'Sonargaon'],
  Mymensingh: ['Mymensingh Sadar', 'Trishal', 'Bhaluka', 'Muktagacha'],
  Chattogram: ['Kotwali', 'Pahartali', 'Halishahar', 'Agrabad'],
  Sylhet: ['Sylhet Sadar', 'South Surma', 'Bishwanath'],
}

export function getDistricts(division) {
  return districtsByDivision[division] || []
}

export function getUpazilas(district) {
  return upazilasByDistrict[district] || [`${district} Sadar`, 'Sadar North', 'Sadar South']
}

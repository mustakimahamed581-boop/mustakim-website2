export const ORDER_STATUSES = [
  'pending',
  'confirmed',
  'processing',
  'packed',
  'shipped',
  'out_for_delivery',
  'delivered',
  'cancelled',
  'returned',
]

export const STATUS_LABELS = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  processing: 'Processing',
  packed: 'Packed',
  shipped: 'Shipped',
  out_for_delivery: 'Out for Delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
  returned: 'Returned',
}

export const PAYMENT_LABELS = {
  cod: 'Cash on Delivery',
  bkash: 'bKash',
  nagad: 'Nagad',
  rocket: 'Rocket',
  upay: 'Upay',
  bank: 'Bank Transfer',
  card: 'Visa / Card',
  sslcommerz: 'SSLCommerz',
}

export const PAYMENT_STATUSES = ['pending', 'approved', 'rejected', 'expired']

export const PAYMENT_STATUS_LABELS = {
  pending: 'Pending',
  approved: 'Approved',
  success: 'Approved',
  rejected: 'Rejected',
  failed: 'Rejected',
  expired: 'Expired',
}

export const BADGE_STYLES = {
  'BEST SELLER': 'bg-amber-500 text-black',
  TRENDING: 'bg-orange-500 text-white',
  POPULAR: 'bg-violet-600 text-white',
  NEW: 'bg-emerald-500 text-black',
  SALE: 'bg-red-500 text-white',
  'LOW STOCK': 'bg-rose-700 text-white',
}

export const ADMIN_NAV = [
  { to: '/admin', label: 'Dashboard', icon: 'LayoutDashboard' },
  { to: '/admin/products', label: 'Products', icon: 'Package' },
  { to: '/admin/categories', label: 'Categories', icon: 'Layers' },
  { to: '/admin/orders', label: 'Orders', icon: 'ShoppingBag' },
  { to: '/admin/customers', label: 'Customers', icon: 'Users' },
  { to: '/admin/coupons', label: 'Coupons', icon: 'Ticket' },
  { to: '/admin/flash-sale', label: 'Flash Sale', icon: 'Zap' },
  { to: '/admin/banners', label: 'Banners', icon: 'Image' },
  { to: '/admin/reviews', label: 'Reviews', icon: 'Star' },
  { to: '/admin/courier', label: 'Courier', icon: 'Truck' },
  { to: '/admin/payments', label: 'Payments', icon: 'CreditCard' },
  { to: '/admin/invoice-designer', label: 'Invoice Designer', icon: 'FileText' },
  { to: '/admin/logos', label: 'Logo Manager', icon: 'Image' },
  { to: '/admin/firebase', label: 'Firebase', icon: 'Flame' },
  { to: '/admin/integrations', label: 'API Center', icon: 'Plug' },
  { to: '/admin/ads', label: 'Ads Manager', icon: 'Monitor' },
  { to: '/admin/icons', label: 'Icons / Emoji', icon: 'Star' },
  { to: '/admin/health', label: 'System Health', icon: 'Activity' },
  { to: '/admin/backup', label: 'Backup', icon: 'Package' },
  { to: '/admin/activity', label: 'Activity Log', icon: 'Clock' },
  { to: '/admin/features', label: 'Feature Control', icon: 'SlidersHorizontal' },
  { to: '/admin/login-page', label: 'Login Page', icon: 'User' },
  { to: '/admin/publish-check', label: 'Publish Check', icon: 'ShieldCheck' },
  { to: '/admin/preview', label: 'Preview Mode', icon: 'Monitor' },
  { to: '/admin/notifications', label: 'Notifications', icon: 'Bell' },
  { to: '/admin/settings', label: 'Website Settings', icon: 'Settings' },
  { to: '/admin/analytics', label: 'Analytics', icon: 'BarChart3' },
  { to: '/admin/security', label: 'Security', icon: 'Shield' },
  { to: '/admin/maintenance', label: 'Maintenance', icon: 'Wrench' },
]

let ctx

function beep(freq, duration, type = 'sine', gain = 0.04) {
  try {
    const AC = window.AudioContext || window.webkitAudioContext
    if (!AC) return
    ctx = ctx || new AC()
    const osc = ctx.createOscillator()
    const g = ctx.createGain()
    osc.type = type
    osc.frequency.value = freq
    g.gain.value = gain
    osc.connect(g)
    g.connect(ctx.destination)
    osc.start()
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration)
    osc.stop(ctx.currentTime + duration)
  } catch {
    /* autoplay may block */
  }
}

export const sounds = {
  cart: () => beep(520, 0.12, 'triangle'),
  buy: () => {
    beep(440, 0.1)
    setTimeout(() => beep(660, 0.14), 90)
  },
  success: () => {
    beep(523, 0.1)
    setTimeout(() => beep(784, 0.16), 80)
  },
  error: () => beep(180, 0.22, 'sawtooth', 0.03),
}

export function playSound(name, enabled) {
  if (!enabled) return
  const fn = sounds[name]
  if (fn) fn()
}

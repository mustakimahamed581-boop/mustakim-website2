function delay(ms = 700) {
  return new Promise((r) => setTimeout(r, ms))
}

export async function testConnection({ mockMode, configured }) {
  await delay(800)
  if (mockMode) {
    return { ok: true, status: 'demo_connected', message: 'DEMO CONNECTED — mock adapter only. No live API was called.' }
  }
  if (!configured) {
    return { ok: false, status: 'not_connected', message: 'Connection failed. Credentials are empty or a backend adapter is required.' }
  }
  return { ok: false, status: 'error', message: 'Live test requires a server-side adapter. Credentials are never sent from the public frontend.' }
}

export async function mockPayment({ method, mockOutcome = 'pending' }) {
  await delay(900)
  if (method === 'cod') return { status: 'pending', message: 'Cash on Delivery selected. Pay when the parcel arrives.' }
  if (mockOutcome === 'success') return { status: 'success', message: 'Demo payment marked successful. No live gateway was charged.' }
  if (mockOutcome === 'failed') return { status: 'failed', message: 'Demo payment failed. Try another method or Cash on Delivery.' }
  return { status: 'pending', message: `${method} requires a connected payment adapter. Status: PAYMENT PENDING.` }
}

export async function createCourierParcel({ mockMode, order }) {
  await delay(800)
  if (!mockMode) {
    return { ok: false, message: 'Steadfast is NOT CONNECTED. Enable DEMO MODE or connect via a backend adapter.' }
  }
  const tracking = `TRK${String(Date.now()).slice(-6)}`
  return {
    ok: true,
    consignmentId: `SF-demo-${String(Date.now()).slice(-4)}`,
    trackingCode: tracking,
    status: 'in_transit',
    message: `DEMO parcel created for ${order?.id || 'order'}.`,
  }
}
